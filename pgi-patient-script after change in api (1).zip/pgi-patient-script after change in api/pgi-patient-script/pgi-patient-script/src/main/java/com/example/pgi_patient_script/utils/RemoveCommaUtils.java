package com.example.pgi_patient_script.utils;

public class RemoveCommaUtils {

    public static String removeComma(String value) {
        // Check and remove leading comma
        if (value.startsWith(",")) {
            value = value.substring(1);
        }

        // Check and remove trailing comma
        if (value.endsWith(",")) {
            value = value.substring(0, value.length() - 1);
        }

        return value;
    }
}
