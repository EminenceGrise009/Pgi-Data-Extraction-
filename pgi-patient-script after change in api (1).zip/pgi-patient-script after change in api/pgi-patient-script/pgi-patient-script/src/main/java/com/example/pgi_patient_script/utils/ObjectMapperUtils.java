package com.example.pgi_patient_script.utils;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Getter
public final class ObjectMapperUtils {
    private static final ObjectMapper OBJECT_MAPPER;
    private static final ObjectWriter WRITER;
    private static final ObjectWriter PRETTY_WRITER;

    private static final TypeReference<HashMap<String, String>>
        STRING_MAP_TYPEREFERENCE = new TypeReference<>() {
    };

    static {
        OBJECT_MAPPER = new ObjectMapper();
        OBJECT_MAPPER.registerModule(new Jdk8Module());
        OBJECT_MAPPER.registerModule(new JavaTimeModule());
        OBJECT_MAPPER.configure(JsonParser.Feature.ALLOW_COMMENTS, true);
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        WRITER = OBJECT_MAPPER.writer();
        PRETTY_WRITER = OBJECT_MAPPER.writerWithDefaultPrettyPrinter();

    }

    private ObjectMapperUtils() {
        throw new UnsupportedOperationException("No Object For This Class.!");
    }

    @SneakyThrows
    public static String toJsonPrettyString(Object value) {
        return PRETTY_WRITER.writeValueAsString(value);
    }

    @SneakyThrows
    public static String toJsonString(Object value) {
        return WRITER.writeValueAsString(value);
    }

    /**
     * Returns the deserialized object from the given json string and target
     * class; or null if the given json string is null.
     */
    @SneakyThrows
    public static <T> T fromJsonString(String json, Class<T> clazz) {
        if (json == null) {
            return null;
        }
        return OBJECT_MAPPER.readValue(json, clazz);
    }

    @SneakyThrows
    public static <T> T fromJsonString(String json, TypeReference<T> typeReference) {
        if (json == null) {
            return null;
        }
        return OBJECT_MAPPER.readValue(json, typeReference);
    }

    @SneakyThrows
    public static ObjectMapper getObjectMapperUtils() {
        return OBJECT_MAPPER;
    }

    /**
     * Returns a map of strings from the given json string; or null if the given json string is null.
     */
    @SneakyThrows
    public static Map<String, String> stringMapFromJsonString(String json) {
        if (json == null) {
            return null;
        }
        return OBJECT_MAPPER.readValue(json, STRING_MAP_TYPEREFERENCE);
    }

    /**
     * Returns the deserialized object from the given json string and target
     * class; or null if the given json string is null. Clears the JSON location in the event of an error
     */


    @SneakyThrows
    public static <T> T fromSensitiveJsonString(String json, Class<T> clazz) {
        if (json == null) {
            return null;
        }
        return OBJECT_MAPPER.readValue(json, clazz);
    }

    public static JsonNode jsonNodeOf(String json) {
        return fromJsonString(json, JsonNode.class);
    }

    @SneakyThrows
    public static JsonGenerator jsonGeneratorOf(Writer writer) {
        return new JsonFactory().createGenerator(writer);
    }

    @SneakyThrows
    public static <T> T loadFrom(File file, Class<T> clazz) {
        return OBJECT_MAPPER.readValue(file, clazz);
    }

}