package com.example.pgi_patient_script.service.helper;

import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;


@Builder
public class SingleColumnHelper {

    private int headerIndex;
    private Row header;
    private List<String> dataToCreateList;
    private List<Row> rows;
    private int nestedIndex;
    private String fieldName;


    public int prePareData() {
        this.nestedIndex = headerIndex;
        createHeaderCellMap();
        createCellForVariable();
        return headerIndex;
    }

    private void createHeaderCellMap() {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellsValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellsValues.add(iterator.next().getStringCellValue());
        }

        if (!cellsValues.contains(fieldName)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(fieldName);
            headerIndex++;
        }

    }


    public void createCellForVariable() {
        int rowIndex = 0;
        for (String dataToCreate : dataToCreateList) {
            Row row = rows.get(rowIndex);
            Cell cell = row.createCell(nestedIndex);
            if (dataToCreate != null) {
                String removeCommaValue = removeComma(dataToCreate);
                String changeToYesOrNo = changeToYesOrNo(removeCommaValue);
                String trimmed = changeToYesOrNo.replace("undefined", "").replace("Others-","").trim();
                cell.setCellValue(trimmed);
            }
            rowIndex++;
        }


    }
}


