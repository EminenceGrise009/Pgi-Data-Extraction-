package com.example.pgi_patient_script.service.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;

@Builder
public class DyspepsiaScoringIndexHelper {
    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap = new LinkedHashMap<>();
    private List<JsonNode> recreatedData = new ArrayList<>();
    private Integer maxHeaderRepeatCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    private static final List<String> ORDERED_SYMPTOMS = Arrays.asList(
            "Epigastric pain", "Retrosternal pain", "Regurgitation", "Nausea",
            "Vomiting", "Belching", "Early Satiety", "Dysphagia"
    );

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxHeaderRepeatCount = 0;
    }

    private void creatingJsonNodeColumn() {
        setHeaderCount();
        createHeaderAndGetMaxHeaderRepeatCount();
        recreating();
        creatingInExcel();
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                Iterator<Map.Entry<String, JsonNode>> fields = jsonNode.fields();
                while (fields.hasNext()) {
                    Map.Entry<String, JsonNode> valueNode = fields.next();
                    String value = valueNode.getValue().asText();
                    Cell cell = row.createCell(nestedIndex);
                    cell.setCellValue(value);
                    nestedIndex++;
                }
            }
            nestedIndex = oldHeader;
            rowIndex++;
        }
    }

    private void recreating() {
        for (JsonNode jsonNode : jsonNodes) {
            ObjectNode newlyCreatedJsonNode = JsonNodeFactory.instance.objectNode();

            if (jsonNode != null && jsonNode.isArray()) {
                Map<String, String> alreadyExistData = getAlreadyExistData(jsonNode);
                creatingDataOnBasisOfMaxHeaderCount(maxHeaderRepeatCount, headerCountMap, alreadyExistData, newlyCreatedJsonNode);
            } else {
                for (String symptom : ORDERED_SYMPTOMS) {
                    newlyCreatedJsonNode.put(symptom, "");
                }
            }
            recreatedData.add(newlyCreatedJsonNode);
        }
    }

    private void creatingDataOnBasisOfMaxHeaderCount(Integer maxHeaderRepeatCount, Map<String, Integer> headerCountMap, Map<String, String> alreadyExistData, ObjectNode newlyCreatedJsonNode) {
        for (String symptom : ORDERED_SYMPTOMS) {
            if (alreadyExistData.containsKey(symptom)) {
                String value = alreadyExistData.get(symptom);
                String removeCommaValue = removeComma(value);
                String changeToYesOrNo = changeToYesOrNo(removeCommaValue);
                String trimmed = changeToYesOrNo.replace("undefined", "").trim();
                newlyCreatedJsonNode.put(symptom, trimmed);
            } else {
                newlyCreatedJsonNode.put(symptom, "");
            }
        }
    }

    private Map<String, String> getAlreadyExistData(JsonNode jsonNode) {
        Map<String, String> alreadyExistData = new HashMap<>();
        for (JsonNode element : jsonNode) {
            if (element.isObject()) {
                String dyspepsiaName = element.get("dyspepsia_name").asText();
                String score = element.get("score").asText();
                alreadyExistData.put(dyspepsiaName, score);
            }
        }
        return alreadyExistData;
    }

    private void createHeaderAndGetMaxHeaderRepeatCount() {
        maxHeaderRepeatCount = 1; // Since we're not repeating headers anymore

        for (String symptom : ORDERED_SYMPTOMS) {
            createHeaderCellMap(header, symptom);
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellsValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellsValues.add(iterator.next().getStringCellValue());
        }

        if (!cellsValues.contains(variable)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }
    }

    private void setHeaderCount() {
        for (String symptom : ORDERED_SYMPTOMS) {
            headerCountMap.put(symptom, 1);
        }
    }
}