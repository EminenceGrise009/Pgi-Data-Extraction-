package com.example.pgi_patient_script.service.helper.gallBladderField;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;

@Builder
public class GallBladderEjectionFractionForVolumnHelper {

    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap;
    private List<JsonNode> recreatedData;
    private Integer maxHeaderRepeatCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    private static final String[] TYPE_HEADERS = {"fasting", "postprandial_at_30min", "postprandial_at_60min"};
    private static final String[] ADDITIONAL_HEADERS = {"time", "gb_length", "gb_breadth", "gb_height", "mean_gb_volume", "gbef"};

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxHeaderRepeatCount = 0;
    }

    private void creatingJsonNodeColumn() {
        createHeaders();
        recreating();
        creatingInExcel();
    }

    private void createHeaders() {


        for (String header : TYPE_HEADERS) {
            createHeaderCellMap(header, header);
        }
        for (int i = 1; i <= maxHeaderRepeatCount; i++) {
            for (String header : ADDITIONAL_HEADERS) {
                createHeaderCellMap(header, header + i);
            }
        }
    }

    private void recreating() {
        for (JsonNode jsonArrayNode : jsonNodes) {

            if (jsonArrayNode != null && jsonArrayNode.isArray()) {
                JsonNode newlyCreatedJsonNode = new ObjectNode(JsonNodeFactory.instance);
                double fastingMeanGbVolume = 0;

                for (JsonNode element : jsonArrayNode) {
                    if (element.isObject()) {
//                        String type = element.get("type").asText();
//                        int index = getTypeIndex(type);
//                        for (String header : ADDITIONAL_HEADERS) {
//                            String value = element.get(header).asText();
//                            ((ObjectNode) newlyCreatedJsonNode).put(header + index, value);
//                        }
                        String type = element.get("type").asText();
                        double gbLength = element.get("gb_length").asDouble();
                        double gbBreadth = element.get("gb_breadth").asDouble();
                        double gbHeight = element.get("gb_height").asDouble();
                        double meanGbVolume = element.get("mean_gb_volume").asDouble();

                        int index = getTypeIndex(type);

                        if (type.equals("fasting")) {
                            double fastingValue = gbLength * gbHeight * gbBreadth * 0.52;
                            ((ObjectNode) newlyCreatedJsonNode).put("fasting", String.format("%.2f", fastingValue));
                            fastingMeanGbVolume = meanGbVolume;
                        } else if (type.equals("postprandial_at_30min")) {
                            double postprandialThirtyMinMeanGbVolume  = element.get("mean_gb_volume").asDouble();
                            double postprandialThirtyMinValue = ((fastingMeanGbVolume - postprandialThirtyMinMeanGbVolume) / fastingMeanGbVolume) * 100;
                            String str = Double.toString(postprandialThirtyMinValue);
                            String value=changeToYesOrNo(str);
                            ((ObjectNode) newlyCreatedJsonNode).put(type,  value);
                        } else if (type.equals("postprandial_at_60min")) {
                            double postprandialSixtyMinMeanGbVolume  = element.get("mean_gb_volume").asDouble();
                            double postprandialSixtyMinValue = ((fastingMeanGbVolume - postprandialSixtyMinMeanGbVolume) / fastingMeanGbVolume) * 100;
                            String str = Double.toString(postprandialSixtyMinValue);
                            String value=changeToYesOrNo(str);
                            ((ObjectNode) newlyCreatedJsonNode).put(type, value);
                        }
//                        for (String header : ADDITIONAL_HEADERS) {
//                            String value = element.get(header).asText();
//                            ((ObjectNode) newlyCreatedJsonNode).put(header + index, value);
//                        }
                    }
                }
                recreatedData.add(newlyCreatedJsonNode);
            }
            else{
                JsonNode newlyCreatedJsonNode = new ObjectNode(JsonNodeFactory.instance);
                ((ObjectNode) newlyCreatedJsonNode).put("fasting", "");
                ((ObjectNode) newlyCreatedJsonNode).put("postprandial_at_30min", "");
                ((ObjectNode) newlyCreatedJsonNode).put("postprandial_at_60min", "");
                recreatedData.add(newlyCreatedJsonNode);
            }
        }
    }

    private int getTypeIndex(String type) {
        switch (type) {
            case "fasting": return 1;
            case "postprandial_at_30min": return 2;
            case "postprandial_at_60min": return 3;
            default: return 0;
        }
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                for (String header : TYPE_HEADERS) {
                    Cell cell = row.createCell(nestedIndex);
                    cell.setCellValue(jsonNode.has(header) ? jsonNode.get(header).asText() : "");
                    nestedIndex++;
                }
                for (int i = 1; i <= maxHeaderRepeatCount; i++) {
                    for (String header : ADDITIONAL_HEADERS) {
                        Cell cell = row.createCell(nestedIndex);
                        String key = header + i;
                        cell.setCellValue(jsonNode.has(key) ? jsonNode.get(key).asText() : "");
                        nestedIndex++;
                    }
                }
            }
            nestedIndex = oldHeader;
            rowIndex++;
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellsValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellsValues.add(iterator.next().getStringCellValue());
        }

        if (!cellsValues.contains(variable)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }
    }

    private void createHeaderCellMap(String key, String variable) {
        createHeaderCellMap(header, variable);
    }
}