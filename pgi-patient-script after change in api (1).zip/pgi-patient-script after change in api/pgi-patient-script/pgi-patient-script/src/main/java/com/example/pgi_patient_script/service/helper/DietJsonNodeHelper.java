package com.example.pgi_patient_script.service.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;

@Builder
public class DietJsonNodeHelper {
    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap;
    private List<JsonNode> recreatedData;
    private Integer maxDietCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    private static final List<String> ORDERED_KEYS = Arrays.asList(
            "diet",
            "type_of_food",
            "frequency",
            "quantity"
    );

    private static final Map<String, String> HEADER_MAPPING = new LinkedHashMap<String, String>() {{
        put("diet", "diet");
        put("type_of_food", "type_non_veg");
        put("frequency", "Number_of_times/week");
        put("quantity", "Amount_each_time");
    }};

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxDietCount = 0;
    }

    private void creatingJsonNodeColumn() {
        setHeaderCount();
        createHeaderAndGetMaxDietCount();
        recreating();
        creatingInExcel();
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                int cellIndex = nestedIndex;

                // Process all diet entries up to maxDietCount
                for (int i = 1; i <= maxDietCount; i++) {
                    for (String originalKey : ORDERED_KEYS) {
                        String transformedKey = transformHeaderKey(originalKey);
                        String transformedKeyWithIndex = transformedKey + i;
                        JsonNode value = jsonNode.get(transformedKeyWithIndex);
                        Cell cell = row.createCell(cellIndex++);
                        cell.setCellValue(value != null ? value.asText() : "");
                    }
                }
            }
            rowIndex++;
        }
    }

    private void recreating() {
        for (JsonNode jsonNode : jsonNodes) {
            ObjectNode newlyCreatedJsonNode = JsonNodeFactory.instance.objectNode();

            if (jsonNode != null) {
                if (jsonNode.isArray()) {
                    Map<String, String> alreadyExistData = getAlreadyExistData(jsonNode);
                    creatingDataOnBasisOfMaxDietCount(maxDietCount, alreadyExistData, newlyCreatedJsonNode);
                }
            } else {
                createEmptyData(newlyCreatedJsonNode);
            }
            recreatedData.add(newlyCreatedJsonNode);
        }
    }

    private void createEmptyData(ObjectNode newlyCreatedJsonNode) {
        for (int i = 1; i <= maxDietCount; i++) {
            for (String originalKey : ORDERED_KEYS) {
                String transformedKey = transformHeaderKey(originalKey);
                String concat = transformedKey.concat("" + i);
                newlyCreatedJsonNode.put(concat, "");
            }
        }
    }

    private void creatingDataOnBasisOfMaxDietCount(Integer maxDietCount,
                                                   Map<String, String> alreadyExistData,
                                                   ObjectNode newlyCreatedJsonNode) {
        for (int i = 1; i <= maxDietCount; i++) {
            boolean hasDataForCurrentDiet = false;

            // Check if there's any data for the current diet number
            for (String originalKey : ORDERED_KEYS) {
                String concat = originalKey.concat("" + i);
                if (alreadyExistData.containsKey(concat) &&
                        !alreadyExistData.get(concat).trim().isEmpty() &&
                        !alreadyExistData.get(concat).equals("0")) {
                    hasDataForCurrentDiet = true;
                    break;
                }
            }

            // Process current diet entries
            for (String originalKey : ORDERED_KEYS) {
                String concat = originalKey.concat("" + i);
                String transformedKey = transformHeaderKey(originalKey);
                String transformedConcat = transformedKey.concat("" + i);

                if (alreadyExistData.containsKey(concat) && hasDataForCurrentDiet) {
                    String value = alreadyExistData.get(concat);
                    String trimmed = value.replace("undefined", "").trim();
                    String removeCommaValue = removeComma(trimmed);
                    String changeToYesOrNo = changeToYesOrNo(removeCommaValue);
                    newlyCreatedJsonNode.put(transformedConcat, changeToYesOrNo);
                } else {
                    newlyCreatedJsonNode.put(transformedConcat, "");
                }
            }
        }
    }

    private Map<String, String> getAlreadyExistData(JsonNode jsonNode) {
        Map<String, String> alreadyExistData = new HashMap<>();
        int dietIndex = 1;

        for (JsonNode element : jsonNode) {
            if (element.isObject()) {
                boolean hasNonEmptyValues = false;
                Map<String, String> tempData = new HashMap<>();

                Iterator<Map.Entry<String, JsonNode>> fields = element.fields();
                while (fields.hasNext()) {
                    Map.Entry<String, JsonNode> next = fields.next();
                    String key = next.getKey();
                    String value = next.getValue().asText();
                    String concat = key.concat("" + dietIndex);
                    tempData.put(concat, value);

                    if (!value.trim().isEmpty() && !value.equals("0")) {
                        hasNonEmptyValues = true;
                    }
                }

                if (hasNonEmptyValues) {
                    alreadyExistData.putAll(tempData);
                    dietIndex++;
                }
            }
        }
        return alreadyExistData;
    }

    private void createHeaderAndGetMaxDietCount() {
        // Create headers for all diets up to maxDietCount
        for (int i = 1; i <= maxDietCount; i++) {
            for (String originalKey : ORDERED_KEYS) {
                String transformedKey = transformHeaderKey(originalKey);
                String concat = transformedKey.concat(key + i);
                createHeaderCellMap(header, concat);
            }
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Cell headerCell = header.createCell(headerIndex++);
        headerCell.setCellValue(variable);
    }

    private void setHeaderCount() {
        for (JsonNode jsonArrayNode : jsonNodes) {
            if (jsonArrayNode != null && jsonArrayNode.isArray()) {
                Map<String, Integer> nestedMap = new LinkedHashMap<>();
                int currentDietCount = 0;

                for (JsonNode element : jsonArrayNode) {
                    if (element.isObject()) {
                        boolean hasNonEmptyValues = false;
                        Iterator<Map.Entry<String, JsonNode>> fields = element.fields();

                        while (fields.hasNext()) {
                            Map.Entry<String, JsonNode> field = fields.next();
                            String key = field.getKey();
                            String value = field.getValue().asText();

                            if (!value.trim().isEmpty() && !value.equals("0")) {
                                hasNonEmptyValues = true;
                            }
                            nestedMap.put(key, nestedMap.getOrDefault(key, 0) + 1);
                        }

                        if (hasNonEmptyValues) {
                            currentDietCount++;
                        }
                    }
                }

                maxDietCount = Math.max(maxDietCount, currentDietCount);

                for (Map.Entry<String, Integer> entry : nestedMap.entrySet()) {
                    headerCountMap.put(entry.getKey(), Math.max(entry.getValue(),
                            headerCountMap.getOrDefault(entry.getKey(), 0)));
                }
            }
        }
    }

    private String transformHeaderKey(String originalKey) {
        return HEADER_MAPPING.getOrDefault(originalKey, originalKey);
    }
}