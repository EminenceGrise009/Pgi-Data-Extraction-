package com.example.pgi_patient_script.dto.internal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IncludedCountQueryResponse {
    private Integer included;
    private Integer  excluded;
    private Integer pending;
}