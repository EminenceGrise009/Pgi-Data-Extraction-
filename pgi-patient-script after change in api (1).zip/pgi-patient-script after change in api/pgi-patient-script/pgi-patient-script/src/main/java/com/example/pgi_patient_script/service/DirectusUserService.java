package com.example.pgi_patient_script.service;

import com.example.pgi_patient_script.dto.internal.DirectusUserQueryResponse;
import com.example.pgi_patient_script.dto.entity.DirectusUserResponse;
import com.example.pgi_patient_script.dto.internal.FollowUpQueryResponse;
import com.example.pgi_patient_script.dto.internal.IncludedCountQueryResponse;
import com.example.pgi_patient_script.repository.DirectusUserRepositoryForFirstTime;
import com.example.pgi_patient_script.repository.DirectusUserRepositoryForFollowUp;
import com.example.pgi_patient_script.repository.DirectusUserRepositoryForRepeated;
import com.example.pgi_patient_script.repository.RepositoryOfIncluded;
import com.example.pgi_patient_script.service.helper.DataCreationHelper;
import com.example.pgi_patient_script.utils.ObjectMapperUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

import java.io.IOException;

@Service
public class DirectusUserService {

    private final DirectusUserRepositoryForFirstTime directusUserRepositoryForFirstTime;
    private final DirectusUserRepositoryForRepeated directusUserRepositoryForRepeated;
    private final DirectusUserRepositoryForFollowUp directusUserRepositoryForFollowUp;
    private final RepositoryOfIncluded repositoryOfIncluded;

    @Value("classpath:file/temp.xlsx")
    private Resource classPathResource;
 //   private static int headerIndex;

    public DirectusUserService(DirectusUserRepositoryForFirstTime directusUserRepositoryForFirstTime, DirectusUserRepositoryForRepeated directusUserRepositoryForRepeated,  DirectusUserRepositoryForFollowUp directusUserRepositoryForFollowUp, RepositoryOfIncluded repositoryOfIncluded) {
        this.directusUserRepositoryForFirstTime = directusUserRepositoryForFirstTime;
        this.directusUserRepositoryForRepeated=directusUserRepositoryForRepeated;
        this.directusUserRepositoryForFollowUp=directusUserRepositoryForFollowUp;
        this.repositoryOfIncluded = repositoryOfIncluded;
    }


    public ByteArrayOutputStream getDetailsForFirstTime(UUID hospitalCenterId,String diseaseCategory) throws IOException, InvocationTargetException, IllegalAccessException {
        List<DirectusUserQueryResponse> joinData = directusUserRepositoryForFirstTime.getDataForFirstVisit(hospitalCenterId,diseaseCategory);
        List<DirectusUserResponse> response = new ArrayList<>();
        createDirectusUserResponse(joinData, response);
        DataCreationHelper dataCreationHelper = DataCreationHelper.builder().build();
        return dataCreationHelper.createExcel(response);
    }

    public ByteArrayOutputStream getDetailsForRepeatedVisits(UUID hospitalCenterId,String diseaseCategory) throws IOException, InvocationTargetException, IllegalAccessException {
        List<DirectusUserQueryResponse> joinData = directusUserRepositoryForRepeated.getDataForRepeatedVisits(hospitalCenterId,diseaseCategory);
        List<DirectusUserResponse> response = new ArrayList<>();
        createDirectusUserResponse(joinData, response);
        DataCreationHelper dataCreationHelper = DataCreationHelper.builder().build();
        return dataCreationHelper.createExcel(response);
    }

    public List<FollowUpQueryResponse> getFollowUp(Integer previousId, String searchIt,UUID center_id) {
        return directusUserRepositoryForFollowUp.getDataOfFollowUp(previousId,searchIt,center_id);
    }
    public List<IncludedCountQueryResponse> getCountIncluded() {
        return repositoryOfIncluded.getCountOfIncluded();
    }


    private void createDirectusUserResponse(List<DirectusUserQueryResponse> directusUserQueryResponses, List<DirectusUserResponse> response) {
        for (DirectusUserQueryResponse directusUserQueryResponse : directusUserQueryResponses) {
            DirectusUserResponse directusUserResponse = new DirectusUserResponse(directusUserQueryResponse);

            String NearestHealthCareCenter =  directusUserQueryResponse.getNearestHealthCareCenter();
            JsonNode NearestHealthCareCenterJsonNode = getJsonNode(NearestHealthCareCenter);
            directusUserResponse.setNearestHealthCareCenter(NearestHealthCareCenterJsonNode);

            String weeklyFoodConsumption = directusUserQueryResponse.getWeeklyFoodConsumption();
            JsonNode weeklyFoodConsumptionJsonNode = getJsonNode(weeklyFoodConsumption);
            directusUserResponse.setWeeklyFoodConsumption(weeklyFoodConsumptionJsonNode);


            String reproductiveHPerO = directusUserQueryResponse.getReproductiveHPerO();
            JsonNode reproductiveHPerONode = getJsonNode(reproductiveHPerO);
            directusUserResponse.setReproductiveHPerO(reproductiveHPerONode);

            String  anthropometricMeasurement = directusUserQueryResponse.getAnthropometricMeasurement();
            JsonNode  anthropometricMeasurementNode = getJsonNode(anthropometricMeasurement);
            directusUserResponse.setAnthropometricMeasurement(anthropometricMeasurementNode);

            String typhoid = directusUserQueryResponse.getTyphoid();
            JsonNode typhoidNode = getJsonNode(typhoid);
            directusUserResponse.setTyphoid(typhoidNode);

            String smoking = directusUserQueryResponse.getSmoking();
            JsonNode smokingNode = getJsonNode(smoking);
            directusUserResponse.setSmoking(smokingNode);

            String alcohol = directusUserQueryResponse.getAlcohol();
            JsonNode alcoholNode = getJsonNode(alcohol);
            directusUserResponse.setAlcohol(alcoholNode);

            String pesticideUse = directusUserQueryResponse.getPesticideUse();
            JsonNode pesticideUseNode = getJsonNode(pesticideUse);
            directusUserResponse.setPesticideUse(pesticideUseNode);

            String familyHistory = directusUserQueryResponse.getFamilyHistory();
            JsonNode familyHistoryNode = getJsonNode(familyHistory);
            directusUserResponse.setFamilyHistory(familyHistoryNode);

            String types = directusUserQueryResponse.getTypes();
            JsonNode typesNode = getJsonNode(types);
            directusUserResponse.setTypes(typesNode);

            //3
            String drugHistory = directusUserQueryResponse.getDrugHistory();
            JsonNode drugHistoryJsonNode = getJsonNode(drugHistory);
            directusUserResponse.setDrugHistory(drugHistoryJsonNode);

            String familyHistoryOfCancer = directusUserQueryResponse.getFamilyHistoryOfCancer();
            JsonNode familyHistoryOfCancerJsonNode = getJsonNode(familyHistoryOfCancer);
            directusUserResponse.setFamilyHistoryOfCancer(familyHistoryOfCancerJsonNode);

            String pregnanciesHistory = directusUserQueryResponse.getPregnanciesHistory();
            JsonNode pregnanciesHistoryNode = getJsonNode(pregnanciesHistory);
            directusUserResponse.setPregnanciesHistory(pregnanciesHistoryNode);

            String diet = directusUserQueryResponse.getDiet();
            JsonNode dietNode = getJsonNode(diet);
            directusUserResponse.setDiet(dietNode);

            String typeOfFats = directusUserQueryResponse.getTypeOfFats();
            JsonNode typeOfFatsJsonNode = getJsonNode(typeOfFats);
            directusUserResponse.setTypeOfFats(typeOfFatsJsonNode);

            String foodRedChili = directusUserQueryResponse.getFoodRedChili();
            JsonNode foodRedChiliJsonNode = getJsonNode(foodRedChili);
            directusUserResponse.setFoodRedChili(foodRedChiliJsonNode);

            String foodGreenChili = directusUserQueryResponse.getFoodGreenChili();
            JsonNode foodGreenChiliJsonNode = getJsonNode(foodGreenChili);
            directusUserResponse.setFoodGreenChili(foodGreenChiliJsonNode);

            String foodPeanuts = directusUserQueryResponse.getFoodPeanuts();
            JsonNode foodPeanutsJsonNode = getJsonNode(foodPeanuts);
            directusUserResponse.setFoodPeanuts(foodPeanutsJsonNode);

            String gallbladderEjectionFraction = directusUserQueryResponse.getGallbladderEjectionFraction();
            JsonNode gallbladderEjectionFractionJsonNode = getJsonNode(gallbladderEjectionFraction);
            directusUserResponse.setGallbladderEjectionFraction(gallbladderEjectionFractionJsonNode);

            String haematology = directusUserQueryResponse.getHaematology();
            JsonNode haematologyjsonNode = getJsonNode(haematology);
            directusUserResponse.setHaematology(haematologyjsonNode);

            String symptomsOfDyspepsia = directusUserQueryResponse.getSymptomsOfDyspepsia();
            JsonNode symptomsOfDyspepsiaJsonNode = getJsonNode(symptomsOfDyspepsia);
            directusUserResponse.setSymptomsOfDyspepsia(symptomsOfDyspepsiaJsonNode);

            String liverFunctionTest = directusUserQueryResponse.getLiverFunctionTest();
            JsonNode liverFunctionTestJsonNode = getJsonNode(liverFunctionTest);
            directusUserResponse.setLiverFunctionTest(liverFunctionTestJsonNode);

            String biochemistry = directusUserQueryResponse.getBiochemistry();
            JsonNode biochemistryJsonNode = getJsonNode(biochemistry);
            directusUserResponse.setBiochemistry(biochemistryJsonNode);

            String dyspepsiaScoringIndex = directusUserQueryResponse.getDyspepsiaScoringIndex();
            JsonNode dyspepsiaScoringIndexJsonNode = getJsonNode(dyspepsiaScoringIndex);
            directusUserResponse.setDyspepsiaScoringIndex(dyspepsiaScoringIndexJsonNode);

            String ipd_visit = directusUserQueryResponse.getIpd_visit();
            JsonNode ipd_visitNode = getJsonNode(ipd_visit);
            directusUserResponse.setIpd_visit(ipd_visitNode);

            String opd_visit = directusUserQueryResponse.getOpd_visit();
            JsonNode opd_visitNode = getJsonNode(opd_visit);
            directusUserResponse.setOpd_visit(opd_visitNode);
            response.add(directusUserResponse);

        }
    }

    private JsonNode getJsonNode(String json) {
        if (json == null) {
            return null;
        }
        TypeReference<JsonNode> typeReference = new TypeReference<>() {
        };
        return ObjectMapperUtils.fromJsonString(json, typeReference);

    }

}