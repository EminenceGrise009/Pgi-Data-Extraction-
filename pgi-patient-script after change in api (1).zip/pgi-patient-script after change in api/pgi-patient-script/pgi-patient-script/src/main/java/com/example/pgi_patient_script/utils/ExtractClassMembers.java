package com.example.pgi_patient_script.utils;

import lombok.Getter;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

@Getter
public class ExtractClassMembers {


    public static List<String> extractClassVariables(Class<?> aClass, List<String> excludingVariables) {
        Field[] fields = aClass.getDeclaredFields();
        List<String> result = new ArrayList<>();
        for (Field field : fields) {
            if (!excludingVariables.contains(field.getName())) {
                result.add(field.getName());
            }
        }
        return result;
    }

    public static Method[] getMethods(Class<?> aClass) {
        return aClass.getMethods();
    }

//    public static <E> List<String> extractClassVariables(Class<DirectusUserResponse> directusUserResponseClass) {
//    }
}
