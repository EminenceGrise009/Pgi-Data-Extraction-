package com.example.pgi_patient_script.service.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;

@Builder
public class FamilyHistoryOfCancerHelper {

    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap;
    private List<JsonNode> recreatedData;
    private Integer maxHeaderRepeatCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    private final List<String> desiredHeaderOrder = Arrays.asList(
            "first_degree_relative", "age_at_diagnosis", "type_of_cancer", "stage_of_cancer", "treatment_received"
    );

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxHeaderRepeatCount = 0;
    }

    private void creatingJsonNodeColumn() {
        setHeaderCount();
        createHeaderAndGetMaxHeaderRepeatCount();
        recreating();
        creatingInExcel();
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                int cellIndex = nestedIndex;
                for (int i = 1; i <= maxHeaderRepeatCount; i++) {
                    for (String field : desiredHeaderOrder) {
                        String key = "FHOC_" + field + i;
                        String value = jsonNode.path(key).asText();
                        Cell cell = row.createCell(cellIndex);
                        cell.setCellValue(value);
                        cellIndex++;
                    }
                }
            }
            rowIndex++;
        }
    }

    private void recreating() {
        for (JsonNode jsonNode : jsonNodes) {
            ObjectNode newlyCreatedJsonNode = JsonNodeFactory.instance.objectNode();

            if (jsonNode != null && jsonNode.isArray()) {
                Map<String, String> alreadyExistData = getAlreadyExistData(jsonNode);
                creatingDataOnBasisOfMaxHeaderCount(maxHeaderRepeatCount, headerCountMap, alreadyExistData, newlyCreatedJsonNode);
            } else {
                for (int i = 1; i <= maxHeaderRepeatCount; i++) {
                    for (String key : desiredHeaderOrder) {
                        String concat = "FHOC_" + key + i;
                        newlyCreatedJsonNode.put(concat, "");
                    }
                }
            }
            recreatedData.add(newlyCreatedJsonNode);
        }
    }

    private void creatingDataOnBasisOfMaxHeaderCount(Integer maxHeaderRepeatCount, Map<String, Integer> headerCountMap, Map<String, String> alreadyExistData, ObjectNode newlyCreatedJsonNode) {
        for (int i = 1; i <= maxHeaderRepeatCount; i++) {
            for (String key : desiredHeaderOrder) {
                String concat = "FHOC_" + key + i;
                if (alreadyExistData.containsKey(concat)) {
                    String value = alreadyExistData.get(concat);
                    String trimmed = value.replace("undefined", "").trim();
                    String removeCommaValue = removeComma(trimmed);
                    String changeToYesOrNo = changeToYesOrNo(removeCommaValue);
                    newlyCreatedJsonNode.put(concat, changeToYesOrNo);
                } else {
                    newlyCreatedJsonNode.put(concat, "");
                }
            }
        }
    }

    private Map<String, String> getAlreadyExistData(JsonNode jsonNode) {
        Map<String, String> alreadyExistData = new HashMap<>();
        int index = 1;
        for (JsonNode element : jsonNode) {
            if (element.isObject()) {
                for (String key : desiredHeaderOrder) {
                    if (element.has(key)) {
                        String concat = "FHOC_" + key + index;
                        alreadyExistData.put(concat, element.get(key).asText());
                    }
                }
                index++;
            }
        }
        return alreadyExistData;
    }

    private void createHeaderAndGetMaxHeaderRepeatCount() {
        for (Map.Entry<String, Integer> entry : headerCountMap.entrySet()) {
            if (entry.getValue() > maxHeaderRepeatCount) {
                maxHeaderRepeatCount = entry.getValue();
            }
        }

        for (int i = 1; i <= maxHeaderRepeatCount; i++) {
            for (String columnKey : desiredHeaderOrder) {
                String concat = "FHOC_" + columnKey + i;
                createHeaderCellMap(header, concat);
            }
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellsValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellsValues.add(iterator.next().getStringCellValue());
        }

        if (!cellsValues.contains(variable)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }
    }

    private void setHeaderCount() {
        for (JsonNode jsonArrayNode : jsonNodes) {
            if (jsonArrayNode != null && jsonArrayNode.isArray()) {
                Map<String, Integer> nestedMap = new LinkedHashMap<>();
                for (JsonNode element : jsonArrayNode) {
                    if (element.isObject()) {
                        for (String headerKey : desiredHeaderOrder) {
                            if (element.has(headerKey)) {
                                nestedMap.put(headerKey, nestedMap.getOrDefault(headerKey, 0) + 1);
                            }
                        }
                    }
                }

                for (String headerKey : desiredHeaderOrder) {
                    headerCountMap.put(headerKey, Math.max(nestedMap.getOrDefault(headerKey, 0),
                            headerCountMap.getOrDefault(headerKey, 0)));
                }
            }
        }
    }
}