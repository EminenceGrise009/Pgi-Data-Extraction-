package com.example.pgi_patient_script.service.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;

@Builder
public class AlcoholHelper {

    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap;
    private List<JsonNode> recreatedData;
    private Integer maxHeaderRepeatCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    private static final List<String> ORDERED_HEADERS = Arrays.asList(
        "nfc_status_Alcohol", "Regular_alc", "times_a_week", "Duration_(years)", "Amount (ml/day)", "Type_alcohol"
    );

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxHeaderRepeatCount = 0;
    }

    private void creatingJsonNodeColumn() {
        setHeaderCount();
        createHeaderAndGetMaxHeaderRepeatCount();
        recreating();
        creatingInExcel();
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                for (String header : ORDERED_HEADERS) {
                    String value = jsonNode.path(header).asText("");
                    Cell cell = row.createCell(nestedIndex);
                    cell.setCellValue(value);
                    nestedIndex++;
                }
            }
            nestedIndex = oldHeader;
            rowIndex++;
        }
    }

    private void recreating() {
        for (JsonNode jsonNode : jsonNodes) {
            ObjectNode newlyCreatedJsonNode = JsonNodeFactory.instance.objectNode();

            if (jsonNode != null && jsonNode.isArray() && jsonNode.size() > 0) {
                JsonNode firstElement = jsonNode.get(0);
                newlyCreatedJsonNode.put("nfc_status_Alcohol", firstElement.path("nfc_status").asText());
                newlyCreatedJsonNode.put("Regular_alc", firstElement.path("is_regular").asText());
                newlyCreatedJsonNode.put("times_a_week", firstElement.path("no_of_times_a_week").asText());
                newlyCreatedJsonNode.put("Duration_(years)", firstElement.path("duration_in_years").asText());
                newlyCreatedJsonNode.put("Amount (ml/day)", firstElement.path("amount_per_day").asText());
                newlyCreatedJsonNode.put("Type_alcohol", firstElement.path("type_of_alcohol").asText());
            } else {
                for (String header : ORDERED_HEADERS) {
                    newlyCreatedJsonNode.put(header, "");
                }
            }
            recreatedData.add(newlyCreatedJsonNode);
        }
    }

    private void createHeaderAndGetMaxHeaderRepeatCount() {
        for (String columnKey : ORDERED_HEADERS) {
            createHeaderCellMap(header, columnKey);
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellsValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellsValues.add(iterator.next().getStringCellValue());
        }

        if (!cellsValues.contains(variable)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }
    }

    private void setHeaderCount() {
        for (String header : ORDERED_HEADERS) {
            headerCountMap.put(header, 1);
        }
    }
}