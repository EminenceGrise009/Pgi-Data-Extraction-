package com.example.pgi_patient_script.service.helper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;
@Builder
public class LeadScoringHelper {

    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap;
    private List<JsonNode> recreatedData;
    private Integer maxHeaderRepeatCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    private static final String[] TYPE_HEADERS = {"Final_Leeds_Score"};
    private static final String[] ADDITIONAL_HEADERS = {"dyspepsia_name", "status", "score",};

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxHeaderRepeatCount = 0;
    }

    private void creatingJsonNodeColumn() {
        createHeaders();
        recreating();
        creatingInExcel();
    }

    private void createHeaders() {
        for (String header : TYPE_HEADERS) {
            createHeaderCellMap(header, header);
        }
        for (int i = 1; i <= maxHeaderRepeatCount; i++) {
            for (String header : ADDITIONAL_HEADERS) {
                createHeaderCellMap(header, header + i);
            }
        }
    }private void recreating() {
        for (JsonNode jsonArrayNode : jsonNodes) {
            if (jsonArrayNode != null && jsonArrayNode.isArray()) {
                JsonNode newlyCreatedJsonNode = new ObjectNode(JsonNodeFactory.instance);
                Integer finalScore = 0;

                for (JsonNode element : jsonArrayNode) {
                    if (element.isObject()) {

                        Integer Score = element.get("score").asInt();
                        finalScore = finalScore + Score;
                    }
                }
                if (finalScore >= 16) {
                    ((ObjectNode) newlyCreatedJsonNode).put("Final_Leeds_Score", "Severe");

                } else if (finalScore >= 9 && finalScore <= 15) {

                    ((ObjectNode) newlyCreatedJsonNode).put("Final_Leeds_Score", "Moderate");

                } else if (finalScore >= 5 && finalScore <= 8) {
                    ((ObjectNode) newlyCreatedJsonNode).put("Final_Leeds_Score", "Mild");

                } else if (finalScore >= 1 && finalScore <= 4) {

                    ((ObjectNode) newlyCreatedJsonNode).put("Final_Leeds_Score", "Very Mild");

                } else {
                    ((ObjectNode) newlyCreatedJsonNode).put("Final_Leeds_Score", "");

                }

                recreatedData.add(newlyCreatedJsonNode);

            }else{
                JsonNode newlyCreatedJsonNode = new ObjectNode(JsonNodeFactory.instance);
                ((ObjectNode) newlyCreatedJsonNode).put("Final_Leeds_Score", "");
                recreatedData.add(newlyCreatedJsonNode);
            }
        }
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                for (String header : TYPE_HEADERS) {
                    Cell cell = row.createCell(nestedIndex);
                    cell.setCellValue(jsonNode.has(header) ? jsonNode.get(header).asText() : "");
                    nestedIndex++;
                }
                for (int i = 1; i <= maxHeaderRepeatCount; i++) {
                    for (String header : ADDITIONAL_HEADERS) {
                        Cell cell = row.createCell(nestedIndex);
                        String key = header + i;
                        cell.setCellValue(jsonNode.has(key) ? jsonNode.get(key).asText() : "");
                        nestedIndex++;
                    }
                }
            }
            nestedIndex = oldHeader;
            rowIndex++;
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellsValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellsValues.add(iterator.next().getStringCellValue());
        }

        if (!cellsValues.contains(variable)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }
    }

    private void createHeaderCellMap(String header_key, String variable) {
        createHeaderCellMap(header, variable);
    }
}
