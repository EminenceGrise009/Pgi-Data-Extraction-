package com.example.pgi_patient_script.repository;

import com.example.pgi_patient_script.dto.internal.DirectusUserQueryResponse;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Repository
public class DirectusUserRepositoryForRepeated {
    private final JdbcTemplate jdbcTemplate;

    public DirectusUserRepositoryForRepeated(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<DirectusUserQueryResponse> getDataForRepeatedVisits(UUID hospitalCenterId, String diseaseCategory) {

        StringBuilder sql = new StringBuilder("""
                WITH TIMES_OF_VISITS AS (
                SELECT ROW_NUMBER() OVER () AS serial_number,
                   ROW_NUMBER() OVER (PARTITION BY pv.user_id ORDER BY cp.center_name,cp.address, pv.date_created) AS rn,
                   CONCAT(UPPER(SUBSTRING(pp.first_name, 1, 1)), LOWER(SUBSTRING(pp.first_name, 2)), ' ',
                   UPPER(SUBSTRING(pp.last_name, 1, 1)), LOWER(SUBSTRING(pp.last_name, 2))) AS "name",
                   
                   CONCAT(cp.center_name,'_', cp.address) AS "Study_Site",
                   
                   CONCAT(DENSE_RANK() OVER (PARTITION BY cp.center_name,cp.address ORDER BY pv.user_id,cp.center_name,cp.address), 
                   '_', cp.center_name,'_', cp.address) AS Study_ID, 
                  
                   TO_CHAR(pv.date_created, 'DD-MM-YYYY') AS "visit_date",
                   
                   COALESCE(
                                        CASE
                                            WHEN RIGHT(kuppuswamy_scale_occupation_of_the_head, 1) ~ '^[0-9]$' THEN CAST(RIGHT(kuppuswamy_scale_occupation_of_the_head, 1) AS INTEGER)
                                            ELSE 0
                                        END,
                                        0
                                    ) +
                                    COALESCE(
                                        CASE
                                            WHEN RIGHT(kuppuswamy_scale_education_of_the_head, 1) ~ '^[0-9]$' THEN CAST(RIGHT(kuppuswamy_scale_education_of_the_head, 1) AS INTEGER)
                                            ELSE 0
                                        END,
                                        0
                                    ) +
                                    COALESCE(
                                        CASE
                                            WHEN RIGHT(kuppuswamy_scale_updated_monthly_family_income, 1) ~ '^[0-9]$' THEN CAST(RIGHT(kuppuswamy_scale_updated_monthly_family_income, 1) AS INTEGER)
                                            ELSE 0
                                        END,
                                        0
                                    ) AS total_score,
                   
                         CONCAT(pp.disease_case::json->>0, ' ', pp.disease_case::json->>1) AS "category",
                                      
                   pp.disease_case::json->>0 AS "category2",
                   pp.disease_case::json->>1 As "category1",
                   
                
                   pp.hospital_no AS hosp_no,
                   pp.hospital_no AS hosp_no,
                   pp.consent_from_url as Consent_Form,
                   pp.address AS Address,
                   pp.recruitment_date as Recruitment_Date,
                   pp.primary_contact_no as Mobile_Number,
                   pp.alternate_contact_no as Alternate_Mobile_Number,
                   pp.whatsapp_no as WhatsApp_Number,   
                   pp.inclusion_status,
                   
                   pp.center_id AS hospital_center_id,
                   
                   di.state_of_residence AS "State_of_residence_last_10_years",
                   di.residence_during_childhood AS "State_of_residence_first_10_years",
                   di.no_of_adults_family_member AS "adults",
                   di.no_of_child_family_member AS "children",
                   (di.no_of_adults_family_member + di.no_of_child_family_member) AS "total_family_members",
                   RIGHT(di.kuppuswamy_scale_occupation_of_the_head,1) AS "occupation_score",
                   RIGHT(di.kuppuswamy_scale_education_of_the_head,1) AS "education_score",
                   RIGHT(di.kuppuswamy_scale_updated_monthly_family_income,1) AS "family_income_score",
                   di."Socio_economic_class" AS "ses_class",
                   INITCAP(di.vehicle) AS "vehicle_category",                                                                                                                                    
                   -- Industry exposure
                   TRIM(','FROM ch.exposure_to_industry) AS "Industrial_Exposure",                                                                                                                                     
                   -- Family details
                   ch.no_of_brothers AS "number_of_brothers",
                   ch.no_of_sisters AS "number_of_sisters",
                   ch.no_of_sons AS "number_of_sons",
                   ch.no_of_daughters AS "number_of_daughters",                                                                                                                                     
                   -- Family history of diseases
                   ch.is_family_history_of_gbc AS "f_h_gbc",
                   ch.is_family_history_of_liver_cancer AS "f_h_liver_cancer",
                   ch.is_family_history_of_liver_cirrhosis AS "f_h_liver_cirrhosis",                                                                                                                                  
                   -- Dietary determinants
                   dd.staple_diet AS "staple_food",
                   dd.use_of_repeatedly_heated_oil AS "repeatedly_heated_oil",
                   gh.bristol_stool_usual_score AS bristol_stool_usual_score,
                   gh.bristol_stool_worst_score AS bristol_stool_worst_score,
                   gh.when_was_surgey_advised,
                   gh.why_not_done_surgery,
                   CASE
                   WHEN pv.id IS NOT NULL THEN 'Yes'
                        ELSE 'No'
                      END AS Included,
                   pain_x_value AS pain_value,
                   jaundice_x_value AS jaundice_value,
                   jaundice_x_value AS jaundice_description,
                   pruritis_x_value,
                   pruritis_desc AS pruritis_description,
                   fever_x_value AS fever_value,
                   fever_desc AS fever_description,
                   cholangitis_x_value,
                   cholangitis_desc AS cholangitis_description,
                   abd_distension_x_value,
                   abd_distension_desc,
                   features_of_goo_x_value,
                   features_of_goo_desc AS features_of_goo_description,
                   anorexia_x_value AS anorexia_value,
                   anorexia_x_value AS anorexia_description,
                   
                   gb_lump_size_x_value AS gb_lump_size_value,
                   gb_lump_size_desc AS gb_lump_size_description,
                   
                   wt_loss_x_value AS weight_loss_value,
                   wt_loss_desc AS weight_loss_description,
                   past_history_of_gsd_x_value AS past_history_of_gsd_value,
                 
                   duration_of_gsd_x_value AS duration_of_gsd_value,
                   duration_of_gsd_desc AS duration_of_gsd_description,
                   past_history_of_biliary_colic_x_value AS past_history_of_biliary_colic_value,
                   past_history_of_biliary_colic_desc AS past_history_of_biliary_colic_description,
                                
                                
                 
                   ascites_x_value,
                   ascites_desc,
                   tenderness_x_value AS tenderness_value,
                   tenderness_desc AS tenderness_description,
                  am.clinical_examination_ecog_performance_status AS ecog_performance_status,
                  *,
                  sgp.within_study_centre,
                  sgp.intraoperative_findings,
                  sgp.any_anatomical_variation,
                  sgp.bile_spillage,
                  sgp.duration_of_procedure,
                  sgp.cut_section,
                  sgp.gall_bladder,
                  sgp.gall_bladder_distension,
                  sgp.media_files,
                  sgp.outside_study_center_name,
                  sgp.surgery_done_by,
                  sgp.type_of_surgery,
                  sgp.difficulty,
                  sgp.complications,
                  ch.comorbidities AS co_morbidity_details,
                  ch.typhoid,
                  ch.smoking,
                  ch.alcohol,
                  ch.family_history,
                  ch.family_history_of_cancer,
                  ch.reproductive_h_per_o,
                  ch.drug_history,
                  ch.visit_remarks,
                  ch.no_of_brothers,
                  ch.no_of_sisters,
                  ch.no_of_sons,
                  ch.no_of_daughters,
                  ch.exposure_to_industry,
                  ch.pesticide_use,
                  am.height_cm,
                  am.weight_kg,
                  am.hip_circumference_cm,
                  am.bmi_kg_per_m_square,
                  am.blood_pressure,
                  am.tooth_count,
                  am.mid_arm_circumference_cm,
                  am.weight_height_ratio_kg_m_sqaure,
                  am.waist_circumference,
                  am.clinical_examination_ecog_performance_status,
                  cea.ipd_visit,
                  cea.opd_visit,
                  di.state_of_residence,
                  di.birth_state,
                  di.lives_in,
                  di.marital_status,
                  di.religion,
                  di.no_of_adults_family_member,
                  di.no_of_child_family_member,
                  di.patient_education,
                  di.socioeconomic_class,
                  di.exposure_to_industry,
                  di.vehicle,
                  di.socioeconomic_class,
                  di.nearest_health_care_center AS NearestHealthCareCenter,
                  di.recruitment_method,
                  di.residence_during_childhood,
                  TRIM(',' FROM di.water_source) AS water_source ,
                  di.ethnicity,
                  di.patient_occupation,
                  di.kuppuswamy_scale_education_of_the_head,
                  di.kuppuswamy_scale_occupation_of_the_head,
                  di.kuppuswamy_scale_updated_monthly_family_income,
                  di.reproductive_h_per_o,
                  di.anthropometric_measurement,
                  di.pregnancies_history,
                  dd.staple_diet,
                  dd.use_of_repeatedly_heated_oil,
                  dd.daily_consumption_of_food,
                  dd.source_of_food,
                  dd.weekly_food_consumption,
                  dd.type_of_fats,
                  dd.food_storage,
                  dd.food_red_chili,
                  dd.food_green_chili,
                  dd.food_peanuts,
                  dd.food_coffee,
                  dd.food_tea,
                  dd.types,
                  gh.gs_first_detected AS when_first_detected,
                  gh.duration_of_stone AS stone_duration_months,
                  gh.how_was_it_detected AS incidental,
                  gh.duration_of_symptoms AS symptom_duration_months,
                  gh.frequency_of_symptoms_per_month,
                  gh.nausea,
                  gh.vomiting,
                  UPPER(gh.documented_on::jsonb->>0)  AS documented_on,
                  gh.symptom_status::jsonb->>0  AS symptom_status,
                  gh.type_of_pain::jsonb->>0  AS  type_of_pain,
                  
                                
                  gh.pain_description::jsonb->>0  AS  PainDescriptionOnset,
                  gh.intensity::jsonb->>0  AS intensity,
                  gh.pain,
                 
                  gh.relief_of_pain::jsonb->>0  AS relief_of_pain,
                  gh.associated_symptoms::jsonb->>0  AS associated_symptoms,
                  gh.when_was_surgey_advised,
                  gh.why_not_done_surgery,
                  gh.radiation::jsonb->>0  AS radiation,
                  gh.location::jsonb->>0  AS location,
                  gh.precipitated_by::jsonb->>0  AS precipitated_by,
                  gh.duration::jsonb->>0  AS duration,
                  gh.total_no_of_hospitalizations AS total_number_of_hospitalizations,
                  gh.date_of_test,
                  gh.severity AS disease_severity,
                  gh.how_was_it_detected_remarks,
                  gh.description_of_symptoms,
                  gh.frequency_more_than_annual_details,
                  gh.type_of_pain_remarks AS pain_type,
                  gh.stool_frequency AS stool_frequency_in_last_one_week,
                  gh.bristol_stool_usual_score,
                  gh.bristol_stool_worst_score,
                  gh.gallstone_status,
                  gh.dyspepsia_final_score as Final_Score,
                  gh.symptoms_of_dyspepsia,
                  gh.dyspepsia_scoring_index,
                  gh.pain_at_night,
                  gh.pain_at_exertion,
                  gh.is_require_hospitalization,
                  --gh.frequency,
                  
                   CASE
                          WHEN gh.frequency LIKE '%infrequent%' THEN NULL
                          ELSE TRIM(SPLIT_PART(SPLIT_PART(gh.frequency, ',', 1), 'times/day', 1))
                      END AS times_per_day,
                      CASE
                          WHEN gh.frequency LIKE '%infrequent%' THEN NULL
                          ELSE TRIM(SPLIT_PART(SPLIT_PART(gh.frequency, ',', 2), 'times/week', 1))
                      END AS times_per_week,
                  	  CASE
                          WHEN gh.frequency LIKE '%infrequent%' THEN NULL
                          ELSE  TRIM(SPLIT_PART(SPLIT_PART(gh.frequency, ',', 3), 'times/month', 1))
                      END AS times_per_month,
                  	  CASE
                          WHEN gh.frequency LIKE '%infrequent%' THEN NULL
                          ELSE  TRIM(SPLIT_PART(SPLIT_PART(gh.frequency, ',', 4), 'times/year', 1))
                      END AS times_per_year,
                      CASE
                          WHEN gh.frequency LIKE '%infrequent%' THEN
                              TRIM(SPLIT_PART(gh.frequency, 'infrequent', 2))
                          ELSE NULL
                      END AS infrequent,
                  
                  
                  gbc.past_history_of_gsd_x_value,
                  gbc.past_history_of_gsd_desc,
                  gbc.duration_of_gsd_x_value,
                  gbc.duration_of_gsd_desc,
                  gbc.past_history_of_biliary_colic_x_value,
                  gbc.past_history_of_biliary_colic_desc,
                  gbc.pain_x_value,
                  gbc.jaundice_x_value,
                  gbc.pain_desc as Duration_Description,
                  gbc.jaundice_desc,
                  gbc.pruritis_x_value,
                  gbc.fever_x_value,
                  gbc.fever_desc,
                  gbc.cholangitis_x_value,
                  gbc.abd_distension_x_value,
                 
                 
                  gbc.anorexia_x_value,
                  gbc.anorexia_desc,
                   gbc.ho_lump_x_value AS H_O_Lump,
                  gbc.ho_lump_desc AS H_O_Lump_Desc,
                  gbc.wt_loss_x_value,
                  gbc.wt_loss_desc,
                  gbc.hepatomegaly_x_value,
                  gbc.gb_lump_size_x_value,
                  gbc.gb_lump_size_desc,
                  gbc.hepatomegaly_desc,
                  gbc.supraclavicular_ln_x_value,
                  gbc.supraclavicular_ln_desc,
                  gbc. post_cholecystectomy_scar_x_value,
                  gbc.post_cholecystectomy_scar_desc,
                                
                  gbc.tenderness_x_value,
                  gbc.tenderness_desc,
                  gbc.pruritis_desc,
                  gbc.features_of_goo_x_value,
                 
                 
                  hgt.ref_number,
                  hgt.length_of_gb_cm,
                  hgt.wall_thickness,
                  hgt.body,
                  hgt.neck,
                  hgt.growth_polyp_ulcer,
                  hgt.inflammation,
                  hgt.depth_of_inflammation,
                  hgt.pattern_of_inflammation,
                  hgt.granuloma,
                  hgt.giant_cells,
                  hgt.reactive_lymphoid_follicles,
                  
                  hgt.mucosal_denudation as Mucosal_Denudation,
                  hgt.mucosal_ulceration as Mucosal_Ulceration,
                  hgt.mucosal_hyperplasia as Mucosal_HyperPlasia ,
                  hgt.fibrosis as Fibrosis ,
                  
                  hgt.muscle_hypertrophy,
                  hgt.myocyte_vacuolation AS mucocyte_vacuolisation,
                  hgt.ras AS RAS,
                  hgt.hyalinisation,
                  hgt.calcification,
                  hgt.cholesterolosis,
                  hgt.metaplasia,
                  hgt.dysplasia,
                  hgt.atypia_nos,
                  hgt.cholecystitis,
                  hgt.incidental_gbc,
                  hgt.invasive_carcinoma AS Invasive_Carcinoma,
                  hgt.any_additional_findings,
                  hgt.date_time,
                 hgt.type_inflammation_n AS neutrophils,
                  hgt.type_inflammation_l AS lymphocytes,
                  hgt.type_inflammation_e AS eosinophils,
                  hgt.type_inflammation_m AS macrophages,
                  hgt.type_inflammation_pc AS plasma_cells,
                  hgt.media_files,
                  inv.haematology,
                  inv.liver_function_test,
                  inv.biochemistry,
                  inv.date_time ,
                  inv.media_files,
                  pv.date_created,
                  pv.date_updated,
                  pv.patient_profile_id,
                  qol.mobility,
                  qol.self_care,
                  qol. usual_activity,
                  qol.pain_description as painDiscomfort,
                  qol. anxiety_depression ,
                  qol. health_scale,
                  rad.fasting,
                  rad.gallbladder As gallbladder_status,
                  rad.sludge,
                  rad.gb_polyp,
                  rad.stone,
                  rad.number_of_stones,
                  rad.gb_wall_fundus AS fundus_mm,
                  rad.gb_wall_body AS body_mm,
                  rad.gb_wall_neck AS neck_mm,
                  rad.gb_wall_thickened AS thickened_wall,
                  
                 TO_CHAR( rad.date_updated , 'DD-MM-YYYY') as date_of_radiology,

                   CASE
                          WHEN gb_wall_thickened LIKE '%Focal%' THEN 'Focal'
                          WHEN gb_wall_thickened LIKE '%Diffuse%' THEN 'Diffuse'
                          ELSE NULL
                      END AS "FocalOrDiffuse",
                     
                      CASE
                          WHEN gb_wall_thickened LIKE '%Symmetrical%' THEN 'Symmetrical'
                          WHEN gb_wall_thickened LIKE '%Asymmetrical%' THEN 'Asymmetrical'
                          ELSE NULL
                      END AS "SymmetricalOrAsymmetrical",
                  rad.gb_wall_layered_appearance AS layered_appearance,
                  rad.gb_wall_intramural_echogenic_foci AS intramural_echogenic_foci,
                  rad.gb_interface_with_liver,
                  rad.fatty_liver,
                  rad.any_complications,
                  rad.gallbladder_ejection_fraction as gallbladderEjectionFraction,
                  rad.usg_done_by,
                  rad.out_side_study_center,
                  rad.media_files,
                  rad.grade_of_fatty_liver,
                  rad.out_side_study_center_name AS if_outside_mention_centre,
                            
                      rad.size_of_stones as size_of_stones,
                  
                  sa.size_of_stones as size_of_stones_mm,
                  sa.color_of_stones,
                  sa.shape_of_stones,
                  sa. weight_of_stone,
                  sa.number_of_stones as number_of_stone,
                  sa.stone_cs,
                  sa. ftir,
                  sa.cholesterol_composition,
                  sa. total_volume,
                  sa. media_files ,
                  sa.is_weight_of_stone_for_single,
                  ic.evaluation,
                  ic.distension,
                  ic.measurement_of_wall_thickness,
                  ic.characterization_of_wall_thickness,
                  ic.gallstones,
                  ic.number_of_stones,
                  ic.stone_size_of_largest_stone_in_cm,
                  ic.focal_gallbladder_thickening,
                  ic.gallbladder_polyp,
                  ic.mirrizi_syndrome,
                  ic.empyema_gallbladder,
                  ic.biliary,
                  ic.vascular,
                  ic.liver_mass,
                  ic.inadequate_evaluation_gb_rads_category,
                  ic.normal_gb_rads_category,
                  ic.benign_gb_rads_category,
                  ic.equivocal_gb_rads_category,
                  ic.malignancy_is_likely_gb_rads_category,
                  ic.malignancy_is_highly_likely,
                  ic.outside_study_centre,
                  ic.media_files , du.id as uuid
                   
                FROM
                       directus_users du
                   JOIN
                       patiant_profile pp ON du.id = pp.user_id
                   JOIN
                       patient_visits pv ON du.id = pv.user_id
                   JOIN
                       center_profile cp ON cp.user_id = pp.center_id
                   LEFT JOIN
                       demographic_information di ON pv.id = di.visit_id
                   LEFT JOIN
                       clinical_history ch ON pv.id = ch.visit_id
                   LEFT JOIN
                       gallstones_history gh ON pv.id = gh.visit_id
                   LEFT JOIN
                       anthropometric_measurements am ON pv.id = am.visit_id
                   LEFT JOIN
                       dietary_determinants dd ON pv.id = dd.visit_id
                   LEFT JOIN
                       investigations inv ON pv.id = inv.visit_id
                   LEFT JOIN
                       imaging_characteristics_of_the_gallbladder ic ON pv.id = ic.visit_id
                   LEFT JOIN
                       surgery_gs_patients sgp ON pv.id = sgp.visit_id
                   LEFT JOIN
                       histology_gb_tissue hgt ON pv.id = hgt.visit_id
                   LEFT JOIN
                       stone_analysis sa ON pv.id = sa.visit_id
                   LEFT JOIN
                       gbc_clinical_presentation gbc ON pv.id = gbc.visit_id
                   LEFT JOIN
                       quality_of_life qol ON pv.id = qol.visit_id
                   LEFT JOIN
                       radiology rad ON pv.id = rad.visit_id
                   LEFT JOIN
                       cost_effective_analysis cea ON pv.id = cea.visit_id)
                       SELECT *
                       FROM TIMES_OF_VISITS
                       WHERE rn > 1 
                        """);
        List<Object> params = new ArrayList<>();

        if (hospitalCenterId != null) {
            sql.append(" AND hospital_Center_id = ?");
            params.add(hospitalCenterId);
        }
//        if (diseaseCategory != null && !diseaseCategory.isEmpty()) {
//            sql.append(" AND \"category\" = ?");
//            params.add( diseaseCategory);
//        }

        if (diseaseCategory != null && !diseaseCategory.isEmpty()) {
            sql.append("AND");
            sql.append("(");
            sql.append("category1 in ('" +diseaseCategory+ "')");
            sql.append(" OR ");
            sql.append("category2 in ('" +diseaseCategory+ "')");
            sql.append(")");
        }

        sql.append(" ORDER BY \"Study_Site\",serial_number");

        return jdbcTemplate.query(sql.toString(), params.toArray(), BeanPropertyRowMapper.newInstance(DirectusUserQueryResponse.class));
    }
}











//                       AND times_of_visits.Hospital_Center_id = ?
//                        ORDER BY "Study_Site",serial_number
//
//
//                """;
//        List<DirectusUserQueryResponse> directusUserQueryResponses = jdbcTemplate.query(sql, new Object[]{hospitalCenterId}, BeanPropertyRowMapper.newInstance(DirectusUserQueryResponse.class));
//        return directusUserQueryResponses;
//    }

//    public List<DirectusUserQueryResponse> findAll() {
//        String sql = "SELECT * FROM directus_users";
//        return jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(DirectusUserQueryResponse.class));
//    }



