package com.example.pgi_patient_script.service.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;

@Builder
public class FatsTypeHelper {
    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap = new LinkedHashMap<>();
    private List<JsonNode> recreatedData = new ArrayList<>();
    private Integer maxHeaderRepeatCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    private static final List<String> FIXED_HEADER_ORDER = Arrays.asList("Mustard oil", "Butter", "Desi ghee", "Others");

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxHeaderRepeatCount = 0;
    }

    private void creatingJsonNodeColumn() {
        setHeaderCount();
        createHeaderAndGetMaxHeaderRepeatCount();
        recreating();
        creatingInExcel();
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                for (String headerName : FIXED_HEADER_ORDER) {
                    String value = jsonNode.has(headerName) ? jsonNode.get(headerName).asText() : "";
                    Cell cell = row.createCell(nestedIndex);
                    cell.setCellValue(value);
                    nestedIndex++;
                }
            }
            nestedIndex = oldHeader;
            rowIndex++;
        }
    }

    private void recreating() {
        for (JsonNode jsonNode : jsonNodes) {
            ObjectNode newlyCreatedJsonNode = JsonNodeFactory.instance.objectNode();

            if (jsonNode != null && jsonNode.isArray()) {
                Map<String, String> alreadyExistData = getAlreadyExistData(jsonNode);
                for (String headerName : FIXED_HEADER_ORDER) {
                    String value = alreadyExistData.getOrDefault(headerName, "");
                    String removeCommaValue = removeComma(value);
                    String changeToYesOrNo = changeToYesOrNo(removeCommaValue);
                    String trimmed = changeToYesOrNo.replace("undefined", "").trim();
                    newlyCreatedJsonNode.put(headerName, trimmed);
                }
            } else {
                for (String headerName : FIXED_HEADER_ORDER) {
                    newlyCreatedJsonNode.put(headerName, "");
                }
            }
            recreatedData.add(newlyCreatedJsonNode);
        }
    }

    private Map<String, String> getAlreadyExistData(JsonNode jsonNode) {
        Map<String, String> alreadyExistData = new HashMap<>();
        for (JsonNode element : jsonNode) {
            if (element.isObject()) {
                String name = element.get("name").asText();
                String quantity = element.get("quantity_ml_per_month").asText();
                alreadyExistData.put(name, quantity);
            }
        }
        return alreadyExistData;
    }

    private void createHeaderAndGetMaxHeaderRepeatCount() {
        for (String headerName : FIXED_HEADER_ORDER) {
            String newColumnKey = headerName + "Fats";
            createHeaderCellMap(header, newColumnKey);
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellsValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellsValues.add(iterator.next().getStringCellValue());
        }

        if (!cellsValues.contains(variable)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }
    }

    private void setHeaderCount() {
        for (String headerName : FIXED_HEADER_ORDER) {
            headerCountMap.put(headerName, 1);
        }
    }
}