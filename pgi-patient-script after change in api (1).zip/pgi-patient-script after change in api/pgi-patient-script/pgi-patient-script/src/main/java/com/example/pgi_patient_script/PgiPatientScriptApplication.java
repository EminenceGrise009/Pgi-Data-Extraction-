package com.example.pgi_patient_script;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgiPatientScriptApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgiPatientScriptApplication.class, args);
	}

}
