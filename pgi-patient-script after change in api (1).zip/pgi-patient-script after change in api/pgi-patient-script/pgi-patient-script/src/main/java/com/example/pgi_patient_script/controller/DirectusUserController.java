package com.example.pgi_patient_script.controller;

import com.example.pgi_patient_script.dto.internal.FollowUpQueryResponse;
import com.example.pgi_patient_script.dto.internal.IncludedCountQueryResponse;
import com.example.pgi_patient_script.service.DirectusUserService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api")
public class DirectusUserController {
    private final DirectusUserService directusUserService;

    public DirectusUserController(DirectusUserService directusUserService) {
        this.directusUserService = directusUserService;
    }

//    @GetMapping("/excelForBaseLine")
//    public ResponseEntity<byte[]> getExcelForFirstVisit(@RequestParam(value = "CenterId", required = false) UUID hospitalCenterId,
//                                                        @RequestParam(value = "diseaseCategory", required = false) String diseaseCategory)  throws IOException, IllegalAccessException, InvocationTargetException {
//        ByteArrayOutputStream baos = directusUserService.getDetailsForFirstTime(hospitalCenterId,diseaseCategory);
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
//        headers.setContentDispositionFormData("attachment", "BaseLine.xlsx");
//
//        return new ResponseEntity<>(baos.toByteArray(), headers, HttpStatus.OK);
//
//    }



    @GetMapping("/excelForFirstVisit")
    public ResponseEntity<byte[]> getExcelForFirstVisit(@RequestParam(value = "CenterId", required = false) UUID hospitalCenterId,
                                                        @RequestParam(value = "diseaseCategory", required = false) String diseaseCategory)  throws IOException, IllegalAccessException, InvocationTargetException {
        ByteArrayOutputStream baos = directusUserService.getDetailsForFirstTime(hospitalCenterId, diseaseCategory);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String formattedDate = currentDate.format(formatter);
        // String centerIdString = hospitalCenterId != null ? hospitalCenterId.toString() : "AllCenters";
        String diseaseCategoryString = diseaseCategory != null ? diseaseCategory : "AllCategories";
        String filename = String.format("BaseLine_%s_%s.xlsx", diseaseCategoryString, formattedDate);
        headers.setContentDispositionFormData("attachment", filename);

        return new ResponseEntity<>(baos.toByteArray(), headers, HttpStatus.OK);
    }


    @GetMapping("/CountIncluded")
    public ResponseEntity<List<IncludedCountQueryResponse>> getIncludedCount() {
        List<IncludedCountQueryResponse> includedPatients = directusUserService.getCountIncluded();
        return ResponseEntity.ok(includedPatients);
    }

    @GetMapping("/excelForRepeatedVisit")
    public ResponseEntity<byte[]> getExcel(@RequestParam(value = "CenterId", required = false) UUID hospitalCenterId,
                                           @RequestParam(value = "diseaseCategory", required = false) String diseaseCategory  ) throws IOException, IllegalAccessException, InvocationTargetException {
        ByteArrayOutputStream baos = directusUserService.getDetailsForRepeatedVisits(hospitalCenterId,diseaseCategory);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String formattedDate = currentDate.format(formatter);
        // String centerIdString = hospitalCenterId != null ? hospitalCenterId.toString() : "AllCenters";
        String diseaseCategoryString = diseaseCategory != null ? diseaseCategory : "AllCategories";
        String filename = String.format("FollowUp_%s_%s.xlsx", diseaseCategoryString, formattedDate);
        headers.setContentDispositionFormData("attachment", filename);

        return new ResponseEntity<>(baos.toByteArray(), headers, HttpStatus.OK);
    }

    @GetMapping("/FollowUpPatients")
    public ResponseEntity<List<FollowUpQueryResponse>> getFollowUpPatients(
            @RequestParam(value = "previousId", required = false) Integer previousId,
            @RequestParam(value = "hospital_no", required = false) String searchIt,
            @RequestParam(value = "centerId", required = false) UUID center_id
    )

    {
        List<FollowUpQueryResponse> excludedPatients = directusUserService.getFollowUp(previousId,searchIt,center_id);
        return ResponseEntity.ok(excludedPatients);
    }
}