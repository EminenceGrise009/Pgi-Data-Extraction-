package com.example.pgi_patient_script.service.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;

@Builder
public class DrugHistoryField {
    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap = new LinkedHashMap<>();
    private List<JsonNode> recreatedData = new ArrayList<>();
    private Integer maxHeaderRepeatCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    private static final List<String> HEADER_ORDER = Arrays.asList(
            "Hormone Replacement Therapy", "Oral contraceptives", "Fibrates", "NSAIDS",
            "Total parentral nutrition", "Statins", "Aspirin", "None", "Others"
    );

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxHeaderRepeatCount = 0;
    }

    private void creatingJsonNodeColumn() {
        setHeaderCount();
        createHeaderAndGetMaxHeaderRepeatCount();
        recreating();
        creatingInExcel();
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                for (String headerKey : HEADER_ORDER) {
                    JsonNode valueNode = jsonNode.get(headerKey);
                    String value = valueNode != null ? valueNode.asText() : "";
                    Cell cell = row.createCell(nestedIndex);
                    cell.setCellValue(value);
                    nestedIndex++;
                }
            }
            nestedIndex = oldHeader;
            rowIndex++;
        }
    }

    private void recreating() {
        for (JsonNode jsonNode : jsonNodes) {
            ObjectNode newlyCreatedJsonNode = JsonNodeFactory.instance.objectNode();

            if (jsonNode != null && jsonNode.isArray()) {
                Map<String, String> alreadyExistData = getAlreadyExistData(jsonNode);
                creatingDataOnBasisOfMaxHeaderCount(alreadyExistData, newlyCreatedJsonNode);
            } else {
                for (String key : HEADER_ORDER) {
                    newlyCreatedJsonNode.put(key, "");
                }
            }
            recreatedData.add(newlyCreatedJsonNode);
        }
    }

    private void creatingDataOnBasisOfMaxHeaderCount(Map<String, String> alreadyExistData, ObjectNode newlyCreatedJsonNode) {
        for (String key : HEADER_ORDER) {
            if (alreadyExistData.containsKey(key)) {
                String value = alreadyExistData.get(key);
                String removeCommaValue = removeComma(value);
                String changeToYesOrNo = changeToYesOrNo(removeCommaValue);
                String trimmed = changeToYesOrNo.replace("undefined", "").trim();
                newlyCreatedJsonNode.put(key, trimmed);
            } else {
                newlyCreatedJsonNode.put(key, "");
            }
        }
    }

    private Map<String, String> getAlreadyExistData(JsonNode jsonNode) {
        Map<String, String> alreadyExistData = new HashMap<>();
        for (JsonNode element : jsonNode) {
            if (element.isObject()) {
                String drugName = element.get("drug_name").asText();
                String nfcStatus = element.get("nfc_status").asText();

                if (drugName.toLowerCase().startsWith("others+")) {
                    String[] split = drugName.split("\\+", 2);
                    alreadyExistData.put("Others", split[1] + "--" + nfcStatus);
                } else {
                    alreadyExistData.put(drugName, nfcStatus);
                }
            }
        }
        return alreadyExistData;
    }

    private void createHeaderAndGetMaxHeaderRepeatCount() {
        for (String columnKey : HEADER_ORDER) {
            createHeaderCellMap(header, columnKey);
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Cell headerCell = header.createCell(headerIndex);
        headerCell.setCellValue(variable);
        headerIndex++;
    }

    private void setHeaderCount() {
        for (String header : HEADER_ORDER) {
            headerCountMap.put(header, 1);
        }
    }
}