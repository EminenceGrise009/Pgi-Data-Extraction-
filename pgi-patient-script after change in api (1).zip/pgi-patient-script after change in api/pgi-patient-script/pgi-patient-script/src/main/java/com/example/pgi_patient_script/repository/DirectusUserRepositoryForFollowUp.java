package com.example.pgi_patient_script.repository;

import com.example.pgi_patient_script.dto.internal.DirectusUserQueryResponse;
import com.example.pgi_patient_script.dto.internal.FollowUpQueryResponse;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Repository

public class DirectusUserRepositoryForFollowUp {

    private final JdbcTemplate jdbcTemplate;

    public DirectusUserRepositoryForFollowUp(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<FollowUpQueryResponse> getDataOfFollowUp(Integer previousId, String searchIt, UUID center_id) {
        StringBuilder sql = new StringBuilder(""" 
                  WITH TIMES_OF_VISITS AS (
                  
                  SELECT ROW_NUMBER() OVER () AS serial_number,
                ROW_NUMBER() OVER (PARTITION BY pv.user_id ORDER BY cp.center_name,cp.address,pv.date_created) AS rn,

                CONCAT(UPPER(SUBSTRING(pp.first_name, 1, 1)), LOWER(SUBSTRING(pp.first_name, 2)), ' ',
                UPPER(SUBSTRING(pp.last_name, 1, 1)), LOWER(SUBSTRING(pp.last_name, 2))) AS "name",

                CONCAT(cp.center_name,'_', cp.address) AS "Study_Site",

                CONCAT(DENSE_RANK() OVER (PARTITION BY cp.center_name,cp.address ORDER BY pv.user_id,cp.center_name,cp.address), 
                '_', cp.center_name,'_', cp.address) AS Study_ID, 

                pv.date_created AS visit_date,
                      pv.user_id AS patient_visit_user_id,
                      
                      pp.id,
                pp.age,
                pp.primary_contact_no as Mobile_Number,
                   pp.alternate_contact_no as Alternate_Mobile_Number,
                   pp.whatsapp_no as WhatsApp_Number,   
                 
                pp.secondary_alternate_contact_no,
                pp.first_name,
                pp.last_name,
                pp.email,
            
                pp.recruitment_date as Recruitment_Date,
                pp.gender,
                pp.father_name,
                pp.mother_name,
                pp.address,
                pp.center_id,
               
                pp.postal_code,
                pp.hospital_no,
                pp.admission_no,
                pp.ward_no,
                pp.bed_no,
                pp.physician_in_charge,
                pp.user_id,
                pp.surgeon_in_charge,
                pp.recruitment_date
                  
                

                FROM
                    directus_users du
                JOIN
                    patiant_profile pp ON du.id = pp.user_id
                JOIN
                    patient_visits pv ON du.id = pv.user_id
                JOIN
                    center_profile cp ON cp.user_id = pp.center_id
                ),
                    
                 Top_Visit AS (
                     SELECT
                  *,
                  ROW_NUMBER() OVER (PARTITION BY patient_visit_user_id ORDER BY rn DESC) AS visit_rank
                     FROM
                  TIMES_OF_VISITS
                 )
                 SELECT
                     v.*,
                     TO_CHAR(v.visit_date, 'DD-MM-YYYY') AS formatted_visit_date,
                     (CURRENT_TIMESTAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata' - v.visit_date) AS days_since_last_visit
                 FROM
                     Top_Visit v
                 WHERE
                     v.visit_rank = 1
                     AND (CURRENT_TIMESTAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata' - v.visit_date) > INTERVAL '180 days'
      
                  """);
        List<Object> params = new ArrayList<>();
        if (searchIt != null && !searchIt.isEmpty()) {
            sql.append(" AND v.hospital_no LIKE ?");
            params.add("%" + searchIt + "%");
        }
        if (center_id != null) {
            sql.append(" AND v.center_id = ?");
            params.add(center_id);
        }

        if (previousId != null) {
            sql.append(" AND v.id > ?");
            params.add(previousId);
        }

        sql.append(" ORDER BY v.id ASC LIMIT 15");

        return jdbcTemplate.query(sql.toString(), params.toArray(),BeanPropertyRowMapper.newInstance(FollowUpQueryResponse.class));
    }
}

