package com.example.pgi_patient_script.dto.internal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class DirectusUserQueryResponse {

    @JsonProperty("uuid")
    public String uuid;

    @JsonProperty("serial_number")
    public String serial_number;

    @JsonProperty("study_site")
    public String study_site;

    @JsonProperty("Study_ID")
    public String Study_ID;

    @JsonProperty("visit_date")
    public String visit_date;

    @JsonProperty("category")
    public String category;

    @JsonProperty("Identification_Data")


    public String Identification_Data;

    @JsonProperty("identification_data")
    public String identification_data;

    @JsonProperty("name")
    public String name;

    @JsonProperty("age")
    public String age;

    @JsonProperty("gender")
    public String gender;

    @JsonProperty("hosp_no")
    public String hosp_no;

    @JsonProperty("Recruitment_Date")
    public String Recruitment_Date;

    @JsonProperty("father_name")
    public String father_name;

    @JsonProperty("mother_name")
    public String mother_name;

    @JsonProperty("email")
    public String email;

    @JsonProperty("Current_address")
    public String Current_address;

    @JsonProperty("Mobile_No")
    public String Mobile_Number;

    @JsonProperty("Alternate_Mobile_No")
    public String Alternate_Mobile_Number;

    @JsonProperty("WhatsApp_Number")
    public String WhatsApp_Number;

//    @JsonProperty("Consent_Form")
//   public String Consent_Form;

    public String recruitment_method;

    @JsonProperty("Personal_History")
    public String Personal_History;

    @JsonProperty("state_of_residence_last_10_years")
    public String state_of_residence_last_10_years;

    @JsonProperty("state_of_residence_first_10_years")
    public String state_of_residence_first_10_years;

    @JsonProperty("lives_in")
    public String lives_in;

    @JsonProperty("married")
    public String married;

    @JsonProperty("religion")
    public String religion;

    @JsonProperty("adults")
    public String adults;

    @JsonProperty("children")
    public String children;

    @JsonProperty("total_family_members")
    public String total_family_members;

    @JsonProperty("patient_education")
    public String patient_education;

    @JsonProperty("patient_occupation")
    public String patient_occupation;

    @JsonProperty("occupation_score")
    public String occupation_score;

    @JsonProperty("education_score")
    public String education_score;

    @JsonProperty("family_income_score")
    public String family_income_score;

    public String ses_category;

    @JsonProperty("ses_class")
    public String ses_class;

    @JsonProperty("vehicle_category")
    public String vehicle_category;

    @JsonProperty("water_source")
    public String water_source;

    @JsonProperty("opd_visit")
    public String opd_visit;

    @JsonProperty("ipd_visit")
    public String ipd_visit;




    @JsonProperty("Clinical_History")
    public String Clinical_History;

    @JsonProperty("co_morbidity_details")
    public String co_morbidity_details;


    @JsonProperty("number_of_brothers")
    public String number_of_brothers;

    @JsonProperty("number_of_sisters")
    public String number_of_sisters;

    @JsonProperty("number_of_sons")
    public String number_of_sons;

    @JsonProperty("number_of_daughters")
    public String number_of_daughters;
    public String fh_gs;
    public String fh_cancer;

    @JsonProperty("f_h_gbc")
    public String f_h_gbc;

    @JsonProperty("f_h_liver_cancer")
    public String f_h_liver_cancer;

    @JsonProperty("f_h_liver_cirrhosis")
    public String f_h_liver_cirrhosis;

    @JsonProperty("staple_food")
    public String staple_food;

    @JsonProperty("repeatedly_heated_oil")
    public String repeatedly_heated_oil;

    @JsonProperty("description_of_symptoms")
    public String description_of_symptoms;

    @JsonProperty("when_first_detected")
    public String when_first_detected;

    @JsonProperty("stone_duration_months")
    public String stone_duration_months;

    @JsonProperty("incidental")
    public String incidental;

    @JsonProperty("symptom_duration_months")
    public String symptom_duration_months;

    @JsonProperty("documented_on")
    public String documented_on;

    @JsonProperty("symptom_status")
    public String symptom_status;

    @JsonProperty("disease_severity")
    public String disease_severity;

    @JsonProperty("pain_type")
    public String pain_type;

    @JsonProperty("location")
    public String location;

    @JsonProperty("intensity")
    public String intensity;

    @JsonProperty("duration")
    public String duration;

    @JsonProperty("radiation")
    public String radiation;

    @JsonProperty("nausea")
    public String nausea;

    @JsonProperty("vomiting")
    public String vomiting;

    @JsonProperty("precipitated_by")
    public String precipitated_by;

   // @JsonProperty("frequency")
   // public String frequency;
    public String times_per_day;
    public String times_per_week;
    public String times_per_month;
    public String times_per_year;
    public String infrequent;

    @JsonProperty("relief_of_pain")
    public String relief_of_pain;

    @JsonProperty("is_require_hospitalization")
    public String is_require_hospitalization;

    @JsonProperty("total_number_of_hospitalizations")
    public String total_number_of_hospitalizations;

    @JsonProperty("associated_symptoms")
    public String associated_symptoms;

    @JsonProperty("stool_frequency_in_last_one_week")
    public String stool_frequency_in_last_one_week;

    @JsonProperty("bristol_stool_usual_score")
    public String bristol_stool_usual_score;

    @JsonProperty("bristol_stool_worst_score")
    public String bristol_stool_worst_score;

    @JsonProperty("Was_Surgery_advised")
    public String Was_Surgery_advised;

    @JsonProperty("when_was_surgey_advised")
    public String when_was_surgey_advised;

    @JsonProperty("Was_Surgery_Done")
    public String Was_Surgery_Done;

    @JsonProperty("NearestHealthCareCenter")
    public String NearestHealthCareCenter;


    @JsonProperty("why_not_done_surgery")
    public String why_not_done_surgery;

    @JsonProperty("Surgery")
    public String Surgery;

    @JsonProperty("Duration_Description")
    public String Duration_Description;

    @JsonProperty("pain_value")
    public String pain_value;

    public String GBWall;

    @JsonProperty("jaundice_value")
    public String jaundice_value;

    @JsonProperty("jaundice_description")
    public String jaundice_description;

    @JsonProperty("pruritis_x_value")
    public String pruritis_x_value;

    @JsonProperty("pruritis_description")
    public String pruritis_description;

    @JsonProperty("fever_value")
    public String fever_value;

    @JsonProperty("H_O_Lump")
    public String H_O_Lump;
    @JsonProperty("H_O_Lump_Desc")
    public String H_O_Lump_Desc;

    @JsonProperty("fever_description")
    public String fever_description;

    @JsonProperty("cholangitis_x_value")
    public String cholangitis_x_value;

    @JsonProperty("cholangitis_description")
    public String cholangitis_description;

    @JsonProperty("abd_distension_x_value")
    public String abd_distension_x_value;

    @JsonProperty("abd_distension_des")
    public String abd_distension_des;

    @JsonProperty("features_of_goo_x_value")
    public String features_of_goo_x_value;

    @JsonProperty("features_of_goo_description")
    public String features_of_goo_description;

    @JsonProperty("anorexia_value")
    public String anorexia_value;

    @JsonProperty("anorexia_description")
    public String anorexia_description;

    @JsonProperty("gbLumpSizeXValue")
    public String gbLumpSizeXValue;

    @JsonProperty("gb_lump_size_description")
    public String gb_lump_size_description;


//    @JsonProperty("gb_lump_duration")
//    public String gb_lump_duration;
//
//    @JsonProperty("gb_lump_size")
//    public String gb_lump_size;

    @JsonProperty("weight_loss_value")
    public String weight_loss_value;

    @JsonProperty("weight_loss_description")
    public String weight_loss_description;


//    @JsonProperty("wight_loss_duration")
//    public String wight_loss_duration;
//
//    @JsonProperty("weight")
//    public String weight;

    public String past_history_of_gsd_x_value;
    public String past_history_of_gsd_desc;

    public String duration_of_gsd_x_value;
    public String duration_of_gsd_desc;

    public String past_history_of_biliary_colic_x_value;
    public String past_history_of_biliary_colic_desc;

    public String number_of_stone;

    @JsonProperty("hepatomegaly_x_value")
    public String hepatomegaly_x_value;

    @JsonProperty("hepatomegaly_desc")
    public String hepatomegaly_desc;

    @JsonProperty("post_cholecystectomy_scar_x_value")
    public String post_cholecystectomy_scar_x_value;

    @JsonProperty("post_cholecystectomy_scar_desc")
    public String post_cholecystectomy_scar_desc;

    @JsonProperty("supraclavicular_ln_x_value")
    public String supraclavicular_ln_x_value;

    @JsonProperty("supraclavicular_ln_desc")
    public String supraclavicular_ln_desc;

    @JsonProperty("ascites_x_value")
    public String ascites_x_value;

    @JsonProperty("ascites_desc")
    public String ascites_desc;

    @JsonProperty("tenderness_value")
    public String tenderness_value;

    @JsonProperty("tenderness_description")
    public String tenderness_description;

    @JsonProperty("ClinicalExamination")
    public String ClinicalExamination;

    public String inclusion_status;

    @JsonProperty("ecog_performance_status")
    public String ecog_performance_status;

    @JsonProperty("quality_of_life")
    public String quality_of_life;

    @JsonProperty("mobility")
    public String mobility;

    @JsonProperty("self_care")
    public String self_care;

    @JsonProperty("usual_activity")
    public String usual_activity;

    @JsonProperty("painDiscomfort")
    public String painDiscomfort;

    @JsonProperty("PainDescriptionOnset")
    public String PainDescriptionOnset;

    @JsonProperty("anxiety_depression")
    public String anxiety_depression;

    @JsonProperty("health_scale")
    public String health_scale;

    @JsonProperty("investigations")
    public String investigations;

    @JsonProperty("usg_done_by")
    public String usg_done_by;

    @JsonProperty("out_side_study_center")
    public String out_side_study_center;

    @JsonProperty("if_outside_mention_centre")
    public String if_outside_mention_centre;

    @JsonProperty("Fasting")
    public String Fasting;

    @JsonProperty("gallbladder_status")
    public String gallbladder_status;

    @JsonProperty("sludge")
    public String sludge;

    @JsonProperty("gb_polyp")
    public String gb_polyp;

    @JsonProperty("gallstone")
    public String gallstone;

    @JsonProperty("size_of_largest_stone")
    public String size_of_largest_stone;

    @JsonProperty("fundus_mm")
    public String fundus_mm;

    @JsonProperty("body_mm")
    public String body_mm;

    @JsonProperty("neck_mm")
    public String neck_mm;

    @JsonProperty("thickened_wall")
    public String thickened_wall;

    @JsonProperty("FocalOrDiffuse")
    public String FocalOrDiffuse;

    @JsonProperty("SymmetricalOrAsymmetrical")
    public String SymmetricalOrAsymmetrical;

    @JsonProperty("layered_appearance")
    public String layered_appearance;

    @JsonProperty("gb_wall_intramural_cyst")
    public String gb_wall_intramural_cyst;

    @JsonProperty("intramural_echogenic_foci")
    public String intramural_echogenic_foci;

    public String intraoperative_findings;

    @JsonProperty("gb_interface_with_liver")
    public String gb_interface_with_liver;

    @JsonProperty("fatty_liver")
    public String fatty_liver;

    @JsonProperty("any_complications")
    public String any_complications;

    @JsonProperty("grade_of_fatty_liver")
    public String grade_of_fatty_liver;

    @JsonProperty("complications")
    public String complications;

    @JsonProperty("complication")
    public String complication;

    @JsonProperty("date")
    public String date;

    public String Gall_Stone;

    @JsonProperty("surgery_done_by")
    public String surgery_done_by;

    @JsonProperty("outside_study_centre")
    public String outside_study_centre;

    @JsonProperty("if_outside_mention_name")
    public String if_outside_mention_name;

    @JsonProperty("type_of_surgery")
    public String type_of_surgery;

    @JsonProperty("gall_bladder")
    public String gall_bladder;

    @JsonProperty("gall_bladder_distension")
    public String gall_bladder_distension;

    @JsonProperty("any_anatomical_variation")
    public String any_anatomical_variation;

    @JsonProperty("cut_section")
    public String cut_section;

    @JsonProperty("bile_spillage")
    public String bile_spillage;

    @JsonProperty("duration_of_procedure")
    public String duration_of_procedure;

    @JsonProperty("difficulty")
    public String difficulty;

    @JsonProperty("histology")
    public String histology;

    @JsonProperty("ref_number")
    public String ref_number;

    @JsonProperty("GBC_Clinical_presentation")
    public String GBC_Clinical_presentation;

    @JsonProperty("length_of_gb_cm")
    public String length_of_gb_cm;

    @JsonProperty("wall_thickness")
    public String wall_thickness;

    @JsonProperty("fundus")
    public String fundus;

    @JsonProperty("body")
    public String body;

    @JsonProperty("neck")
    public String neck;

    @JsonProperty("inflammation")
    public String inflammation;

    @JsonProperty("neutrophils")
    public String neutrophils;

    @JsonProperty("lymphocytes")
    public String lymphocytes;

    @JsonProperty("eosinophils")
    public String eosinophils;

    @JsonProperty("macrophages")
    public String macrophages;

    @JsonProperty("plasma_cells")
    public String plasma_cells;

    @JsonProperty("depth_of_inflammation")
    public String depth_of_inflammation;

    @JsonProperty("pattern_of_inflammation")
    public String pattern_of_inflammation;

    @JsonProperty("granuloma")
    public String granuloma;

    @JsonProperty("giant_cells")
    public String giant_cells;

    @JsonProperty("reactive_lymphoid_follicles")
    public String reactive_lymphoid_follicles;


    @JsonProperty("Mucosal_Denudation")
    public String Mucosal_Denudation;

    @JsonProperty("Mucosal_Ulceration")
    public String Mucosal_Ulceration;

    @JsonProperty("Mucosal_HyperPlasia")
    public String Mucosal_HyperPlasia;

    @JsonProperty("Fibrosis")
    public String Fibrosis;

    @JsonProperty("muscle_hypertrophy")
    public String muscle_hypertrophy;

    @JsonProperty("mucocyte_vacuolisation")
    public String mucocyte_vacuolisation;

    @JsonProperty("RAS")
    public String RAS;

    public String gallstone_status;

    @JsonProperty("hyalinisation")
    public String hyalinisation;

    @JsonProperty("calcification")
    public String calcification;

    @JsonProperty("cholesterolosis")
    public String cholesterolosis;

    @JsonProperty("metaplasia")
    public String metaplasia;

    @JsonProperty("dysplasia")
    public String dysplasia;

    @JsonProperty("atypia_nos")
    public String atypia_nos;

    @JsonProperty("cholecystitis")
    public String cholecystitis;

    @JsonProperty("incidental_gbc")
    public String incidental_gbc;

    @JsonProperty("Invasive_Carcinoma")
    public String Invasive_Carcinoma;

    @JsonProperty("any_additional_findings")
    public String any_additional_findings;

    @JsonProperty("stone_analysis")
    public String stone_analysis;

    @JsonProperty("size_of_stones_mm")
    public String size_of_stones_mm;

    @JsonProperty("stone")
    public String stone;

    public String StonePresent;
    public String SingleOrMultipleOrGBPackedWithStones;

    @JsonProperty("number_of_stones")
    public String number_of_stones;

    @JsonProperty("size_of_stones")
    public String size_of_stones;

    @JsonProperty("color_of_stones")
    public String color_of_stones;

    @JsonProperty("shape_of_stones")
    public String shape_of_stones;

    @JsonProperty("weight_of_stone")
    public String weight_of_stone;

    @JsonProperty("total_volume")
    public String total_volume;

    @JsonProperty("stone_cs")
    public String stone_cs;

    @JsonProperty("ftir")
    public String ftir;

    @JsonProperty("cholesterol_composition")
    public String cholesterol_composition;

    @JsonProperty("family_history")
    public String familyHistory;

    @JsonProperty("smoking")
    public String smoking;

    @JsonProperty("alcohol")
    public String alcohol;

    @JsonProperty("typhoid")
    public String typhoid;

    @JsonProperty("types")
    public String types;

    @JsonProperty("reproductive_h_per_o")
    public String reproductiveHPerO;

    @JsonProperty("weekly_food_consumption")
    public String weeklyFoodConsumption;

    @JsonProperty("drug_history")
    public String drugHistory;

    @JsonProperty("family_history_of_cancer")
    public String familyHistoryOfCancer;

    @JsonProperty("total_score")
    public String total_score;

    @JsonProperty("stoneDurationMonths")
    public String stoneDurationMonths;

    @JsonProperty("pregnancies_history")
    public String pregnanciesHistory;

    @JsonProperty("diet")
    public String diet;

    @JsonProperty("type_of_fats")
    public String typeOfFats;

    @JsonProperty("Industrial_Exposure")
    public String Industrial_Exposure;

    @JsonProperty("food_red_chili")
    public String foodRedChili;

    @JsonProperty("Dietary_determinants")
    public String Dietary_determinants;

    @JsonProperty("food_green_chili")
    public String foodGreenChili;

    @JsonProperty("food_peanuts")
    public String foodPeanuts;

    @JsonProperty("gallbladder_ejection_fraction")
    public String gallbladderEjectionFraction;

    @JsonProperty("haematology")
    public String haematology;

    @JsonProperty("symptoms_of_dyspepsia")
    public String symptomsOfDyspepsia;

    @JsonProperty("liver_function_test")
    public String liverFunctionTest;

    @JsonProperty("biochemistry")
    public String biochemistry;

    @JsonProperty("dyspepsia_scoring_index")
    public String dyspepsiaScoringIndex;

    @JsonProperty("Final_Score")
    public String Final_Score;

    @JsonProperty("finalLeedsScore")
    public String finalLeedsScore;

    @JsonProperty("pesticide_use")
    public String pesticideUse;

    @JsonProperty("symptom_status")
    public String symptomStatus;

    @JsonProperty("disease_case")
    public String diseaseCase;

    public String Radiology;

    @JsonProperty("date_of_radiology")
    public String date_of_radiology;

    @JsonProperty("anthropometric_measurement")
    public String anthropometricMeasurement;




//    public Integer getF_h_gbc() {
//        return Boolean.TRUE.equals(f_h_gbc) ? 1 : 0;
//    }
//
//    public Integer getF_h_liver_cancer() {
//        return Boolean.TRUE.equals(f_h_liver_cancer) ? 1 : 0;
//    }
//
//    public Integer getF_h_liver_cirrhosis() {
//        return Boolean.TRUE.equals(f_h_liver_cirrhosis) ? 1 : 0;
 //   }





}
