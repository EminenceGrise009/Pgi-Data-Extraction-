package com.example.pgi_patient_script.service.helper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;


@Builder
public class GreenChilliHelper {

    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap ;
    private List<JsonNode> recreatedData;
    private Integer maxHeaderRepeatCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxHeaderRepeatCount = 0;
    }

    private void creatingJsonNodeColumn() {
        //don't change the order
        setHeaderCount();
        createHeaderAndGetMaxHeaderRepeatCount();
        recreating();
        creatingInExcel();
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                Iterator<Map.Entry<String, JsonNode>> fields = jsonNode.fields();
                while (fields.hasNext()) {
                    Map.Entry<String, JsonNode> valueNode = fields.next();
                    String value = valueNode.getValue().asText();
                    Cell cell = row.createCell(nestedIndex);
                    cell.setCellValue((value));
                    nestedIndex++;
                }
            }
            nestedIndex = oldHeader;
            rowIndex++;
        }
    }

    private void recreating() {
        for (JsonNode jsonNode : jsonNodes) {
            JsonNode newlyCreatedJsonNode = new ObjectNode(JsonNodeFactory.instance);

            if (jsonNode != null) {
                if (jsonNode.isArray()) {
                    Map<String, String> alreadyExistData = getAlreadyExistData(jsonNode);
                    creatingDataOnBasisOfMaxHeaderCount(maxHeaderRepeatCount, headerCountMap, alreadyExistData, (ObjectNode) newlyCreatedJsonNode);
                }
            } else {
                for (int i = 1; i <= maxHeaderRepeatCount; i++) {
                    for (Map.Entry<String, Integer> stringIntegerEntry : headerCountMap.entrySet()) {
                        String key = stringIntegerEntry.getKey();
                        String concat = key.concat("" + i);
                        ((ObjectNode) newlyCreatedJsonNode).put(concat, "");
                    }
                }
            }
            recreatedData.add(newlyCreatedJsonNode);
        }
    }

    private void creatingDataOnBasisOfMaxHeaderCount(Integer maxHeaderRepeatCount, Map<String, Integer> headerCountMap, Map<String, String> alreadyExistData, ObjectNode newlyCreatedJsonNode) {
        for (int i = 1; i <= maxHeaderRepeatCount; i++) {
            for (Map.Entry<String, Integer> stringIntegerEntry : headerCountMap.entrySet()) {
                String key = stringIntegerEntry.getKey();
                String concat1 = key.concat("" + i);

                if (alreadyExistData.containsKey(concat1)) {
                    String value = alreadyExistData.get(concat1);
                    String trimmed = value.replace("undefined", "").trim();
                    String removeCommaValue = removeComma(trimmed);
                    String changeToYesOrNo = changeToYesOrNo(removeCommaValue);
                    String concatKey = key.concat("" + i);
                    newlyCreatedJsonNode.put(concatKey, changeToYesOrNo);
                } else {
                    String concat = key.concat("" + i);
                    newlyCreatedJsonNode.put(concat, "");
                }
            }
        }
    }

    private Map<String, String> getAlreadyExistData(JsonNode jsonNode) {
        Map<String, String> alreadyExistData = new HashMap<>();
        int index = 1;
        for (JsonNode element : jsonNode) {
            if (element.isObject()) {
                Iterator<Map.Entry<String, JsonNode>> fields = element.fields();

                while (fields.hasNext()) {
                    Map.Entry<String, JsonNode> next = fields.next();
                    String key = next.getKey();
                    String concat = key.concat("" + index);
                    alreadyExistData.put(concat, next.getValue().asText());
                }
            }
            index++;
        }
        return alreadyExistData;
    }

    private void createHeaderAndGetMaxHeaderRepeatCount() {
        for (Map.Entry<String, Integer> stringIntegerEntry : headerCountMap.entrySet()) {
            if (stringIntegerEntry.getValue() > maxHeaderRepeatCount) {
                maxHeaderRepeatCount = stringIntegerEntry.getValue();
            }
        }

        for (int i = 1; i <= maxHeaderRepeatCount; i++) {
            Set<String> strings = headerCountMap.keySet();
            for (String columnKey : strings) {
                String concat = columnKey.concat(key);
                createHeaderCellMap(header, concat);
            }
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellsValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellsValues.add(iterator.next().getStringCellValue());
        }

        if (!cellsValues.contains(variable)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }

    }

    private void setHeaderCount() {
        for (JsonNode jsonArrayNode : jsonNodes) {
            if (jsonArrayNode != null && jsonArrayNode.isArray()) {
                Map<String, Integer> nestedMap = new LinkedHashMap<>();
                for (JsonNode element : jsonArrayNode) {
                    if (element.isObject()) {
                        Iterator<Map.Entry<String, JsonNode>> fields = element.fields();
                        while (fields.hasNext()) {
                            Map.Entry<String, JsonNode> field = fields.next();
                            String key = field.getKey();
                            nestedMap.put(key, nestedMap.getOrDefault(key, 0) + 1);
                        }
                    }
                }

                for (Map.Entry<String, Integer> entry : nestedMap.entrySet()) {
                    headerCountMap.put(entry.getKey(), Math.max(entry.getValue(),
                            headerCountMap.getOrDefault(entry.getKey(), 0)));
                }

            }
        }
    }
}
