

package com.example.pgi_patient_script.service.helper;
import ch.qos.logback.classic.encoder.JsonEncoder;
import com.example.pgi_patient_script.dto.entity.DirectusUserResponse;
import com.example.pgi_patient_script.service.helper.gallBladderField.GallBladderEjectionFractionForVolumnHelper;
import com.example.pgi_patient_script.service.helper.gallBladderField.GallBladderEjectionSimpleExpandHelper;
import com.example.pgi_patient_script.utils.ExtractClassMembers;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;

@Builder
public class DataCreationHelper {

    private int headerIndex;

    public ByteArrayOutputStream createExcel(List<DirectusUserResponse> response) throws IOException, IllegalAccessException, InvocationTargetException {
        System.out.println("File creation started");

        try (Workbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            System.out.println("Sheet creation started");
            Sheet sheet = workbook.getSheet("sheet");
            if (sheet == null) {
                sheet = workbook.createSheet("sheet");
                System.out.println("New 'sheet' created");
            } else {
                System.out.println("Existing 'sheet' found");
            }

            Row header = sheet.createRow(0);
            CellStyle headerStyle = workbook.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            List<String> variables = new ArrayList<>();

            System.out.println("Creating header");
            headerIndex = createHeader(variables, header, headerStyle);
            System.out.println("Header created with " + headerIndex + " columns");

            System.out.println("Creating data rows");
            int rowsCreated = createData(response, sheet, variables, header);
            System.out.println("Data rows created: " + rowsCreated);

            System.out.println("File write started");
            workbook.write(outputStream);
            System.out.println("File write completed. Bytes written: " + outputStream.size());

            if (outputStream.size() == 0) {
                throw new IOException("No data was written to the Excel file.");
            }

            return outputStream;
        }
    }

    private int createHeader(List<String> variables, Row header, CellStyle headerStyle) {
        variables.addAll(ExtractClassMembers.extractClassVariables(DirectusUserResponse.class, List.of(


                "NearestHealthCareCenter",
                "recruitment_method",
                "state_of_residence_last_10_years",
                "state_of_residence_first_10_years",
                "lives_in",
                "married",
                "religion",
                "adults",
                "children",
                "total_family_members",
                "patient_education",
                "patient_occupation",
                "occupation_score",
                "education_score",
                "family_income_score",
                "total_score",
                "ses_category",
                "ses_class",
                "vehicle_category",
                 "H_O_Lump",
                  "H_O_Lump_Desc",
                "familyHistory",
                "smoking",
                "alcohol",
                "typhoid",
                "reproductiveHPerO",
                "weeklyFoodConsumption",
                "drugHistory",
                "pregnanciesHistory",
                "diet",
                "types",
                "water_source",
                "typeOfFats",
                "foodRedChili",
                "foodGreenChili",
                "foodPeanuts",
                "anthropometric_measurement",
                "haematology",
                "opd_visit",
                "ipd_visit",

                "symptomsOfDyspepsia",
                "liverFunctionTest",
                "biochemistry",
                "dyspepsiaScoringIndex",
                "pesticideUse",
                "symptomStatus",
                "gallbladderEjectionFraction",
                "familyHistoryOfCancer",
                "Gall_Stone",
                "fh_cancer",
                "fh_gs",
                "ses_category",
                "ses_class",
                "vehicle_category",
                "Surgery",
                "complication",
                "number_of_stone",
                "intraoperative_findings",
                "Final_Score",
                "finalLeedsScore",
                "GBC_Clinical_presentation",
                "past_history_of_gsd_x_value",
                "past_history_of_gsd_desc",
                "duration_of_gsd_x_value",
                "duration_of_gsd_desc",
                "past_history_of_biliary_colic_x_value",
                "past_history_of_biliary_colic_desc",
                "Clinical_History", "co_morbidity_details",
                "typhoid", "smoking", "alcohol", "Industrial_Exposure",
                 "number_of_brothers", "number_of_sisters", "number_of_sons",
                "number_of_daughters",  "f_h_gbc", "f_h_liver_cancer", "f_h_liver_cirrhosis",
                "Dietary_determinants", "diet", "staple_food",
                "repeatedly_heated_oil", "weeklyFoodConsumption", "foodRedChili", "foodGreenChili",
                "foodPeanuts", "gallstone_status", "description_of_symptoms", "when_first_detected", "stoneDurationMonths",
                "symptom_duration_months", "incidental", "documented_on", "symptom_status", "disease_severity",
                "painDiscomfort", "pain_type", "location", "intensity", "duration", "exact_time", "radiation", "nausea",
                "vomiting", "precipitated_by", "frequency",

                "times_per_day",
                "times_per_week",
                "times_per_month",
                "times_per_year",
                "infrequent",
                "relief_of_pain", "is_require_hospitalization",
                "PainDescriptionOnset",
                "total_number_of_hospitalizations", "associated_symptoms", "stool_frequency_in_last_one_week", "bristol_stool_usual_score",
                "bristol_stool_worst_score", "when_was_surgey_advised","Was_Surgery_advised","Was_Surgery_Done", "why_not_done_surgery", "symptomsOfDyspepsia", "dyspepsiaScoringIndex", "Duration_Description",
                "pain_value", "jaundice_value", "jaundice_description", "pruritis_x_value", "pruritis_description", "fever_value",
                "fever_description", "cholangitis_x_value", "cholangitis_description", "abd_distension_x_value", "abd_distension_des",
                "features_of_goo_x_value", "features_of_goo_description", "anorexia_value", "anorexia_description", "gbLumpSizeXValue",
                "gb_lump_size_description", "weight_loss_value", "weight_loss_description", "hepatomegaly_x_value", "hepatomegaly_desc",
                "post_cholecystectomy_scar_x_value", "post_cholecystectomy_scar_desc", "supraclavicular_ln_x_value", "supraclavicular_ln_desc",
                "ascites_x_value", "ascites_desc", "tenderness_value", "tenderness_description", "ClinicalExamination",
                "ecog_performance_status", "quality_of_life", "mobility", "Radiology",
                "self_care", "usual_activity", "anxiety_depression", "health_scale", "investigations", "biochemistry",
                "date_of_radiology", "usg_done_by", "out_side_study_center", "if_outside_mention_centre", "Fasting", "gallbladder_status", "sludge", "gb_polyp",
                "stone",  "StonePresent",
                "SingleOrMultipleOrGBPackedWithStones",  "number_of_stones", "size_of_stones","GBWall", "fundus_mm", "body_mm", "neck_mm", "thickened_wall" ,"FocalOrDiffuse","SymmetricalOrAsymmetrical", "layered_appearance", "gb_wall_intramural_cyst",
                "intramural_echogenic_foci", "gb_interface_with_liver", "fatty_liver", "any_complications", "grade_of_fatty_liver", "complications", "gallbladderEjectionFraction", "date",
                "surgery_done_by", "outside_study_centre", "if_outside_mention_name", "type_of_surgery", "gall_bladder", "gall_bladder_distension", "any_anatomical_variation",
                "cut_section", "bile_spillage", "duration_of_procedure", "difficulty", "histology", "ref_number", "length_of_gb_cm", "wall_thickness",
                "fundus", "body", "neck", "inflammation", "neutrophils", "lymphocytes", "eosinophils", "macrophages", "plasma_cells", "depth_of_inflammation",
                "pattern_of_inflammation", "granuloma", "giant_cells", "reactive_lymphoid_follicles",   "Fibrosis", "Mucosal_HyperPlasia","Mucosal_Ulceration","Mucosal_Denudation", "muscle_hypertrophy", "mucocyte_vacuolisation", "RAS",
                "hyalinisation", "calcification", "cholesterolosis", "metaplasia", "dysplasia", "atypia_nos", "cholecystitis", "incidental_gbc",
                "Invasive_Carcinoma", "any_additional_findings", "stone_analysis", "size_of_stones_mm", "color_of_stones", "shape_of_stones", "weight_of_stone",
                "total_volume", "stone_cs", "ftir", "cholesterol_composition", "anthropometricMeasurement"



        )));
        int headerIndex = 0;
        for (String variable : variables) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }
        return headerIndex;
    }

    private void createHeaderCellMap(Row header, String variable) {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellsValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellsValues.add(iterator.next().getStringCellValue());
        }

        if (!cellsValues.contains(variable)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }

    }


    private int createData(List<DirectusUserResponse> response, Sheet sheet, List<String> variables, Row header) throws IllegalAccessException, InvocationTargetException {
        List<String> recruitmentMethodList = new ArrayList<>();
        List<String> stateOfResidenceLast10YearsList = new ArrayList<>();
        List<String> stateOfResidenceFirst10YearsList = new ArrayList<>();
        List<String> livesInList = new ArrayList<>();
        List<String> marriedList = new ArrayList<>();
        List<String> religionList = new ArrayList<>();
        List<String> adultsList = new ArrayList<>();
        List<String> childrenList = new ArrayList<>();
        List<String> totalFamilyMembersList = new ArrayList<>();
        List<String> patientEducationList = new ArrayList<>();
        List<String> patientOccupationList = new ArrayList<>();
        List<String> occupationScoreList = new ArrayList<>();
        List<String> educationScoreList = new ArrayList<>();
        List<String> familyIncomeScoreList = new ArrayList<>();
        List<String> totalScoreList = new ArrayList<>();

        List<JsonNode> nearestHealthCenterList = new ArrayList<>();
        List<JsonNode> familyHistoryList = new ArrayList<>();
        List<JsonNode> smokingList = new ArrayList<>();
        List<JsonNode> alcoholList  = new ArrayList<>();
        List<JsonNode> typhoidList = new ArrayList<>();
        List<JsonNode>  pesticideUseList = new ArrayList<>();
        List<JsonNode> reproductiveHPerOList = new ArrayList<>();
         List<JsonNode> weeklyFoodConsumptionList = new ArrayList<>();
        List<JsonNode> drugHistoryList = new ArrayList<>();
        List<JsonNode> familyListOfCancerList = new ArrayList<>();
        List<JsonNode> pregnanciesHistoryList = new ArrayList<>();
        List<JsonNode> dietList = new ArrayList<>();
        List<JsonNode> typeOfFatsList = new ArrayList<>();
        List<JsonNode> foodRedChiliList  = new ArrayList<>();
        List<JsonNode> foodGreenChiliList  = new ArrayList<>();
        List<JsonNode> foodPeanutsList  = new ArrayList<>();
        List<JsonNode> gallbladderEjectionFractionList = new ArrayList<>();
        List<JsonNode> symptomsOfDyspepsiaList = new ArrayList<>();
        List<JsonNode> liverFunctionTestList  = new ArrayList<>();
        List<JsonNode> biochemistryList  = new ArrayList<>();
        List<JsonNode> dyspepsiaScoringIndexList = new ArrayList<>();
        List<JsonNode> anthropometricMeasurementList = new ArrayList<>();
        List<JsonNode> typesList= new ArrayList<>();
        List<String> clinicalHistoryList = new ArrayList<>();
        List<String> coMorbidityDetailsList = new ArrayList<>();
        List<String> industrialExposureList = new ArrayList<>();
        List<String> numberOfBrothersList = new ArrayList<>();
        List<String> numberOfSistersList = new ArrayList<>();
        List<String> numberOfSonsList = new ArrayList<>();
        List<String> numberOfDaughtersList = new ArrayList<>();
        List<String>fhgsList = new ArrayList<>();
        List<String>fhcancerList=new ArrayList<>();
        List<String> fhGbcList = new ArrayList<>();
        List<String> fhLiverCancerList = new ArrayList<>();
        List<String> fhLiverCirrhosisList = new ArrayList<>();
        List<String> dietaryDeterminantsList = new ArrayList<>();
        List<String> stapleFoodList = new ArrayList<>();
        List<String> repeatedlyHeatedOilList = new ArrayList<>();
        List<String> gallStoneList = new ArrayList<>();
        List<String> gallstoneStatusList = new ArrayList<>();
        List<String> descriptionOfSymptomsList = new ArrayList<>();
        List<String> whenFirstDetectedList = new ArrayList<>();
        List<String> stoneDurationMonthsList = new ArrayList<>();
        List<String> symptomDurationMonthsList = new ArrayList<>();
        List<String> incidentalList = new ArrayList<>();
        List<String> documentedOnList = new ArrayList<>();
        List<String> symptomStatusList = new ArrayList<>();
        List<String> diseaseSeverityList = new ArrayList<>();
        List<String> painDescriptionList = new ArrayList<>();
        List<String> painDescriptionOnsetList = new ArrayList<>();
        List<String> painTypeList = new ArrayList<>();
        List<String> locationList = new ArrayList<>();
        List<String> intensityList = new ArrayList<>();
        List<String> durationList = new ArrayList<>();
        List<String> exactTimeList = new ArrayList<>();
        List<String> radiationList = new ArrayList<>();
        List<String> nauseaList = new ArrayList<>();
        List<String> vomitingList = new ArrayList<>();
        List<String> precipitatedByList = new ArrayList<>();
        //List<String> frequencyList = new ArrayList<>();
        List<String> times_per_dayList =new ArrayList<>();
        List<String> times_per_weekList =new ArrayList<>();
        List<String> times_per_monthList =new ArrayList<>();
        List<String> times_per_yearList =new ArrayList<>();
        List<String> infrequentList =new ArrayList<>();

        List<String> reliefOfPainList = new ArrayList<>();
        List<String> isRequireHospitalizationList = new ArrayList<>();
        List<String> totalNumberOfHospitalizationsList = new ArrayList<>();
        List<String> associatedSymptomsList = new ArrayList<>();
        List<String> stoolFrequencyInLastOneWeekList = new ArrayList<>();
        List<String> bristolStoolUsualScoreList = new ArrayList<>();
        List<String> bristolStoolWorstScoreList = new ArrayList<>();
        List<String> wasSurgeryAdvisedList = new ArrayList<>();
        List<String> whenWasSurgeryAdvisedList = new ArrayList<>();
        List<String> wasSurgeryDoneList = new ArrayList<>();
        List<String> whyNotDoneSurgeryList = new ArrayList<>();
        List<String> finalScoreList = new ArrayList<>();
        List<JsonNode> finalLeedScoreList = new ArrayList<>();

        List<String> gbcClinicalPresentationHelperList = new ArrayList<>();
        List<String> painValueList = new ArrayList<>();
        List<String> painDescList = new ArrayList<>();
        List<String> jaundiceValueList = new ArrayList<>();
        List<String> jaundiceDescriptionList = new ArrayList<>();
        List<String> pruritisXValueList = new ArrayList<>();
        List<String> pruritisDescriptionList = new ArrayList<>();
        List<String> feverValueList = new ArrayList<>();
        List<String> feverDescriptionList = new ArrayList<>();
        List<String> cholangitisXValueList = new ArrayList<>();
        List<String> cholangitisDescriptionList = new ArrayList<>();
        List<String> abdDistensionXValueList = new ArrayList<>();
        List<String> abdDistensionDesList = new ArrayList<>();
        List<String> featuresOfGooXValueList = new ArrayList<>();
        List<String> featuresOfGooDescriptionList = new ArrayList<>();
        List<String> anorexiaValueList = new ArrayList<>();
        List<String> anorexiaDescriptionList = new ArrayList<>();
        List<String> gbLumpSizeValueList = new ArrayList<>();
        List<String> gbLumpSizeDescriptionList = new ArrayList<>();
//        List<String> gbLumpDurationList = new ArrayList<>();
//        List<String> gbLumpSizeList = new ArrayList<>();
        List<String> weightLossValueList = new ArrayList<>();
        List<String> weightLossDescriptionList = new ArrayList<>();

//        List<String> weightLossDurationList = new ArrayList<>();
//        List<String> weightList = new ArrayList<>();

        List<String> pastHistoryOfGsdXValueList = new ArrayList<>();
        List<String> pastHistoryOfGsdDescList = new ArrayList<>();
        List<String> durationOfGsdXValueList = new ArrayList<>();
        List<String> durationOfGsdDescList = new ArrayList<>();
        List<String> pastHistoryOfBiliaryColicXValueList = new ArrayList<>();
        List<String> pastHistoryOfBiliaryColicDescList = new ArrayList<>();

        List<String> hepatomegalyXValueList = new ArrayList<>();
        List<String> hepatomegalyDescList = new ArrayList<>();
        List<String> postCholecystectomyScarXValueList = new ArrayList<>();
        List<String> postCholecystectomyScarDescList = new ArrayList<>();
        List<String> supraclavicularLnXValueList = new ArrayList<>();
        List<String> supraclavicularLnDescList = new ArrayList<>();
        List<String> ascitesXValueList = new ArrayList<>();
        List<String> ascitesDescList = new ArrayList<>();
        List<String> tendernessValueList = new ArrayList<>();
        List<String> tendernessDescriptionList = new ArrayList<>();
        List<String> clinicalExaminationList  = new ArrayList<>();
        List<String> ecogPerformanceStatusList = new ArrayList<>();
        List<String> qualityOfLifeList = new ArrayList<>();
        List<String> mobilityList = new ArrayList<>();
        List<String> selfCareList = new ArrayList<>();
        List<String> usualActivityList = new ArrayList<>();
        List<String> anxietyDepressionList = new ArrayList<>();
        List<String> healthScaleList = new ArrayList<>();
        List<String> investigationsList = new ArrayList<>();
        List<JsonNode> haematologyList = new ArrayList<>();
        List<String> radiologyList = new ArrayList<>();
        List<String> dateOfRadiologyList = new ArrayList<>();
        List<String> usgDoneByList = new ArrayList<>();
        List<String> outSideStudyCenterList = new ArrayList<>();
        List<String> ifOutsideMentionCentreList = new ArrayList<>();
        List<String> fastingList = new ArrayList<>();
        List<String> gallbladderStatusList = new ArrayList<>();
        List<String> sludgeList = new ArrayList<>();
        List<String> gbPolypList = new ArrayList<>();
        List<String> stoneList = new ArrayList<>();

        List<String> StonePresentList = new ArrayList<>();
         List<String> SingleOrMultipleOrGBPackedWithStonesList= new ArrayList<>();

        List<String> numberOfStonesList = new ArrayList<>();
        List<String> gbWallList = new ArrayList<>();

        List<String> sizeOfStonesList = new ArrayList<>();
        List<String> fundusMmList = new ArrayList<>();
        List<String> bodyMmList = new ArrayList<>();
        List<String> neckMmList = new ArrayList<>();
        List<String> thickenedWallList = new ArrayList<>();
        List<String> FocalOrDiffuseList = new ArrayList<>();
        List<String> SymmetricalOrAsymmetricalList = new ArrayList<>();
        List<String> layeredAppearanceList = new ArrayList<>();
        List<String> gbWallIntramuralCystList = new ArrayList<>();
        List<String> intramuralEchogenicFociList = new ArrayList<>();
        List<String> gbInterfaceWithLiverList = new ArrayList<>();
        List<String> fattyLiverList = new ArrayList<>();
        List<String> anyComplicationsList = new ArrayList<>();
        List<String> gradeOfFattyLiverList = new ArrayList<>();
        List<String> complicationsList = new ArrayList<>();
        List<String> surgeryList = new ArrayList<>();
        List<String> dateList = new ArrayList<>();
        List<String> surgeryDoneByList = new ArrayList<>();
        List<String> outsideStudyCentreList = new ArrayList<>();
        List<String> ifOutsideMentionNameList = new ArrayList<>();
        List<String> typeOfSurgeryList = new ArrayList<>();
        List<String> intraoperativeFindingsList = new ArrayList<>();
        List<String> gallBladderList = new ArrayList<>();
        List<String> gallBladderDistensionList = new ArrayList<>();
        List<String> anyAnatomicalVariationList = new ArrayList<>();
        List<String> cutSectionList = new ArrayList<>();
        List<String> bileSpillageList = new ArrayList<>();
        List<String> durationOfProcedureList = new ArrayList<>();
        List<String> difficultyList = new ArrayList<>();
        List<String> complicationList = new ArrayList<>();
        List<String> histologyList = new ArrayList<>();
        List<String> refNumberList = new ArrayList<>();
        List<String> lengthOfGbCmList = new ArrayList<>();
        List<String> wallThicknessList = new ArrayList<>();
        List<String> fundusList = new ArrayList<>();
        List<String> bodyList = new ArrayList<>();
        List<String> neckList = new ArrayList<>();
        List<String> inflammationList = new ArrayList<>();
        List<String> neutrophilsList = new ArrayList<>();
        List<String> lymphocytesList = new ArrayList<>();
        List<String> eosinophilsList = new ArrayList<>();
        List<String> macrophagesList = new ArrayList<>();
        List<String> plasmaCellsList = new ArrayList<>();
        List<String> depthOfInflammationList = new ArrayList<>();
        List<String> patternOfInflammationList = new ArrayList<>();
        List<String> granulomaList = new ArrayList<>();
        List<String> giantCellsList = new ArrayList<>();
        List<String> reactiveLymphoidFolliclesList = new ArrayList<>();

        List<String> mucosalDenudationList = new ArrayList<>();
        List<String> mucosalUlcerationList = new ArrayList<>();
        List<String> mucosalHyperPlasiaList = new ArrayList<>();
        List<String> fibrosisList = new ArrayList<>();


        List<String> muscleHypertrophyList = new ArrayList<>();
        List<String> mucocyteVacuolisationList = new ArrayList<>();
        List<String> rasList = new ArrayList<>();
        List<String> hyalinisationList = new ArrayList<>();
        List<String> calcificationList = new ArrayList<>();
        List<String> cholesterolosisList = new ArrayList<>();
        List<String> metaplasiaList = new ArrayList<>();
        List<String> dysplasiaList = new ArrayList<>();
        List<String> atypiaNosList = new ArrayList<>();
        List<String> cholecystitisList = new ArrayList<>();
        List<String> incidentalGbcList = new ArrayList<>();
        List<String> invasiveList = new ArrayList<>();
        List<String> anyAdditionalFindingsList = new ArrayList<>();
        List<String> stoneAnalysisList = new ArrayList<>();
        List<String> numberOfStoneList = new ArrayList<>();
        List<String> sizeOfStonesMmList = new ArrayList<>();
        List<String> colorOfStonesList = new ArrayList<>();
        List<String> shapeOfStonesList = new ArrayList<>();
        List<String> weightOfStoneList = new ArrayList<>();
        List<String> totalVolumeList = new ArrayList<>();
        List<String> stoneCsList = new ArrayList<>();
        List<String> ftirList = new ArrayList<>();
        List<String> cholesterolCompositionList = new ArrayList<>();
        List<String> ses_classList = new ArrayList<>();
        List<String> vehicle_categoryList = new ArrayList<>();
        List<String> water_sourceList = new ArrayList<>();
        List<JsonNode> opd_visitList = new ArrayList<>();
        List<JsonNode> ipd_visitList = new ArrayList<>();
        List<String> hoLumpList = new ArrayList<>();
        List<String>    hoLumpDescList = new ArrayList<>();

        List<Row> rows = new ArrayList<>();

        int indexRow = 1;
        for (DirectusUserResponse directusUserResponse : response) {
            int nestedIndexCell = 0;
            Row row = sheet.createRow(indexRow);
            rows.add(row);

            nestedIndexCell = createCellWithSingleCoulmn(variables, directusUserResponse, row, nestedIndexCell);


            JsonNode NearestHealthCareCenter = directusUserResponse.getNearestHealthCareCenter();
            nearestHealthCenterList.add(NearestHealthCareCenter);

            JsonNode weeklyFoodConsumption = directusUserResponse.getWeeklyFoodConsumption();
            weeklyFoodConsumptionList.add(weeklyFoodConsumption);

            JsonNode typhoid = directusUserResponse.getTyphoid();
            typhoidList.add(typhoid);

            JsonNode alcohol = directusUserResponse.getAlcohol();
            alcoholList.add(alcohol);

            JsonNode  pesticideUse = directusUserResponse.getPesticideUse();
            pesticideUseList.add(pesticideUse);

            JsonNode smoking = directusUserResponse.getSmoking();
            smokingList.add(smoking);

            JsonNode familyHistory = directusUserResponse.getFamilyHistory();
            familyHistoryList.add(familyHistory);

            JsonNode reproductiveHPerO = directusUserResponse.getReproductiveHPerO();
            reproductiveHPerOList.add(reproductiveHPerO);

            JsonNode drugHistory = directusUserResponse.getDrugHistory();
            drugHistoryList.add(drugHistory);

            JsonNode familyHistoryOfCancer = directusUserResponse.getFamilyHistoryOfCancer();
            familyListOfCancerList.add(familyHistoryOfCancer);

            JsonNode pregnanciesHistory = directusUserResponse.getPregnanciesHistory();
            pregnanciesHistoryList.add(pregnanciesHistory);

            JsonNode anthropometricMeasurement = directusUserResponse.getAnthropometricMeasurement();
            anthropometricMeasurementList.add(anthropometricMeasurement);

            JsonNode typeOfFats = directusUserResponse.getTypeOfFats();
            typeOfFatsList.add(typeOfFats);

            JsonNode foodRedChili = directusUserResponse.getFoodRedChili();
            foodRedChiliList.add(foodRedChili);

            JsonNode foodGreenChili = directusUserResponse.getFoodGreenChili();
            foodGreenChiliList.add(foodGreenChili);

            JsonNode foodPeanuts = directusUserResponse.getFoodPeanuts();
            foodPeanutsList.add(foodPeanuts);

            JsonNode gallbladderEjectionFraction = directusUserResponse.getGallbladderEjectionFraction();
            gallbladderEjectionFractionList.add(gallbladderEjectionFraction);


            JsonNode symptomsOfDyspepsia = directusUserResponse.getSymptomsOfDyspepsia();
            symptomsOfDyspepsiaList.add(symptomsOfDyspepsia);

            JsonNode types = directusUserResponse.getTypes();
            typesList.add(types);

            JsonNode liverFunctionTest = directusUserResponse.getLiverFunctionTest();
            liverFunctionTestList.add(liverFunctionTest);

            JsonNode haematology = directusUserResponse.getHaematology();
            haematologyList.add(haematology);

            JsonNode biochemistry = directusUserResponse.getBiochemistry();
            biochemistryList.add(biochemistry);

            JsonNode dyspepsiaScoringIndex = directusUserResponse.getDyspepsiaScoringIndex();
            dyspepsiaScoringIndexList.add(dyspepsiaScoringIndex);

            JsonNode diet = directusUserResponse.getDiet();
            dietList.add(diet);


            JsonNode opd_visit = directusUserResponse.getOpd_visit();
            opd_visitList.add(opd_visit);

            JsonNode ipd_visit = directusUserResponse.getIpd_visit();
            ipd_visitList.add(ipd_visit);

            recruitmentMethodList.add(directusUserResponse.getRecruitment_method());
            stateOfResidenceLast10YearsList.add(directusUserResponse.getState_of_residence_last_10_years());
            stateOfResidenceFirst10YearsList.add(directusUserResponse.getState_of_residence_first_10_years());
            livesInList.add(directusUserResponse.getLives_in());
            marriedList.add(directusUserResponse.getMarried());
            religionList.add(directusUserResponse.getReligion());
            adultsList.add(directusUserResponse.getAdults());
            childrenList.add(directusUserResponse.getChildren());
            totalFamilyMembersList.add(directusUserResponse.getTotal_family_members());
            patientEducationList.add(directusUserResponse.getPatient_education());
            patientOccupationList.add(directusUserResponse.getPatient_occupation());
            occupationScoreList.add(directusUserResponse.getOccupation_score());
            educationScoreList.add(directusUserResponse.getEducation_score());
            familyIncomeScoreList.add(directusUserResponse.getFamily_income_score());
            totalScoreList.add(directusUserResponse.getTotal_score());

            ses_classList.add(directusUserResponse.getSes_class());

            vehicle_categoryList.add(directusUserResponse.getVehicle_category());
            water_sourceList.add(directusUserResponse.getWater_source());

            clinicalHistoryList.add(directusUserResponse.getClinical_History());
            coMorbidityDetailsList.add(directusUserResponse.getCo_morbidity_details());
            industrialExposureList.add(directusUserResponse.getIndustrial_Exposure());
            numberOfBrothersList.add(directusUserResponse.getNumber_of_brothers());
            numberOfSistersList.add(directusUserResponse.getNumber_of_sisters());
            numberOfSonsList.add(directusUserResponse.getNumber_of_sons());
            numberOfDaughtersList.add(directusUserResponse.getNumber_of_daughters());
            fhgsList.add(directusUserResponse.getFh_gs());
            fhcancerList.add(directusUserResponse.getFh_cancer());

            fhGbcList.add(directusUserResponse.getF_h_gbc());
            fhLiverCancerList.add(directusUserResponse.getF_h_liver_cancer());
            fhLiverCirrhosisList.add(directusUserResponse.getF_h_liver_cirrhosis());
            dietaryDeterminantsList.add(directusUserResponse.getDietary_determinants());
            stapleFoodList.add(directusUserResponse.getStaple_food());
            repeatedlyHeatedOilList.add(directusUserResponse.getRepeatedly_heated_oil());
            gallStoneList.add(directusUserResponse.getGall_Stone());
            gallstoneStatusList.add(directusUserResponse.getGallstone_status());
            descriptionOfSymptomsList.add(directusUserResponse.getDescription_of_symptoms());
            whenFirstDetectedList.add(directusUserResponse.getWhen_first_detected());
            stoneDurationMonthsList.add(directusUserResponse.getStoneDurationMonths());
            symptomDurationMonthsList.add(directusUserResponse.getSymptom_duration_months());
            incidentalList.add(directusUserResponse.getIncidental());
            documentedOnList.add(directusUserResponse.getDocumented_on());
            symptomStatusList.add(directusUserResponse.getSymptom_status());
            diseaseSeverityList.add(directusUserResponse.getDisease_severity());
            painDescriptionList.add(directusUserResponse.getPainDiscomfort());
            painDescriptionOnsetList.add(directusUserResponse.getPainDescriptionOnset());
            painTypeList.add(directusUserResponse.getPain_type());
            locationList.add(directusUserResponse.getLocation());
            intensityList.add(directusUserResponse.getIntensity());
            durationList.add(directusUserResponse.getDuration());
            exactTimeList.add(String.valueOf(directusUserResponse.getExact_time()));
            radiationList.add(directusUserResponse.getRadiation());
            nauseaList.add(directusUserResponse.getNausea());
            vomitingList.add(directusUserResponse.getVomiting());
            precipitatedByList.add(directusUserResponse.getPrecipitated_by());

            times_per_dayList.add(directusUserResponse.getTimes_per_day());
            times_per_weekList.add(directusUserResponse.getTimes_per_week());
            times_per_monthList.add(directusUserResponse.getTimes_per_month());
            times_per_yearList.add(directusUserResponse.getTimes_per_year());
            infrequentList.add(directusUserResponse.getInfrequent());
            reliefOfPainList.add(directusUserResponse.getRelief_of_pain());
            isRequireHospitalizationList.add(directusUserResponse.getIs_require_hospitalization());
            totalNumberOfHospitalizationsList.add(directusUserResponse.getTotal_number_of_hospitalizations());
            associatedSymptomsList.add(directusUserResponse.getAssociated_symptoms());
            stoolFrequencyInLastOneWeekList.add(directusUserResponse.getStool_frequency_in_last_one_week());
            bristolStoolUsualScoreList.add(directusUserResponse.getBristol_stool_usual_score());
            bristolStoolWorstScoreList.add(directusUserResponse.getBristol_stool_worst_score());
            wasSurgeryAdvisedList.add(directusUserResponse.getWas_Surgery_advised());
            whenWasSurgeryAdvisedList.add(directusUserResponse.getWhen_was_surgey_advised());
            wasSurgeryDoneList.add(directusUserResponse.getWas_Surgery_Done());
            whyNotDoneSurgeryList.add(directusUserResponse.getWhy_not_done_surgery());
            finalScoreList.add(directusUserResponse.getFinal_Score());

            finalLeedScoreList.add(directusUserResponse.getFinalLeedsScore());

            gbcClinicalPresentationHelperList.add(directusUserResponse.getGBC_Clinical_presentation());

            painValueList.add(directusUserResponse.getPain_value());
            painDescList.add(directusUserResponse.getDuration_Description());
            jaundiceValueList.add(directusUserResponse.getJaundice_value());

            jaundiceDescriptionList.add(directusUserResponse.getJaundice_description());
            pruritisXValueList.add(directusUserResponse.getPruritis_x_value());
            pruritisDescriptionList.add(directusUserResponse.getPruritis_description());
            feverValueList.add(directusUserResponse.getFever_value());
            feverDescriptionList.add(directusUserResponse.getFever_description());
            cholangitisXValueList.add(directusUserResponse.getCholangitis_x_value());
            cholangitisDescriptionList.add(directusUserResponse.getCholangitis_description());
            abdDistensionXValueList.add(directusUserResponse.getAbd_distension_x_value());
            abdDistensionDesList.add(directusUserResponse.getAbd_distension_des());
            featuresOfGooXValueList.add(directusUserResponse.getFeatures_of_goo_x_value());
            featuresOfGooDescriptionList.add(directusUserResponse.getFeatures_of_goo_description());
            anorexiaValueList.add(directusUserResponse.getAnorexia_value());
            anorexiaDescriptionList.add(directusUserResponse.getAnorexia_description());
            gbLumpSizeValueList.add(directusUserResponse.getGbLumpSizeXValue());
            gbLumpSizeDescriptionList.add(directusUserResponse.getGb_lump_size_description());

//            gbLumpDurationList.add(directusUserResponse.getGb_lump_duration());
//            gbLumpSizeList.add(directusUserResponse.getGb_lump_size());
            weightLossValueList.add(directusUserResponse.getWeight_loss_value());
            weightLossDescriptionList.add(directusUserResponse.getGb_lump_size_description());
//            weightLossDurationList.add(directusUserResponse.getWight_loss_duration());
//            weightList.add(directusUserResponse.getWeight());
            pastHistoryOfGsdXValueList.add(directusUserResponse.getPast_history_of_gsd_x_value());
            pastHistoryOfGsdDescList.add(directusUserResponse.getPast_history_of_gsd_desc());
            durationOfGsdXValueList.add(directusUserResponse.getDuration_of_gsd_x_value());
            durationOfGsdDescList.add(directusUserResponse.getDuration_of_gsd_desc());
            pastHistoryOfBiliaryColicXValueList.add(directusUserResponse.getPast_history_of_biliary_colic_x_value());
            pastHistoryOfBiliaryColicDescList.add(directusUserResponse.getPast_history_of_biliary_colic_desc());
            hepatomegalyXValueList.add(directusUserResponse.getHepatomegaly_x_value());
            hepatomegalyDescList.add(directusUserResponse.getHepatomegaly_desc());
            postCholecystectomyScarXValueList.add(directusUserResponse.getPost_cholecystectomy_scar_x_value());
            postCholecystectomyScarDescList.add(directusUserResponse.getPost_cholecystectomy_scar_desc());
            supraclavicularLnXValueList.add(directusUserResponse.getSupraclavicular_ln_x_value());
            supraclavicularLnDescList.add(directusUserResponse.getSupraclavicular_ln_desc());
            ascitesXValueList.add(directusUserResponse.getAscites_x_value());
            ascitesDescList.add(directusUserResponse.getAscites_desc());
            tendernessValueList.add(directusUserResponse.getTenderness_value());
            tendernessDescriptionList.add(directusUserResponse.getTenderness_description());
            clinicalExaminationList.add(directusUserResponse.getClinicalExamination());
            ecogPerformanceStatusList.add(directusUserResponse.getEcog_performance_status());
            qualityOfLifeList.add(directusUserResponse.getQuality_of_life());
            mobilityList.add(directusUserResponse.getMobility());
            selfCareList.add(directusUserResponse.getSelf_care());
            usualActivityList.add(directusUserResponse.getUsual_activity());
            anxietyDepressionList.add(directusUserResponse.getAnxiety_depression());
            healthScaleList.add(directusUserResponse.getHealth_scale());
            investigationsList.add(directusUserResponse.getInvestigations());
            radiologyList.add(String.valueOf(directusUserResponse.getRadiology()));
            dateOfRadiologyList.add(String.valueOf(directusUserResponse.getDate_of_radiology()));
            usgDoneByList.add(directusUserResponse.getUsg_done_by());
            outSideStudyCenterList.add(directusUserResponse.getOut_side_study_center());
            ifOutsideMentionCentreList.add(directusUserResponse.getIf_outside_mention_centre());
            fastingList.add(directusUserResponse.getFasting());
            gallbladderStatusList.add(directusUserResponse.getGallbladder_status());
            sludgeList.add(directusUserResponse.getSludge());
            gbPolypList.add(directusUserResponse.getGb_polyp());
            stoneList.add(directusUserResponse.getStone());
            StonePresentList.add(directusUserResponse.getStonePresent());
            SingleOrMultipleOrGBPackedWithStonesList.add(directusUserResponse.getSingleOrMultipleOrGBPackedWithStones());
            numberOfStonesList.add(directusUserResponse.getNumber_of_stones());
            gbWallList.add(directusUserResponse.getGBWall());
            sizeOfStonesList.add(directusUserResponse.getSize_of_stones());
            fundusMmList.add(directusUserResponse.getFundus_mm());
            bodyMmList.add(directusUserResponse.getBody_mm());
            neckMmList.add(directusUserResponse.getNeck_mm());

            thickenedWallList.add(directusUserResponse.getThickened_wall());
            FocalOrDiffuseList.add(directusUserResponse.getFocalOrDiffuse());
            SymmetricalOrAsymmetricalList.add(directusUserResponse.getSymmetricalOrAsymmetrical());

            layeredAppearanceList.add(directusUserResponse.getLayered_appearance());
            gbWallIntramuralCystList.add(directusUserResponse.getGb_wall_intramural_cyst());
            intramuralEchogenicFociList.add(directusUserResponse.getIntramural_echogenic_foci());
            gbInterfaceWithLiverList.add(directusUserResponse.getGb_interface_with_liver());
            fattyLiverList.add(directusUserResponse.getFatty_liver());
            anyComplicationsList.add(directusUserResponse.getAny_complications());
            gradeOfFattyLiverList.add(directusUserResponse.getGrade_of_fatty_liver());
            complicationsList.add(directusUserResponse.getComplications());
            dateList.add(directusUserResponse.getDate());
            surgeryList.add(directusUserResponse.getSurgery());
            surgeryDoneByList.add(directusUserResponse.getSurgery_done_by());
            outsideStudyCentreList.add(directusUserResponse.getOutside_study_centre());
            ifOutsideMentionNameList.add(directusUserResponse.getIf_outside_mention_name());
            typeOfSurgeryList.add(directusUserResponse.getType_of_surgery());
            intraoperativeFindingsList.add(directusUserResponse.getIntraoperative_findings());
            gallBladderList.add(directusUserResponse.getGall_bladder());
            gallBladderDistensionList.add(directusUserResponse.getGall_bladder_distension());
            anyAnatomicalVariationList.add(directusUserResponse.getAny_anatomical_variation());
            cutSectionList.add(directusUserResponse.getCut_section());
            bileSpillageList.add(directusUserResponse.getBile_spillage());
            durationOfProcedureList.add(directusUserResponse.getDuration_of_procedure());
            difficultyList.add(directusUserResponse.getDifficulty());
            complicationList.add(directusUserResponse.getComplication());
            histologyList.add(directusUserResponse.getHistology());
            refNumberList.add(directusUserResponse.getRef_number());
            lengthOfGbCmList.add(directusUserResponse.getLength_of_gb_cm());
            wallThicknessList.add(directusUserResponse.getWall_thickness());
            fundusList.add(directusUserResponse.getFundus());
            bodyList.add(directusUserResponse.getBody());
            neckList.add(directusUserResponse.getNeck());
            inflammationList.add(directusUserResponse.getInflammation());
            neutrophilsList.add(directusUserResponse.getNeutrophils());
            lymphocytesList.add(directusUserResponse.getLymphocytes());
            eosinophilsList.add(directusUserResponse.getEosinophils());
            macrophagesList.add(directusUserResponse.getMacrophages());
            plasmaCellsList.add(directusUserResponse.getPlasma_cells());
            depthOfInflammationList.add(directusUserResponse.getDepth_of_inflammation());
            patternOfInflammationList.add(directusUserResponse.getPattern_of_inflammation());
            granulomaList.add(directusUserResponse.getGranuloma());
            giantCellsList.add(directusUserResponse.getGiant_cells());
            reactiveLymphoidFolliclesList.add(directusUserResponse.getReactive_lymphoid_follicles());
            mucosalDenudationList.add(directusUserResponse.getMucosal_Denudation());
            mucosalUlcerationList.add(directusUserResponse.getMucosal_Ulceration());
            mucosalHyperPlasiaList.add(directusUserResponse.getMucosal_HyperPlasia());
            fibrosisList.add(directusUserResponse.getFibrosis());
            muscleHypertrophyList.add(directusUserResponse.getMuscle_hypertrophy());
            mucocyteVacuolisationList.add(directusUserResponse.getMucocyte_vacuolisation());
            rasList.add(directusUserResponse.getRAS());
            hyalinisationList.add(directusUserResponse.getHyalinisation());
            calcificationList.add(directusUserResponse.getCalcification());
            cholesterolosisList.add(directusUserResponse.getCholesterolosis());
            metaplasiaList.add(directusUserResponse.getMetaplasia());
            dysplasiaList.add(directusUserResponse.getDysplasia());
            atypiaNosList.add(directusUserResponse.getAtypia_nos());
            cholecystitisList.add(directusUserResponse.getCholecystitis());
            incidentalGbcList.add(directusUserResponse.getIncidental_gbc());
            invasiveList.add(directusUserResponse.getInvasive_Carcinoma());
            anyAdditionalFindingsList.add(directusUserResponse.getAny_additional_findings());
            stoneAnalysisList.add(directusUserResponse.getStone_analysis());
             numberOfStoneList.add(directusUserResponse.getNumber_of_stone());
            sizeOfStonesMmList.add(directusUserResponse.getSize_of_stones_mm());
            colorOfStonesList.add(directusUserResponse.getColor_of_stones());
            shapeOfStonesList.add(directusUserResponse.getShape_of_stones());
            weightOfStoneList.add(directusUserResponse.getWeight_of_stone());
            totalVolumeList.add(directusUserResponse.getTotal_volume());
            stoneCsList.add(directusUserResponse.getStone_cs());
            ftirList.add(directusUserResponse.getFtir());
            hoLumpList.add(directusUserResponse.getH_O_Lump());
            hoLumpDescList.add(directusUserResponse.getH_O_Lump_Desc());
            cholesterolCompositionList.add(directusUserResponse.getCholesterol_composition());
            indexRow++;

        }

        NearestHealthCenterHelper nearestHealthCenterJsonNodeHelper = NearestHealthCenterHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(nearestHealthCenterList)
                .rows(rows)
                .key("")
                .build();
        headerIndex = nearestHealthCenterJsonNodeHelper.prePareData();

        SingleColumnHelper recruitmentMethodHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(recruitmentMethodList)
                .rows(rows)
                .fieldName("Recruitment_method")
                .build();
        headerIndex = recruitmentMethodHelper.prePareData();

        SingleColumnHelper stateOfResidenceLast10YearsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(stateOfResidenceLast10YearsList)
                .rows(rows)
                .fieldName("State_of_residence_last_10_years")
                .build();
        headerIndex = stateOfResidenceLast10YearsHelper.prePareData();

        SingleColumnHelper stateOfResidenceFirst10YearsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(stateOfResidenceFirst10YearsList)
                .rows(rows)
                .fieldName("State_of_residence_first_10_years")
                .build();
        headerIndex = stateOfResidenceFirst10YearsHelper.prePareData();

        SingleColumnHelper livesInHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(livesInList)
                .rows(rows)
                .fieldName("Lives_in")
                .build();
        headerIndex = livesInHelper.prePareData();

        SingleColumnHelper marriedHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(marriedList)
                .rows(rows)
                .fieldName("Married")
                .build();
        headerIndex = marriedHelper.prePareData();

        SingleColumnHelper religionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(religionList)
                .rows(rows)
                .fieldName("Religion")
                .build();
        headerIndex = religionHelper.prePareData();

        SingleColumnHelper adultsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(adultsList)
                .rows(rows)
                .fieldName("Adults")
                .build();
        headerIndex = adultsHelper.prePareData();

        SesCategoryHelper childrenHelper = SesCategoryHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(childrenList)
                .rows(rows)
                .fieldName("Children")
                .build();
        headerIndex = childrenHelper.prePareData();

        SingleColumnHelper totalFamilyMembersHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(totalFamilyMembersList)
                .rows(rows)
                .fieldName("Total_family_members")
                .build();
        headerIndex = totalFamilyMembersHelper.prePareData();

        SingleColumnHelper patientEducationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(patientEducationList)
                .rows(rows)
                .fieldName("Patient_education")
                .build();
        headerIndex = patientEducationHelper.prePareData();

        SingleColumnHelper patientOccupationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(patientOccupationList)
                .rows(rows)
                .fieldName("Patient_occupation")
                .build();
        headerIndex = patientOccupationHelper.prePareData();

        SingleColumnHelper occupationScoreHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(occupationScoreList)
                .rows(rows)
                .fieldName("Occupation_score")
                .build();
        headerIndex = occupationScoreHelper.prePareData();

        SingleColumnHelper educationScoreHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(educationScoreList)
                .rows(rows)
                .fieldName("Education_score")
                .build();
        headerIndex = educationScoreHelper.prePareData();

        SingleColumnHelper familyIncomeScoreHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(familyIncomeScoreList)
                .rows(rows)
                .fieldName("Family_income_score")
                .build();
        headerIndex = familyIncomeScoreHelper.prePareData();

        SingleColumnHelper totalScoreHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(totalScoreList)
                .rows(rows)
                .fieldName("Total_score")
                .build();
        headerIndex = totalScoreHelper.prePareData();


        SesCategoryHelper ses_CategoryHelper = SesCategoryHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(ses_classList)
                .rows(rows)
                .fieldName("Ses_category")
                .build();
        headerIndex = ses_CategoryHelper.prePareData();

        SingleColumnHelper ses_classHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(ses_classList)
                .rows(rows)
                .fieldName("ses_class")
                .build();
        headerIndex = ses_classHelper.prePareData();

        SingleColumnHelper vehicle_categoryHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(vehicle_categoryList)
                .rows(rows)
                .fieldName("vehicle_category")
                .build();
        headerIndex = vehicle_categoryHelper.prePareData();

        SingleColumnHelper water_sourceHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(water_sourceList)
                .rows(rows)
                .fieldName("water_source")
                .build();
        headerIndex = water_sourceHelper.prePareData();


        ReproductiveHPerOHelper reproductiveHPerOJsonNodeHelper = ReproductiveHPerOHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(reproductiveHPerOList)
                .rows(rows)
                .key("")
                .build();
        headerIndex = reproductiveHPerOJsonNodeHelper.prePareData();

        PregnanciesHistoryHelper pregnanciesHistoryJsonNodeHelper = PregnanciesHistoryHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(pregnanciesHistoryList)
                .rows(rows)
                .key("")
                .build();
        headerIndex = pregnanciesHistoryJsonNodeHelper.prePareData();

        AnthropometricFieldHelper anthropometricMeasurementHelper = AnthropometricFieldHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(anthropometricMeasurementList)
                .rows(rows)
                .key("")
                .build();
        headerIndex = anthropometricMeasurementHelper.prePareData();


        SingleColumnHelper clinicalHistoryHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(clinicalHistoryList)
                .rows(rows)
                .fieldName("clinical_history")
                .build();
        headerIndex = clinicalHistoryHelper.prePareData();

        SingleColumnHelper coMorbidityDetailsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(coMorbidityDetailsList)
                .rows(rows)
                .fieldName("co_morbidity_details")
                .build();
        headerIndex = coMorbidityDetailsHelper.prePareData();

        DrugHistoryField drugHistory = DrugHistoryField.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(drugHistoryList)
                .rows(rows)
                .key("1")
                .build();
        headerIndex = drugHistory.prePareData();

        TyphoidHelper typhoidJsonNodeHelper = TyphoidHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(typhoidList)
                .rows(rows)
                .key("")
                .build();
        headerIndex = typhoidJsonNodeHelper.prePareData();

        SmokingHelper smokingJsonNodeHelper = SmokingHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(smokingList)
                .rows(rows)
                .key("_Smoking")
                .build();
        headerIndex = smokingJsonNodeHelper.prePareData();

        AlcoholHelper alcoholJsonNodeHelper = AlcoholHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(alcoholList)
                .rows(rows)
                .key("Alcohol")
                .build();
        headerIndex = alcoholJsonNodeHelper.prePareData();



        SingleColumnHelper industrialExposureHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(industrialExposureList)
                .rows(rows)
                .fieldName("industrial_exposure")
                .build();
        headerIndex = industrialExposureHelper.prePareData();



        PesticideUseHelper pesticideUseJsonNodeHelper = PesticideUseHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(pesticideUseList)
                .rows(rows)
                .key("_PesticideUse")
                .build();
        headerIndex = pesticideUseJsonNodeHelper.prePareData();

        SingleColumnHelper numberOfBrothersHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(numberOfBrothersList)
                .rows(rows)
                .fieldName("number_of_brothers")
                .build();
        headerIndex = numberOfBrothersHelper.prePareData();

        SingleColumnHelper numberOfSistersHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(numberOfSistersList)
                .rows(rows)
                .fieldName("number_of_sisters")
                .build();
        headerIndex = numberOfSistersHelper.prePareData();

        SingleColumnHelper numberOfSonsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(numberOfSonsList)
                .rows(rows)
                .fieldName("number_of_sons")
                .build();
        headerIndex = numberOfSonsHelper.prePareData();

        SingleColumnHelper numberOfDaughtersHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(numberOfDaughtersList)
                .rows(rows)
                .fieldName("number_of_daughters")
                .build();
        headerIndex = numberOfDaughtersHelper.prePareData();

        SingleColumnHelper fh_gsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(fhgsList)
                .rows(rows)
                .fieldName("fh_gs")
                .build();
        headerIndex = fh_gsHelper.prePareData();


        FamilyHistoryHelper familyHistoryJsonNodeHelper = FamilyHistoryHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(familyHistoryList)
                .rows(rows)
                .key("")
                .build();
        headerIndex = familyHistoryJsonNodeHelper.prePareData();

        SingleColumnHelper fh_CancerHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(fhcancerList)
                .rows(rows)
                .fieldName("fh_Cancer")
                .build();
        headerIndex = fh_CancerHelper.prePareData();

        FamilyHistoryOfCancerHelper familyHistoryOfCancerJsonNodeHelper = FamilyHistoryOfCancerHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(familyListOfCancerList)
                .rows(rows)
                .key("")
                .build();
        headerIndex = familyHistoryOfCancerJsonNodeHelper.prePareData();


        SingleColumnHelper fhGbcHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(fhGbcList)
                .rows(rows)
                .fieldName("fh_gbc")
                .build();
        headerIndex = fhGbcHelper.prePareData();

        SingleColumnHelper fhLiverCancerHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(fhLiverCancerList)
                .rows(rows)
                .fieldName("fh_liver_cancer")
                .build();
        headerIndex = fhLiverCancerHelper.prePareData();

        SingleColumnHelper fhLiverCirrhosisHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(fhLiverCirrhosisList)
                .rows(rows)
                .fieldName("fh_liver_cirrhosis")
                .build();
        headerIndex = fhLiverCirrhosisHelper.prePareData();

        SingleColumnHelper dietaryDeterminantsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(dietaryDeterminantsList)
                .rows(rows)
                .fieldName("dietary_determinants")
                .build();
        headerIndex = dietaryDeterminantsHelper.prePareData();

        DietJsonNodeHelper dietJsonNodeHelper = DietJsonNodeHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(dietList)
                .rows(rows)
                .key("")
                .build();
        headerIndex = dietJsonNodeHelper.prePareData();


        SingleColumnHelper stapleFoodHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(stapleFoodList)
                .rows(rows)
                .fieldName("staple_food")
                .build();
        headerIndex = stapleFoodHelper.prePareData();



        FatsTypeHelper typeOfFatsbasedOnDifferentField = FatsTypeHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(typeOfFatsList)
                .rows(rows)
                .key("1")
                .build();
        headerIndex = typeOfFatsbasedOnDifferentField.prePareData();

        SingleColumnHelper repeatedlyHeatedOilHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(repeatedlyHeatedOilList)
                .rows(rows)
                .fieldName("repeatedly_heated_oil")
                .build();
        headerIndex = repeatedlyHeatedOilHelper.prePareData();

        BasedOnDifferentField WFCbasedOnDifferentField = BasedOnDifferentField.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(weeklyFoodConsumptionList)
                .rows(rows)
                .key("1")
                .build();
        headerIndex = WFCbasedOnDifferentField.prePareData();


        TypesHelper typesHelper = TypesHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(typesList)
                .rows(rows)
                .build();
        headerIndex = typesHelper.prePareData();


        FoodRedChilliHelper foodRedChiliJsonNodeHelper = FoodRedChilliHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(foodRedChiliList)
                .rows(rows)
                .key("_RedChili")
                .build();
        headerIndex = foodRedChiliJsonNodeHelper.prePareData();

        GreenChilliHelper foodGreenChiliJsonNodeHelper = GreenChilliHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(foodGreenChiliList)
                .rows(rows)
                .key("_GreenChili")
                .build();
        headerIndex = foodGreenChiliJsonNodeHelper.prePareData();

        FoodPeanutsHelper foodPeanutsJsonNodeHelper = FoodPeanutsHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(foodPeanutsList)
                .rows(rows)
                .key("_FoodPeanuts")
                .build();
        headerIndex = foodPeanutsJsonNodeHelper.prePareData();

        SingleColumnHelper gallStoneHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gallStoneList)
                .rows(rows)
                .fieldName("Gall_Stone")
                .build();
        headerIndex = gallStoneHelper.prePareData();

        SingleColumnHelper gallstoneStatusHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gallstoneStatusList)
                .rows(rows)
                .fieldName("GS_status")
                .build();
        headerIndex = gallstoneStatusHelper.prePareData();

        SingleColumnHelper descriptionOfSymptomsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(descriptionOfSymptomsList)
                .rows(rows)
                .fieldName("description_of_symptoms")
                .build();
        headerIndex = descriptionOfSymptomsHelper.prePareData();

        SingleColumnHelper whenFirstDetectedHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(whenFirstDetectedList)
                .rows(rows)
                .fieldName("when_first_detected")
                .build();
        headerIndex = whenFirstDetectedHelper.prePareData();

        SingleColumnHelper stoneDurationMonthsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(stoneDurationMonthsList)
                .rows(rows)
                .fieldName("stone Duration(in Months)")
                .build();
        headerIndex = stoneDurationMonthsHelper.prePareData();

        SingleColumnHelper symptomDurationMonthsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(symptomDurationMonthsList)
                .rows(rows)
                .fieldName("symptom_duration_months")
                .build();
        headerIndex = symptomDurationMonthsHelper.prePareData();

        SingleColumnHelper incidentalHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(incidentalList)
                .rows(rows)
                .fieldName("incidental")
                .build();
        headerIndex = incidentalHelper.prePareData();

        SingleColumnHelper documentedOnHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(documentedOnList)
                .rows(rows)
                .fieldName("documented_on")
                .build();
        headerIndex = documentedOnHelper.prePareData();

        SingleColumnHelper symptomStatusHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(symptomStatusList)
                .rows(rows)
                .fieldName("symptom_status")
                .build();
        headerIndex = symptomStatusHelper.prePareData();

        SingleColumnHelper diseaseSeverityHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(diseaseSeverityList)
                .rows(rows)
                .fieldName("disease_severity")
                .build();
        headerIndex = diseaseSeverityHelper.prePareData();

        SingleColumnHelper PainDescriptionOnsetHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(painDescriptionOnsetList)
                .rows(rows)
                .fieldName("PainDescriptionOnset")
                .build();
        headerIndex = PainDescriptionOnsetHelper.prePareData();


        SingleColumnHelper painTypeHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(painTypeList)
                .rows(rows)
                .fieldName("pain_type")
                .build();
        headerIndex = painTypeHelper.prePareData();



        SingleColumnHelper locationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(locationList)
                .rows(rows)
                .fieldName("location")
                .build();
        headerIndex = locationHelper.prePareData();

        SingleColumnHelper intensityHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(intensityList)
                .rows(rows)
                .fieldName("intensity")
                .build();
        headerIndex = intensityHelper.prePareData();

        SingleColumnHelper durationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(durationList)
                .rows(rows)
                .fieldName("duration")
                .build();
        headerIndex = durationHelper.prePareData();

//        SingleColumnHelper exactTimeHelper = SingleColumnHelper.builder()
//                .headerIndex(headerIndex)
//                .header(header)
//                .dataToCreateList(exactTimeList)
//                .rows(rows)
//                .fieldName("exact_time")
//                .build();
//        headerIndex = exactTimeHelper.prePareData();

        SingleColumnHelper radiationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(radiationList)
                .rows(rows)
                .fieldName("radiation")
                .build();
        headerIndex = radiationHelper.prePareData();

        SingleColumnHelper nauseaHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(nauseaList)
                .rows(rows)
                .fieldName("nausea")
                .build();
        headerIndex = nauseaHelper.prePareData();

        SingleColumnHelper vomitingHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(vomitingList)
                .rows(rows)
                .fieldName("vomiting")
                .build();
        headerIndex = vomitingHelper.prePareData();

        SingleColumnHelper precipitatedByHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(precipitatedByList)
                .rows(rows)
                .fieldName("precipitated_by")
                .build();
        headerIndex = precipitatedByHelper.prePareData();

//        SingleColumnHelper frequencyHelper = SingleColumnHelper.builder()
//                .headerIndex(headerIndex)
//                .header(header)
//                .dataToCreateList(frequencyList)
//                .rows(rows)
//                .fieldName("frequency")
//                .build();
//        headerIndex = frequencyHelper.prePareData();

        SingleColumnHelper dayHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(times_per_dayList)
                .rows(rows)
                .fieldName("times_per_day")
                .build();
        headerIndex = dayHelper.prePareData();

        SingleColumnHelper weekHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(times_per_weekList)
                .rows(rows)
                .fieldName("times_per_week")
                .build();
        headerIndex = weekHelper.prePareData();


        SingleColumnHelper monthHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(times_per_monthList)
                .rows(rows)
                .fieldName("times_per_month")
                .build();
        headerIndex = monthHelper.prePareData();


        SingleColumnHelper yearHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(times_per_yearList)
                .rows(rows)
                .fieldName("times_per_year")
                .build();
        headerIndex = yearHelper.prePareData();


        SingleColumnHelper infrequentHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(infrequentList)
                .rows(rows)
                .fieldName("If infrequency describe")
                .build();
        headerIndex = infrequentHelper.prePareData();


        //if_infrequent,describe

        SingleColumnHelper reliefOfPainHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(reliefOfPainList)
                .rows(rows)
                .fieldName("relief_of_pain")
                .build();
        headerIndex = reliefOfPainHelper.prePareData();

        SingleColumnHelper isRequireHospitalizationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(isRequireHospitalizationList)
                .rows(rows)
                .fieldName("is_require_hospitalization")
                .build();
        headerIndex = isRequireHospitalizationHelper.prePareData();

        SingleColumnHelper totalNumberOfHospitalizationsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(totalNumberOfHospitalizationsList)
                .rows(rows)
                .fieldName("total_number_of_hospitalizations")
                .build();
        headerIndex = totalNumberOfHospitalizationsHelper.prePareData();

        SingleColumnHelper associatedSymptomsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(associatedSymptomsList)
                .rows(rows)
                .fieldName("associated_symptoms")
                .build();
        headerIndex = associatedSymptomsHelper.prePareData();

        SingleColumnHelper stoolFrequencyInLastOneWeekHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(stoolFrequencyInLastOneWeekList)
                .rows(rows)
                .fieldName("stool_frequency_in_last_one_week")
                .build();
        headerIndex = stoolFrequencyInLastOneWeekHelper.prePareData();

        SingleColumnHelper bristolStoolUsualScoreHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(bristolStoolUsualScoreList)
                .rows(rows)
                .fieldName("bristol_stool_usual_score")
                .build();
        headerIndex = bristolStoolUsualScoreHelper.prePareData();

        SingleColumnHelper bristolStoolWorstScoreHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(bristolStoolWorstScoreList)
                .rows(rows)
                .fieldName("bristol_stool_worst_score")
                .build();
        headerIndex = bristolStoolWorstScoreHelper.prePareData();

        SingleColumnHelper WasSurgeryAdvisedHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(wasSurgeryAdvisedList)
                .rows(rows)
                .fieldName("Was_Surgery_advised")
                .build();
        headerIndex = WasSurgeryAdvisedHelper.prePareData();

        SingleColumnHelper whenWasSurgeryAdvisedHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(whenWasSurgeryAdvisedList)
                .rows(rows)
                .fieldName("when_was_surgery_advised")
                .build();
        headerIndex = whenWasSurgeryAdvisedHelper.prePareData();

        SingleColumnHelper WasSurgeryDoneHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(wasSurgeryDoneList)
                .rows(rows)
                .fieldName("Was_Surgery_Done")
                .build();
        headerIndex = WasSurgeryDoneHelper.prePareData();

        SingleColumnHelper whyNotDoneSurgeryHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(whyNotDoneSurgeryList)
                .rows(rows)
                .fieldName("why_not_done_surgery")
                .build();
        headerIndex = whyNotDoneSurgeryHelper.prePareData();

        SymptomsOfDyspepsiaBasedOnDifferentField symptomsOfDyspepsiabasedOnDifferentField = SymptomsOfDyspepsiaBasedOnDifferentField.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(symptomsOfDyspepsiaList)
                .rows(rows)
                .key("2")
                .build();
        headerIndex = symptomsOfDyspepsiabasedOnDifferentField.prePareData();


        DyspepsiaScoringIndexHelper dyspepsiaScoringIndexbasedOnDifferentField = DyspepsiaScoringIndexHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(dyspepsiaScoringIndexList)
                .rows(rows)
                .key("3")
                .build();
        headerIndex = dyspepsiaScoringIndexbasedOnDifferentField.prePareData();

        SingleColumnHelper finalScoreHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(finalScoreList)
                .rows(rows)
                .fieldName("Final_Score")
                .build();
        headerIndex = finalScoreHelper.prePareData();


        LeadScoringHelper finalLeedsScoreHelper = LeadScoringHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(dyspepsiaScoringIndexList)
                .rows(rows)
                .key("3")
                .build();
        headerIndex = finalLeedsScoreHelper.prePareData();

        SingleColumnHelper gbcClinicalPresentationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gbcClinicalPresentationHelperList)
                .rows(rows)
                .fieldName("GBC_Clinical_presentation")
                .build();
        headerIndex = gbcClinicalPresentationHelper.prePareData();

        SingleColumnHelper painValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(painValueList)
                .rows(rows)
                .fieldName("pain_value")
                .build();
        headerIndex = painValueHelper.prePareData();

        SingleColumnHelper painDescHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(painDescList)
                .rows(rows)
                .fieldName("Duration_Description")
                .build();
        headerIndex = painDescHelper.prePareData();



        SingleColumnHelper jaundiceValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(jaundiceValueList)
                .rows(rows)
                .fieldName("jaundice_value")
                .build();
        headerIndex = jaundiceValueHelper.prePareData();

        SingleColumnHelper jaundiceDescriptionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(jaundiceDescriptionList)
                .rows(rows)
                .fieldName("jaundice_description")
                .build();
        headerIndex = jaundiceDescriptionHelper.prePareData();

        SingleColumnHelper pruritisXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(pruritisXValueList)
                .rows(rows)
                .fieldName("pruritis_x_value")
                .build();
        headerIndex = pruritisXValueHelper.prePareData();

        SingleColumnHelper pruritisDescriptionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(pruritisDescriptionList)
                .rows(rows)
                .fieldName("pruritis_description")
                .build();
        headerIndex = pruritisDescriptionHelper.prePareData();

        SingleColumnHelper feverValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(feverValueList)
                .rows(rows)
                .fieldName("fever_value")
                .build();
        headerIndex = feverValueHelper.prePareData();

        SingleColumnHelper feverDescriptionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(feverDescriptionList)
                .rows(rows)
                .fieldName("fever_description")
                .build();
        headerIndex = feverDescriptionHelper.prePareData();

        SingleColumnHelper cholangitisXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(cholangitisXValueList)
                .rows(rows)
                .fieldName("cholangitis_x_value")
                .build();
        headerIndex = cholangitisXValueHelper.prePareData();

        SingleColumnHelper cholangitisDescriptionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(cholangitisDescriptionList)
                .rows(rows)
                .fieldName("cholangitis_description")
                .build();
        headerIndex = cholangitisDescriptionHelper.prePareData();

        SingleColumnHelper abdDistensionXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(abdDistensionXValueList)
                .rows(rows)
                .fieldName("abd_distension_x_value")
                .build();
        headerIndex = abdDistensionXValueHelper.prePareData();


        SingleColumnHelper abdDistensionDesHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(abdDistensionDesList)
                .rows(rows)
                .fieldName("abd_distension_description")
                .build();
        headerIndex = abdDistensionDesHelper.prePareData();

        SingleColumnHelper featuresOfGooXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(featuresOfGooXValueList)
                .rows(rows)
                .fieldName("features_of_goo_x_value")
                .build();
        headerIndex = featuresOfGooXValueHelper.prePareData();

        SingleColumnHelper featuresOfGooDescriptionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(featuresOfGooDescriptionList)
                .rows(rows)
                .fieldName("features_of_goo_description")
                .build();
        headerIndex = featuresOfGooDescriptionHelper.prePareData();

        SingleColumnHelper anorexiaValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(anorexiaValueList)
                .rows(rows)
                .fieldName("anorexia_value")
                .build();
        headerIndex = anorexiaValueHelper.prePareData();

        SingleColumnHelper anorexiaDescriptionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(anorexiaDescriptionList)
                .rows(rows)
                .fieldName("anorexia_description")
                .build();
        headerIndex = anorexiaDescriptionHelper.prePareData();

        SingleColumnHelper HOLumpHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(hoLumpList)
                .rows(rows)
                .fieldName("H_O_Lump")
                .build();
        headerIndex = HOLumpHelper.prePareData();

        SingleColumnHelper HOLumpDescHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(hoLumpDescList)
                .rows(rows)
                .fieldName("H_O_Lump_Desc")
                .build();
        headerIndex = HOLumpDescHelper.prePareData();

             SingleColumnHelper weightLossValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(weightLossValueList)
                .rows(rows)
                .fieldName("weight_loss_value")
                .build();
        headerIndex = weightLossValueHelper.prePareData();

        SingleColumnHelper weightLossDescriptionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(weightLossDescriptionList)
                .rows(rows)
                .fieldName("weight_loss_description")
                .build();
        headerIndex = weightLossDescriptionHelper.prePareData();

//        SingleColumnHelper weightLossDurationHelper = SingleColumnHelper.builder()
//                .headerIndex(headerIndex)
//                .header(header)
//                .dataToCreateList(weightLossDurationList)
//                .rows(rows)
//                .fieldName("weight_loss_duration")
//                .build();
//        headerIndex = weightLossDurationHelper.prePareData();
//
//        SingleColumnHelper weightHelper = SingleColumnHelper.builder()
//                .headerIndex(headerIndex)
//                .header(header)
//                .dataToCreateList(weightList)
//                .rows(rows)
//                .fieldName("weight")
//                .build();
//        headerIndex = weightHelper.prePareData();

        SingleColumnHelper pastHistoryOfGsdXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(pastHistoryOfGsdXValueList)
                .rows(rows)
                .fieldName("past_history_of_gsd_x_value")
                .build();
        headerIndex = pastHistoryOfGsdXValueHelper.prePareData();

        SingleColumnHelper pastHistoryOfGsdDescHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(pastHistoryOfGsdDescList)
                .rows(rows)
                .fieldName("past_history_of_gsd_desc")
                .build();
        headerIndex = pastHistoryOfGsdDescHelper.prePareData();

        SingleColumnHelper durationOfGsdXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(durationOfGsdXValueList)
                .rows(rows)
                .fieldName("duration_of_gsd_x_value")
                .build();
        headerIndex = durationOfGsdXValueHelper.prePareData();

        SingleColumnHelper durationOfGsdDescHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(durationOfGsdDescList)
                .rows(rows)
                .fieldName("duration_of_gsd_desc")
                .build();
        headerIndex = durationOfGsdDescHelper.prePareData();

        SingleColumnHelper pastHistoryOfBiliaryColicXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(pastHistoryOfBiliaryColicXValueList)
                .rows(rows)
                .fieldName("past_history_of_biliary_colic_x_value")
                .build();
        headerIndex = pastHistoryOfBiliaryColicXValueHelper.prePareData();

        SingleColumnHelper pastHistoryOfBiliaryColicDescHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(pastHistoryOfBiliaryColicDescList)
                .rows(rows)
                .fieldName("past_history_of_biliary_colic_desc")
                .build();
        headerIndex = pastHistoryOfBiliaryColicDescHelper.prePareData();

        SingleColumnHelper gbLumpSizeValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gbLumpSizeValueList)
                .rows(rows)
                .fieldName("gbLumpSizeXValue")
                .build();
        headerIndex = gbLumpSizeValueHelper.prePareData();

        SingleColumnHelper gbLumpSizeDescriptionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gbLumpSizeDescriptionList)
                .rows(rows)
                .fieldName("gb_lump_size_description")
                .build();
        headerIndex = gbLumpSizeDescriptionHelper.prePareData();



//        SingleColumnHelper gbLumpSizeHelper = SingleColumnHelper.builder()
//                .headerIndex(headerIndex)
//                .header(header)
//                .dataToCreateList(gbLumpSizeList)
//                .rows(rows)
//                .fieldName("gb_lump_size")
//                .build();
//        headerIndex = gbLumpSizeHelper.prePareData();
//
//
//
//        SingleColumnHelper gbLumpDurationHelper = SingleColumnHelper.builder()
//                .headerIndex(headerIndex)
//                .header(header)
//                .dataToCreateList(gbLumpDurationList)
//                .rows(rows)
//                .fieldName("gb_lump_duration")
//                .build();
//        headerIndex = gbLumpDurationHelper.prePareData();

        SingleColumnHelper hepatomegalyXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(hepatomegalyXValueList)
                .rows(rows)
                .fieldName("hepatomegaly_x_value")
                .build();
        headerIndex = hepatomegalyXValueHelper.prePareData();

        SingleColumnHelper hepatomegalyDescHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(hepatomegalyDescList)
                .rows(rows)
                .fieldName("hepatomegaly_description")
                .build();
        headerIndex = hepatomegalyDescHelper.prePareData();

        SingleColumnHelper postCholecystectomyScarXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(postCholecystectomyScarXValueList)
                .rows(rows)
                .fieldName("post_cholecystectomy_scar_x_value")
                .build();
        headerIndex = postCholecystectomyScarXValueHelper.prePareData();

        SingleColumnHelper postCholecystectomyScarDescHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(postCholecystectomyScarDescList)
                .rows(rows)
                .fieldName("post_cholecystectomy_scar_description")
                .build();
        headerIndex = postCholecystectomyScarDescHelper.prePareData();

        SingleColumnHelper supraclavicularLnXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(supraclavicularLnXValueList)
                .rows(rows)
                .fieldName("supraclavicular_ln_x_value")
                .build();
        headerIndex = supraclavicularLnXValueHelper.prePareData();

        SingleColumnHelper supraclavicularLnDescHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(supraclavicularLnDescList)
                .rows(rows)
                .fieldName("supraclavicular_ln_description")
                .build();
        headerIndex = supraclavicularLnDescHelper.prePareData();

        SingleColumnHelper ascitesXValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(ascitesXValueList)
                .rows(rows)
                .fieldName("ascites_x_value")
                .build();
        headerIndex = ascitesXValueHelper.prePareData();

        SingleColumnHelper ascitesDescHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(ascitesDescList)
                .rows(rows)
                .fieldName("ascites_description")
                .build();
        headerIndex = ascitesDescHelper.prePareData();

        SingleColumnHelper tendernessValueHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(tendernessValueList)
                .rows(rows)
                .fieldName("tenderness_value")
                .build();
        headerIndex = tendernessValueHelper.prePareData();

        SingleColumnHelper tendernessDescriptionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(tendernessDescriptionList)
                .rows(rows)
                .fieldName("tenderness_description")
                .build();
        headerIndex = tendernessDescriptionHelper.prePareData();



        SingleColumnHelper clinicalExaminationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(clinicalExaminationList)
                .rows(rows)
                .fieldName("ClinicalExamination")
                .build();
        headerIndex = clinicalExaminationHelper.prePareData();

        SingleColumnHelper ecogPerformanceStatusHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(ecogPerformanceStatusList)
                .rows(rows)
                .fieldName("ecog_performance_status")
                .build();
        headerIndex = ecogPerformanceStatusHelper.prePareData();

        SingleColumnHelper qualityOfLifeHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(qualityOfLifeList)
                .rows(rows)
                .fieldName("quality_of_life")
                .build();
        headerIndex = qualityOfLifeHelper.prePareData();



        SingleColumnHelper mobilityHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(mobilityList)
                .rows(rows)
                .fieldName("mobility")
                .build();
        headerIndex = mobilityHelper.prePareData();

        SingleColumnHelper selfCareHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(selfCareList)
                .rows(rows)
                .fieldName("self_care")
                .build();
        headerIndex = selfCareHelper.prePareData();

        SingleColumnHelper usualActivityHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(usualActivityList)
                .rows(rows)
                .fieldName("usual_activity")
                .build();
        headerIndex = usualActivityHelper.prePareData();


        SingleColumnHelper painDescriptionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(painDescriptionList)
                .rows(rows)
                .fieldName("painDiscomfort")
                .build();
        headerIndex = painDescriptionHelper.prePareData();




        SingleColumnHelper anxietyDepressionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(anxietyDepressionList)
                .rows(rows)
                .fieldName("anxiety_depression")
                .build();
        headerIndex = anxietyDepressionHelper.prePareData();

        SingleColumnHelper healthScaleHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(healthScaleList)
                .rows(rows)
                .fieldName("health_scale")
                .build();
        headerIndex = healthScaleHelper.prePareData();

        SingleColumnHelper investigationsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(investigationsList)
                .rows(rows)
                .fieldName("investigations")
                .build();
        headerIndex = investigationsHelper.prePareData();

        HaematologyHelper haematology = HaematologyHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(haematologyList)
                .key("")
                .rows(rows)
                .build();
        headerIndex =  haematology.prePareData();

        liverFunctionTestHelper liverFunctionTest = liverFunctionTestHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(liverFunctionTestList)
                .key("")
                .rows(rows)
                .build();
        headerIndex = liverFunctionTest.prePareData();

        BioChemistryHelper biochemistry = BioChemistryHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(biochemistryList)
                .key("")
                .rows(rows)
                .build();
        headerIndex = biochemistry.prePareData();


        SingleColumnHelper radiologyHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(radiologyList)
                .rows(rows)
                .fieldName("Radiology")
                .build();
        headerIndex = radiologyHelper.prePareData();


        SingleColumnHelper dateOfRadiologyHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(dateOfRadiologyList)
                .rows(rows)
                .fieldName("date_of_radiology")
                .build();
        headerIndex = dateOfRadiologyHelper.prePareData();

        SingleColumnHelper usgDoneByHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(usgDoneByList)
                .rows(rows)
                .fieldName("usg_done_by")
                .build();
        headerIndex = usgDoneByHelper.prePareData();

        SingleColumnHelper outSideStudyCenterHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(outSideStudyCenterList)
                .rows(rows)
                .fieldName("outside_study_center")
                .build();
        headerIndex = outSideStudyCenterHelper.prePareData();



        SingleColumnHelper ifOutsideMentionCentreHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(ifOutsideMentionCentreList)
                .rows(rows)
                .fieldName("if_outside_mention_centre")
                .build();
        headerIndex = ifOutsideMentionCentreHelper.prePareData();

        SingleColumnHelper fastingHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(fastingList)
                .rows(rows)
                .fieldName("Fasting")
                .build();
        headerIndex = fastingHelper.prePareData();


        SingleColumnHelper gallbladderStatusHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gallbladderStatusList)
                .rows(rows)
                .fieldName("gallbladder_status")
                .build();
        headerIndex = gallbladderStatusHelper.prePareData();

        SingleColumnHelper sludgeHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(sludgeList)
                .rows(rows)
                .fieldName("sludge")
                .build();
        headerIndex = sludgeHelper.prePareData();

        SingleColumnHelper gbPolypHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gbPolypList)
                .rows(rows)
                .fieldName("gb_polyp")
                .build();
        headerIndex = gbPolypHelper.prePareData();

//        SingleColumnHelper stoneHelper = SingleColumnHelper.builder()
//                .headerIndex(headerIndex)
//                .header(header)
//                .dataToCreateList(stoneList)
//                .rows(rows)
//                .fieldName("stone")
//                .build();
//        headerIndex = stoneHelper.prePareData();


        SingleColumnHelper StonePresentHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(StonePresentList)
                .rows(rows)
                .fieldName("StonePresent")
                .build();
        headerIndex = StonePresentHelper.prePareData();

        SingleColumnHelper SingleOrMultipleOrGBPackedWithStonesHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(SingleOrMultipleOrGBPackedWithStonesList)
                .rows(rows)
                .fieldName("SingleOrMultipleOrGBPackedWithStones")
                .build();
        headerIndex = SingleOrMultipleOrGBPackedWithStonesHelper.prePareData();



        SingleColumnHelper numberOfStonesHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(numberOfStonesList)
                .rows(rows)
                .fieldName("number_of_stones")
                .build();
        headerIndex = numberOfStonesHelper.prePareData();

        SingleColumnHelper sizeOfStonesHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(sizeOfStonesList)
                .rows(rows)
                .fieldName("size_of_stones")
                .build();
        headerIndex = sizeOfStonesHelper.prePareData();

        SingleColumnHelper gbWallHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gbWallList)
                .rows(rows)
                .fieldName("GBWall")
                .build();
        headerIndex = gbWallHelper.prePareData();

        SingleColumnHelper fundusMmHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(fundusMmList)
                .rows(rows)
                .fieldName("fundus_mm")
                .build();
        headerIndex = fundusMmHelper.prePareData();

        SingleColumnHelper bodyMmHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(bodyMmList)
                .rows(rows)
                .fieldName("body_mm")
                .build();
        headerIndex = bodyMmHelper.prePareData();

        SingleColumnHelper neckMmHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(neckMmList)
                .rows(rows)
                .fieldName("neck_mm")
                .build();
        headerIndex = neckMmHelper.prePareData();


//        SingleColumnHelper thickenedWallHelper = SingleColumnHelper.builder()
//                .headerIndex(headerIndex)
//                .header(header)
//                .dataToCreateList(thickenedWallList)
//                .rows(rows)
//                .fieldName("thickened_wall")
//                .build();
//        headerIndex = thickenedWallHelper.prePareData();



        SingleColumnHelper FocalOrDiffuseHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(FocalOrDiffuseList)
                .rows(rows)
                .fieldName("FocalOrDiffuse")
                .build();
        headerIndex = FocalOrDiffuseHelper.prePareData();

        SingleColumnHelper SymmetricalOrAsymmetricalHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(SymmetricalOrAsymmetricalList)
                .rows(rows)
                .fieldName("SymmetricalOrAsymmetrical")
                .build();
        headerIndex = SymmetricalOrAsymmetricalHelper.prePareData();


        SingleColumnHelper layeredAppearanceHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(layeredAppearanceList)
                .rows(rows)
                .fieldName("layered_appearance")
                .build();
        headerIndex = layeredAppearanceHelper.prePareData();

        SingleColumnHelper gbWallIntramuralCystHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gbWallIntramuralCystList)
                .rows(rows)
                .fieldName("gb_wall_intramural_cyst")
                .build();
        headerIndex = gbWallIntramuralCystHelper.prePareData();

        SingleColumnHelper intramuralEchogenicFociHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(intramuralEchogenicFociList)
                .rows(rows)
                .fieldName("intramural_echogenic_foci")
                .build();
        headerIndex = intramuralEchogenicFociHelper.prePareData();

        SingleColumnHelper gbInterfaceWithLiverHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gbInterfaceWithLiverList)
                .rows(rows)
                .fieldName("gb_interface_with_liver")
                .build();
        headerIndex = gbInterfaceWithLiverHelper.prePareData();

        SingleColumnHelper fattyLiverHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(fattyLiverList)
                .rows(rows)
                .fieldName("fatty_liver")
                .build();
        headerIndex = fattyLiverHelper.prePareData();

        SingleColumnHelper gradeOfFattyLiverHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gradeOfFattyLiverList)
                .rows(rows)
                .fieldName("grade_of_fatty_liver")
                .build();
        headerIndex = gradeOfFattyLiverHelper.prePareData();

//        SingleColumnHelper anyComplicationsHelper = SingleColumnHelper.builder()
//                .headerIndex(headerIndex)
//                .header(header)
//                .dataToCreateList(anyComplicationsList)
//                .rows(rows)
//                .fieldName("any_complications")
//                .build();
//        headerIndex = anyComplicationsHelper.prePareData();

        SingleColumnHelper complicationsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(complicationsList)
                .rows(rows)
                .fieldName("complications")
                .build();
        headerIndex = complicationsHelper.prePareData();

        GallBladderEjectionSimpleExpandHelper GallBladderEjectionSimpleExpand = GallBladderEjectionSimpleExpandHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(gallbladderEjectionFractionList)
                .rows(rows)
                .key("")
                .build();
        headerIndex = GallBladderEjectionSimpleExpand.prePareData();


        GallBladderEjectionFractionForVolumnHelper gallbladderEjectionFractionJsonNodeHelper = GallBladderEjectionFractionForVolumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(gallbladderEjectionFractionList)
                .rows(rows)
                .key("")
                .build();
        headerIndex = gallbladderEjectionFractionJsonNodeHelper.prePareData();

        SingleColumnHelper surgeryHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(surgeryList)
                .rows(rows)
                .fieldName("Surgery")
                .build();
        headerIndex = surgeryHelper.prePareData();

        SingleColumnHelper dateHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(dateList)
                .rows(rows)
                .fieldName("date")
                .build();
        headerIndex = dateHelper.prePareData();


        SingleColumnHelper surgeryDoneByHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(surgeryDoneByList)
                .rows(rows)
                .fieldName("surgery_done_by")
                .build();
        headerIndex = surgeryDoneByHelper.prePareData();

        SingleColumnHelper outsideStudyCentreHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(outsideStudyCentreList)
                .rows(rows)
                .fieldName("outside_study_centre")
                .build();
        headerIndex = outsideStudyCentreHelper.prePareData();

        SingleColumnHelper ifOutsideMentionNameHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(ifOutsideMentionNameList)
                .rows(rows)
                .fieldName("if_outside_mention_name")
                .build();
        headerIndex = ifOutsideMentionNameHelper.prePareData();

        SingleColumnHelper typeOfSurgeryHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(typeOfSurgeryList)
                .rows(rows)
                .fieldName("type_of_surgery")
                .build();
        headerIndex = typeOfSurgeryHelper.prePareData();

        SingleColumnHelper intraoperativeFindingsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(intraoperativeFindingsList)
                .rows(rows)
                .fieldName("intraoperative_findings")
                .build();
        headerIndex = intraoperativeFindingsHelper.prePareData();


        SingleColumnHelper gallBladderHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gallBladderList)
                .rows(rows)
                .fieldName("gall_bladder")
                .build();
        headerIndex = gallBladderHelper.prePareData();

        SingleColumnHelper gallBladderDistensionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(gallBladderDistensionList)
                .rows(rows)
                .fieldName("gall_bladder_distension")
                .build();
        headerIndex = gallBladderDistensionHelper.prePareData();

        SingleColumnHelper anyAnatomicalVariationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(anyAnatomicalVariationList)
                .rows(rows)
                .fieldName("any_anatomical_variation")
                .build();
        headerIndex = anyAnatomicalVariationHelper.prePareData();

        SingleColumnHelper cutSectionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(cutSectionList)
                .rows(rows)
                .fieldName("cut_section")
                .build();
        headerIndex = cutSectionHelper.prePareData();

        SingleColumnHelper bileSpillageHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(bileSpillageList)
                .rows(rows)
                .fieldName("bile_spillage")
                .build();
        headerIndex = bileSpillageHelper.prePareData();

        SingleColumnHelper durationOfProcedureHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(durationOfProcedureList)
                .rows(rows)
                .fieldName("duration_of_procedure")
                .build();
        headerIndex = durationOfProcedureHelper.prePareData();

        SingleColumnHelper difficultyHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(difficultyList)
                .rows(rows)
                .fieldName("difficulty")
                .build();
        headerIndex = difficultyHelper.prePareData();

        SingleColumnHelper complicationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(complicationList)
                .rows(rows)
                .fieldName("complication")
                .build();
        headerIndex = complicationHelper.prePareData();

        SingleColumnHelper histologyHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(histologyList)
                .rows(rows)
                .fieldName("histology")
                .build();
        headerIndex = histologyHelper.prePareData();

        SingleColumnHelper refNumberHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(refNumberList)
                .rows(rows)
                .fieldName("ref_number")
                .build();
        headerIndex = refNumberHelper.prePareData();

        SingleColumnHelper lengthOfGbCmHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(lengthOfGbCmList)
                .rows(rows)
                .fieldName("length_of_gb_cm")
                .build();
        headerIndex = lengthOfGbCmHelper.prePareData();

        SingleColumnHelper wallThicknessHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(wallThicknessList)
                .rows(rows)
                .fieldName("wall_thickness")
                .build();
        headerIndex = wallThicknessHelper.prePareData();

        SingleColumnHelper fundusHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(fundusList)
                .rows(rows)
                .fieldName("fundus")
                .build();
        headerIndex = fundusHelper.prePareData();

        SingleColumnHelper bodyHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(bodyList)
                .rows(rows)
                .fieldName("body")
                .build();
        headerIndex = bodyHelper.prePareData();

        SingleColumnHelper neckHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(neckList)
                .rows(rows)
                .fieldName("neck")
                .build();
        headerIndex = neckHelper.prePareData();

        SingleColumnHelper inflammationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(inflammationList)
                .rows(rows)
                .fieldName("inflammation")
                .build();
        headerIndex = inflammationHelper.prePareData();

        SingleColumnHelper neutrophilsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(neutrophilsList)
                .rows(rows)
                .fieldName("neutrophils")
                .build();
        headerIndex = neutrophilsHelper.prePareData();

        SingleColumnHelper lymphocytesHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(lymphocytesList)
                .rows(rows)
                .fieldName("lymphocytes")
                .build();
        headerIndex = lymphocytesHelper.prePareData();

        SingleColumnHelper eosinophilsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(eosinophilsList)
                .rows(rows)
                .fieldName("eosinophils")
                .build();
        headerIndex = eosinophilsHelper.prePareData();

        SingleColumnHelper macrophagesHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(macrophagesList)
                .rows(rows)
                .fieldName("macrophages")
                .build();
        headerIndex = macrophagesHelper.prePareData();

        SingleColumnHelper plasmaCellsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(plasmaCellsList)
                .rows(rows)
                .fieldName("plasma_cells")
                .build();
        headerIndex = plasmaCellsHelper.prePareData();

        SingleColumnHelper depthOfInflammationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(depthOfInflammationList)
                .rows(rows)
                .fieldName("depth_of_inflammation")
                .build();
        headerIndex = depthOfInflammationHelper.prePareData();

        SingleColumnHelper patternOfInflammationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(patternOfInflammationList)
                .rows(rows)
                .fieldName("pattern_of_inflammation")
                .build();
        headerIndex = patternOfInflammationHelper.prePareData();

        SingleColumnHelper granulomaHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(granulomaList)
                .rows(rows)
                .fieldName("granuloma")
                .build();
        headerIndex = granulomaHelper.prePareData();

        SingleColumnHelper giantCellsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(giantCellsList)
                .rows(rows)
                .fieldName("giant_cells")
                .build();
        headerIndex = giantCellsHelper.prePareData();

        SingleColumnHelper reactiveLymphoidFolliclesHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(reactiveLymphoidFolliclesList)
                .rows(rows)
                .fieldName("reactive_lymphoid_follicles")
                .build();
        headerIndex = reactiveLymphoidFolliclesHelper.prePareData();

        SingleColumnHelper mucosalDenudationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(mucosalDenudationList)
                .rows(rows)
                .fieldName("Mucosal_Denudation")
                .build();
        headerIndex = mucosalDenudationHelper.prePareData();

        SingleColumnHelper mucosalUlcerationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(mucosalUlcerationList)
                .rows(rows)
                .fieldName("Mucosal_Ulceration")
                .build();
        headerIndex = mucosalUlcerationHelper.prePareData();

        SingleColumnHelper mucosalHyperPlasiaHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(mucosalHyperPlasiaList)
                .rows(rows)
                .fieldName("Mucosal_HyperPlasia")
                .build();
        headerIndex = mucosalHyperPlasiaHelper.prePareData();

        SingleColumnHelper fibrosisHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(fibrosisList)
                .rows(rows)
                .fieldName("Fibrosis")
                .build();
        headerIndex = fibrosisHelper.prePareData();


        SingleColumnHelper muscleHypertrophyHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(muscleHypertrophyList)
                .rows(rows)
                .fieldName("muscle_hypertrophy")
                .build();
        headerIndex = muscleHypertrophyHelper.prePareData();

        SingleColumnHelper mucocyteVacuolisationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(mucocyteVacuolisationList)
                .rows(rows)
                .fieldName("mucocyte_vacuolisation")
                .build();
        headerIndex = mucocyteVacuolisationHelper.prePareData();

        SingleColumnHelper rasHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(rasList)
                .rows(rows)
                .fieldName("RAS")
                .build();
        headerIndex = rasHelper.prePareData();

        SingleColumnHelper hyalinisationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(hyalinisationList)
                .rows(rows)
                .fieldName("hyalinisation")
                .build();
        headerIndex = hyalinisationHelper.prePareData();

        SingleColumnHelper calcificationHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(calcificationList)
                .rows(rows)
                .fieldName("calcification")
                .build();
        headerIndex = calcificationHelper.prePareData();

        SingleColumnHelper cholesterolosisHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(cholesterolosisList)
                .rows(rows)
                .fieldName("cholesterolosis")
                .build();
        headerIndex = cholesterolosisHelper.prePareData();

        SingleColumnHelper metaplasiaHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(metaplasiaList)
                .rows(rows)
                .fieldName("metaplasia")
                .build();
        headerIndex = metaplasiaHelper.prePareData();

        SingleColumnHelper dysplasiaHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(dysplasiaList)
                .rows(rows)
                .fieldName("dysplasia")
                .build();
        headerIndex = dysplasiaHelper.prePareData();

        SingleColumnHelper atypiaNosHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(atypiaNosList)
                .rows(rows)
                .fieldName("atypia_nos")
                .build();
        headerIndex = atypiaNosHelper.prePareData();

        SingleColumnHelper cholecystitisHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(cholecystitisList)
                .rows(rows)
                .fieldName("cholecystitis")
                .build();
        headerIndex = cholecystitisHelper.prePareData();

        SingleColumnHelper incidentalGbcHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(incidentalGbcList)
                .rows(rows)
                .fieldName("incidental_gbc")
                .build();
        headerIndex = incidentalGbcHelper.prePareData();

        SingleColumnHelper invasiveHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(invasiveList)
                .rows(rows)
                .fieldName("Invasive_Carcinoma")
                .build();
        headerIndex = invasiveHelper.prePareData();

        SingleColumnHelper anyAdditionalFindingsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(anyAdditionalFindingsList)
                .rows(rows)
                .fieldName("any_additional_findings")
                .build();
        headerIndex = anyAdditionalFindingsHelper.prePareData();

        SingleColumnHelper stoneAnalysisHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(stoneAnalysisList)
                .rows(rows)
                .fieldName("stone_analysis")
                .build();
        headerIndex = stoneAnalysisHelper.prePareData();


        SingleColumnHelper numberOfStoneHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(numberOfStoneList)
                .rows(rows)
                .fieldName("number_of_stone")
                .build();
        headerIndex = numberOfStoneHelper.prePareData();



        SingleColumnHelper sizeOfStonesMmHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(sizeOfStonesMmList)
                .rows(rows)
                .fieldName("size_of_stones_mm")
                .build();
        headerIndex = sizeOfStonesMmHelper.prePareData();

        SingleColumnHelper colorOfStonesHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(colorOfStonesList)
                .rows(rows)
                .fieldName("color_of_stones")
                .build();
        headerIndex = colorOfStonesHelper.prePareData();

        SingleColumnHelper shapeOfStonesHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(shapeOfStonesList)
                .rows(rows)
                .fieldName("shape_of_stones")
                .build();
        headerIndex = shapeOfStonesHelper.prePareData();

        SingleColumnHelper weightOfStoneHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(weightOfStoneList)
                .rows(rows)
                .fieldName("weight_of_stone")
                .build();
        headerIndex = weightOfStoneHelper.prePareData();

        SingleColumnHelper totalVolumeHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(totalVolumeList)
                .rows(rows)
                .fieldName("total_volume")
                .build();
        headerIndex = totalVolumeHelper.prePareData();

        SingleColumnHelper stoneCsHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(stoneCsList)
                .rows(rows)
                .fieldName("stone_c/s")
                .build();
        headerIndex = stoneCsHelper.prePareData();

        SingleColumnHelper ftirHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(ftirList)
                .rows(rows)
                .fieldName("ftir")
                .build();
        headerIndex = ftirHelper.prePareData();

        SingleColumnHelper cholesterolCompositionHelper = SingleColumnHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .dataToCreateList(cholesterolCompositionList)
                .rows(rows)
                .fieldName("cholesterol_composition")
                .build();
        headerIndex = cholesterolCompositionHelper.prePareData();

        OpdVisitHelper opd_visitJsonNodeHelper = OpdVisitHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(opd_visitList)
                .rows(rows)
                .key("_OpdVisit")
                .build();
        headerIndex = opd_visitJsonNodeHelper.prePareData();

        OpdVisitHelper ipd_visitJsonNodeHelper = OpdVisitHelper.builder()
                .headerIndex(headerIndex)
                .header(header)
                .jsonNodes(ipd_visitList)
                .rows(rows)
                .key("_ipdVisit")
                .build();
        headerIndex = ipd_visitJsonNodeHelper.prePareData();

        return rows.size() -1;

    }

    private static int createCellWithSingleCoulmn(List<String> variables, DirectusUserResponse DirectusUserResponse, Row row, int nestedIndexCell) {
        for (String fieldName : variables) {
            String upperCaseFieldName =
                    String.valueOf(fieldName.charAt(0)).toUpperCase() + fieldName.substring(1);
            try {

                Cell cell = row.createCell(nestedIndexCell);
                Object invoke = DirectusUserResponse.getClass().getDeclaredMethod("get" + upperCaseFieldName).invoke(DirectusUserResponse);
                if (invoke != null) {
                    Class<?> returnType = DirectusUserResponse.getClass().getDeclaredMethod("get" + upperCaseFieldName).getReturnType();

                    switch (returnType.getSimpleName()) {
                        case "String" -> {
                            String value = (String) invoke;
                            String removeCommaValue = removeComma(value);
                            String changeToYesOrNo = changeToYesOrNo(removeCommaValue);
                            String trimmed = changeToYesOrNo.replace("undefined", "").trim();
                            cell.setCellValue((trimmed));
                        }
                        case "Integer", "int" -> cell.setCellValue((Integer) invoke);
                        case "Double", "double" -> cell.setCellValue((Double) invoke);
                        case "Boolean", "boolean" -> {
                            Boolean aBoolean = (Boolean) invoke;
                            String value = aBoolean.toString();
                            String removeCommaValue = removeComma(value);
                            String changeToYesOrNo = changeToYesOrNo(removeCommaValue);
                            String trimmed = changeToYesOrNo.replace("undefined", "").trim();
                            cell.setCellValue((trimmed));
                        }
                        case "LocalDateTime" -> cell.setCellValue(invoke != null ? invoke.toString() : "");
                        default -> cell.setCellValue(invoke != null ? invoke.toString() : "");
                    }
                }

                nestedIndexCell++;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return nestedIndexCell;
    }
}
