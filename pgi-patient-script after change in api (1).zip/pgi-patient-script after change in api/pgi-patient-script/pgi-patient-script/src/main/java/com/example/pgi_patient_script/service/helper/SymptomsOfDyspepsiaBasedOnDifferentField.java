package com.example.pgi_patient_script.service.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;

@Builder
public class SymptomsOfDyspepsiaBasedOnDifferentField {
    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap = new LinkedHashMap<>();
    private List<JsonNode> recreatedData = new ArrayList<>();
    private Integer maxHeaderRepeatCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    private static final List<String> ORDERED_HEADERS = Arrays.asList(
            "Bothersome epigastric pain",
            "Bothersome epigastric burning",
            "Bothersome early satiety",
            "Bothersome postprandial fullness",
            "Overall duration of symptoms ≥ 3m",
            "Criteria fulfilled for ≥ 6m"
    );

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxHeaderRepeatCount = 0;
    }

    private void creatingJsonNodeColumn() {
        setHeaderCount();
        createHeaderAndGetMaxHeaderRepeatCount();
        recreating();
        creatingInExcel();
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                for (String header : ORDERED_HEADERS) {
                    JsonNode valueNode = jsonNode.get(header);
                    String value = valueNode != null ? valueNode.asText() : "";
                    Cell cell = row.createCell(nestedIndex);
                    cell.setCellValue(value);
                    nestedIndex++;
                }
            }
            nestedIndex = oldHeader;
            rowIndex++;
        }
    }

    private void recreating() {
        for (JsonNode jsonNode : jsonNodes) {
            ObjectNode newlyCreatedJsonNode = JsonNodeFactory.instance.objectNode();

            if (jsonNode != null && jsonNode.isArray()) {
                Map<String, String> alreadyExistData = getAlreadyExistData(jsonNode);
                creatingDataOnBasisOfMaxHeaderCount(maxHeaderRepeatCount, headerCountMap, alreadyExistData, newlyCreatedJsonNode);
            } else {
                for (String header : ORDERED_HEADERS) {
                    newlyCreatedJsonNode.put(header, "");
                }
            }
            recreatedData.add(newlyCreatedJsonNode);
        }
    }

    private void creatingDataOnBasisOfMaxHeaderCount(Integer maxHeaderRepeatCount, Map<String, Integer> headerCountMap, Map<String, String> alreadyExistData, ObjectNode newlyCreatedJsonNode) {
        for (String header : ORDERED_HEADERS) {
            if (alreadyExistData.containsKey(header)) {
                String value = alreadyExistData.get(header);
                String removeCommaValue = removeComma(value);
                String changeToYesOrNo = changeToYesOrNo(removeCommaValue);
                String trimmed = changeToYesOrNo.replace("undefined", "").trim();
                newlyCreatedJsonNode.put(header, trimmed);
            } else {
                newlyCreatedJsonNode.put(header, "");
            }
        }
    }

    private Map<String, String> getAlreadyExistData(JsonNode jsonNode) {
        Map<String, String> alreadyExistData = new HashMap<>();
        for (JsonNode element : jsonNode) {
            if (element.isObject()) {
                Iterator<Map.Entry<String, JsonNode>> fields = element.fields();
                Map.Entry<String, JsonNode> keyNode = fields.next();
                Map.Entry<String, JsonNode> valueNode;

                if (key.equals("2")) {
                    valueNode = fields.next();
                    fields.next(); // Skip the third field
                } else {
                    // Existing logic for other keys
                    if (key.equals("1")) {
                        valueNode = fields.next();
                    } else {
                        fields.next();
                        valueNode = fields.next();
                    }
                }

                String symptomName = keyNode.getValue().asText();
                String symptomValue = valueNode.getValue().asText();
                alreadyExistData.put(symptomName, symptomValue);
            }
        }
        return alreadyExistData;
    }

    private void createHeaderAndGetMaxHeaderRepeatCount() {
        for (Map.Entry<String, Integer> stringIntegerEntry : headerCountMap.entrySet()) {
            if (stringIntegerEntry.getValue() > maxHeaderRepeatCount) {
                maxHeaderRepeatCount = stringIntegerEntry.getValue();
            }
        }

        for (String columnKey : ORDERED_HEADERS) {
            createHeaderCellMap(header, columnKey);
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellsValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellsValues.add(iterator.next().getStringCellValue());
        }

        if (!cellsValues.contains(variable)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }
    }

    private void setHeaderCount() {
        for (JsonNode jsonArrayNode : jsonNodes) {
            if (jsonArrayNode != null && jsonArrayNode.isArray()) {
                Map<String, Integer> nestedMap = new LinkedHashMap<>();
                for (JsonNode element : jsonArrayNode) {
                    if (element.isObject()) {
                        Iterator<Map.Entry<String, JsonNode>> fields = element.fields();
                        Map.Entry<String, JsonNode> field = fields.next();
                        String value = field.getValue().asText();
                        nestedMap.put(value, nestedMap.getOrDefault(value, 0) + 1);
                    }
                }

                for (Map.Entry<String, Integer> entry : nestedMap.entrySet()) {
                    headerCountMap.put(entry.getKey(), Math.max(entry.getValue(),
                            headerCountMap.getOrDefault(entry.getKey(), 0)));
                }
            }
        }
    }
}