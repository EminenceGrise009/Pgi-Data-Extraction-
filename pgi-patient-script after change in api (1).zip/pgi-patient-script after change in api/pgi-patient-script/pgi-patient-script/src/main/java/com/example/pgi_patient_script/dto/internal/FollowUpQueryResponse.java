package com.example.pgi_patient_script.dto.internal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FollowUpQueryResponse {

    private String  id;
    private String  age;
    private String  alternate_contact_no;
    private String  secondary_alternate_contact_no;
    private String  first_name;
    private String  last_name;
    private String  email;
    private String  primary_contact_no;
    private String  dob;
    private String  gender;
    private String  father_name;
    private String  mother_name;
    private String  address;
    private String  center_id;
    private String  whatsapp_no;
    private String  postal_code;
    private String  hospital_no;
    private String  admission_no;
    private String  ward_no;
    private String  bed_no;
    private String  physician_in_charge;
    private String  user_id;
    private String  surgeon_in_charge;
    private String  recruitment_date;
}
