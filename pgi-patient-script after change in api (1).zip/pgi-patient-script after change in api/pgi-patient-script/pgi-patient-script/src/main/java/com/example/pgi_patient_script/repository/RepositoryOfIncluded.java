package com.example.pgi_patient_script.repository;

import com.example.pgi_patient_script.dto.internal.FollowUpQueryResponse;
import com.example.pgi_patient_script.dto.internal.IncludedCountQueryResponse;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public class RepositoryOfIncluded {

    private final JdbcTemplate jdbcTemplate;

    public RepositoryOfIncluded(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<IncludedCountQueryResponse> getCountOfIncluded() {
        String sql = """
                SELECT
                SUM(CASE WHEN inclusion_status = 'included' THEN 1 ELSE 0 END) AS included,
                SUM(CASE WHEN inclusion_status = 'excluded' THEN 1 ELSE 0 END) AS excluded,
                SUM(CASE WHEN inclusion_status IS NULL OR inclusion_status = '' THEN 1 ELSE 0 END) AS pending
                FROM public.patiant_profile;
                """;
        return jdbcTemplate.query(sql,  BeanPropertyRowMapper.newInstance(IncludedCountQueryResponse.class));

    }
}

//SELECT
//SUM(CASE WHEN inclusion_status = 'included' THEN 1 ELSE 0 END) AS included,
//SUM(CASE WHEN inclusion_status = 'excluded' THEN 1 ELSE 0 END) AS excluded,
//SUM(CASE WHEN inclusion_status IS NULL OR inclusion_status = '' THEN 1 ELSE 0 END) AS pending
//FROM public.patiant_profile;