package com.example.pgi_patient_script.service.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.util.*;

import static com.example.pgi_patient_script.utils.ChangeBooleanType.changeToYesOrNo;
import static com.example.pgi_patient_script.utils.RemoveCommaUtils.removeComma;

@Builder
public class OpdVisitHelper {

    private int headerIndex;
    private Row header;
    private List<JsonNode> jsonNodes;
    private List<Row> rows;
    private Map<String, Integer> headerCountMap;
    private List<JsonNode> recreatedData;
    private Integer maxHeaderRepeatCount;
    private int nestedIndex;
    private int oldHeader;
    private String key;

    public int prePareData() {
        this.nestedIndex = headerIndex;
        this.oldHeader = headerIndex;
        createRelatedData();
        creatingJsonNodeColumn();
        return headerIndex;
    }

    private void createRelatedData() {
        headerCountMap = new LinkedHashMap<>();
        recreatedData = new ArrayList<>();
        maxHeaderRepeatCount = 0;
    }

    private void creatingJsonNodeColumn() {
        // Don't change the order
        setHeaderCount();
        createHeaderAndGetMaxHeaderRepeatCount();
        recreating();
        creatingInExcel();
    }

    private void creatingInExcel() {
        int rowIndex = 0;
        for (JsonNode jsonNode : recreatedData) {
            Row row = rows.get(rowIndex);
            if (jsonNode.isObject()) {
                Iterator<Map.Entry<String, JsonNode>> fields = jsonNode.fields();
                while (fields.hasNext()) {
                    Map.Entry<String, JsonNode> valueNode = fields.next();
                    String value = valueNode.getValue().asText();
                    Cell cell = row.createCell(nestedIndex);
                    cell.setCellValue(value);
                    nestedIndex++;
                }
            }
            nestedIndex = oldHeader;
            rowIndex++;
        }
    }

    private void recreating() {
        for (JsonNode jsonNode : jsonNodes) {
            ObjectNode newlyCreatedJsonNode = JsonNodeFactory.instance.objectNode();

            if (jsonNode != null) {
                if (jsonNode.isArray()) {
                    Map<String, String> alreadyExistData = getAlreadyExistData(jsonNode);
                    creatingDataOnBasisOfMaxHeaderCount(maxHeaderRepeatCount, headerCountMap, alreadyExistData, newlyCreatedJsonNode);
                }
            } else {
                for (int i = 1; i <= maxHeaderRepeatCount; i++) {
                    for (Map.Entry<String, Integer> entry : headerCountMap.entrySet()) {
                        String keyWithIndex = entry.getKey().concat("" + i);
                        newlyCreatedJsonNode.put(keyWithIndex, "");
                    }
                }
            }
            recreatedData.add(newlyCreatedJsonNode);
        }
    }

    private void creatingDataOnBasisOfMaxHeaderCount(Integer maxHeaderRepeatCount, Map<String, Integer> headerCountMap,
                                                     Map<String, String> alreadyExistData, ObjectNode newlyCreatedJsonNode) {
        for (int i = 1; i <= maxHeaderRepeatCount; i++) {
            int totalAmount = 0;
            for (Map.Entry<String, Integer> entry : headerCountMap.entrySet()) {
                String key = entry.getKey();
                String indexedKey = key.concat("" + i);

                if (alreadyExistData.containsKey(indexedKey)) {
                    String value = alreadyExistData.get(indexedKey);
                    String trimmed = value.replace("undefined", "").trim();
                    String processedValue = changeToYesOrNo(removeComma(trimmed));

                    if (!key.equals("distance") && !key.equals("vehicle") && !key.equals("date")) {
                        try {
                            totalAmount += Integer.parseInt(processedValue);
                        } catch (NumberFormatException e) {
                            System.out.println(key);
                        }
                    }
                    newlyCreatedJsonNode.put(indexedKey, processedValue);
                } else {
                    newlyCreatedJsonNode.put(indexedKey, "");
                }
            }
            newlyCreatedJsonNode.put("Total" + i, totalAmount);
        }
    }

    private Map<String, String> getAlreadyExistData(JsonNode jsonNode) {
        Map<String, String> alreadyExistData = new HashMap<>();
        int index = 1;

        for (JsonNode element : jsonNode) {
            if (element.isObject()) {
                Iterator<Map.Entry<String, JsonNode>> fields = element.fields();
                int totalAmount = 0;

                while (fields.hasNext()) {
                    Map.Entry<String, JsonNode> next = fields.next();
                    String key = next.getKey();
                    String indexedKey = key.concat("" + index);
                    String value = next.getValue().asText();
                    alreadyExistData.put(indexedKey, value);
                    if (!key.equals("distance") && !key.equals("vehicle") && !key.equals("date")) {
                        try {
                            totalAmount += Integer.parseInt(value);
                        } catch (NumberFormatException e) {
                            System.out.println(key);
                        }
                    }
                }
                alreadyExistData.put("Total" + index, Integer.toString(totalAmount));
            }
            index++;
        }
        return alreadyExistData;
    }

    private void createHeaderAndGetMaxHeaderRepeatCount() {
        for (Map.Entry<String, Integer> entry : headerCountMap.entrySet()) {
            maxHeaderRepeatCount = Math.max(maxHeaderRepeatCount, entry.getValue());
        }

        for (int i = 1; i <= maxHeaderRepeatCount; i++) {
            Set<String> headerKeys = new LinkedHashSet<>(headerCountMap.keySet());
            headerKeys.add("Total");
            for (String columnKey : headerKeys) {
                String concatenatedKey = columnKey.concat(key + "(" + i + ")");
                createHeaderCellMap(header, concatenatedKey);
            }
        }
    }

    private void createHeaderCellMap(Row header, String variable) {
        Iterator<Cell> iterator = header.iterator();
        List<String> cellValues = new ArrayList<>();

        while (iterator.hasNext()) {
            cellValues.add(iterator.next().getStringCellValue());
        }

        if (!cellValues.contains(variable)) {
            Cell headerCell = header.createCell(headerIndex);
            headerCell.setCellValue(variable);
            headerIndex++;
        }
    }

    private void setHeaderCount() {
        for (JsonNode jsonArrayNode : jsonNodes) {
            if (jsonArrayNode != null && jsonArrayNode.isArray()) {
                Map<String, Integer> nestedMap = new LinkedHashMap<>();
                for (JsonNode element : jsonArrayNode) {
                    if (element.isObject()) {
                        Iterator<Map.Entry<String, JsonNode>> fields = element.fields();
                        while (fields.hasNext()) {
                            Map.Entry<String, JsonNode> field = fields.next();
                            nestedMap.merge(field.getKey(), 1, Integer::sum);
                        }
                    }
                }

                for (Map.Entry<String, Integer> entry : nestedMap.entrySet()) {
                    headerCountMap.merge(entry.getKey(), entry.getValue(), Math::max);
                }
            }
        }
    }
}