package com.example.pgi_patient_script.utils;

public class ChangeBooleanType {
    public static String changeToYesOrNo(String value) {

        String newValue = "";
        if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")) {
            newValue = newValue.concat("Yes");
        } else if(value.equalsIgnoreCase("false") || value.equalsIgnoreCase("f")) {
            newValue = newValue.concat("No");
        }   else if(value.equalsIgnoreCase("null")||value.equalsIgnoreCase("-cm")||
                value.equalsIgnoreCase("-inches")||value.equalsIgnoreCase("NaN")){
            newValue = newValue.concat("");
        }
        else {
            newValue = newValue.concat(value);
        }
        return newValue;

    }
}